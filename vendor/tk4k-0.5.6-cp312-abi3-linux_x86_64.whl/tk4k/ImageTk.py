"""Stand-in for PIL.ImageTk, so `ImageTk.PhotoImage(pil_image)` works with TK 4K widgets.

Pillow's own ImageTk needs a live Tcl interpreter; TK 4K only needs the pixels. The porter rewrites
`from PIL import ImageTk` to `from tk4k import ImageTk`; everything else from Pillow (Image, ImageDraw...) is untouched.
"""
from __future__ import annotations

from typing import Any

from ._image import PhotoImage as _Photo


class PhotoImage(_Photo):
    """ImageTk.PhotoImage(image) / (file=...) / (mode, size). `image` is a Pillow Image (any mode)."""

    def __init__(self, image: Any = None, size: Any = None, **kw: Any):
        if image is not None and not isinstance(image, str) and hasattr(image, "convert"):
            super().__init__(width=image.size[0], height=image.size[1])
            self.paste(image)
        elif isinstance(image, str) and size is not None:   # PhotoImage("RGB", (w, h))
            super().__init__(width=size[0], height=size[1])
        else:
            super().__init__(**kw)

    def paste(self, im: Any, box: Any = None) -> None:
        rgba = im.convert("RGBA")
        if rgba.size != (self.w, self.h):
            self.w, self.h = rgba.size
        self.px = rgba.tobytes()
        self._dirty = True

    def _PhotoImage__photo(self):  # some programs reach for the inner tkinter image
        return self


BitmapImage = PhotoImage


def getimage(photo: Any):
    """ImageTk.getimage(photo) -> a Pillow image of the pixels."""
    from PIL import Image
    return Image.frombytes("RGBA", (photo.w, photo.h), bytes(photo.px))
