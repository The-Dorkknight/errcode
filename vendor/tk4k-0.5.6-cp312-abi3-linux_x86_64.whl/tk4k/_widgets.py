"""Widgets and layout containers.

The widget tree is retained (plain Python objects you can change at any time); drawing is
immediate underneath. Callbacks never run while a frame is being drawn: they are queued and
run right after, so it is always safe to add, remove or change widgets inside a callback.
"""
from __future__ import annotations

import itertools
from typing import Any, Callable, Optional

from . import _core

_ids = itertools.count(1)
_anim_ms = 0  # a widget sets this while drawing if it needs another frame soon (e.g. busy bar)
_stack: list["Container"] = []  # containers currently open with `with`


class Var:
    """A value that widgets can share (like Tk's StringVar/IntVar/BooleanVar in one).

    Changing it from any thread wakes the window; use Window.post() if you also touch widgets.
    """

    def __init__(self, value: Any = None):
        self._v = value
        self._traces: list[Callable[[Any], None]] = []

    def get(self) -> Any:
        return self._v

    def initialize(self, value: Any) -> None:
        self.set(value)

    def set(self, value: Any) -> None:
        if value == self._v:
            return
        self._v = value
        for fn in list(self._traces):
            _queue(fn, value)
        _core.wake()

    value = property(get, set)

    def trace(self, *args: Any):
        """trace(fn): fn(new_value) on every change (TK 4K's own form, usable as a decorator).
        trace("w", cb): tkinter's old form, same as trace_add("write", cb); cb(name, index, mode)."""
        if len(args) == 1:
            self._traces.append(args[0])
            return args[0]
        return self.trace_add(*args[:2])

    def trace_add(self, mode: Any, cb: Callable) -> str:
        """tkinter's var.trace_add("write", cb): cb is called as cb(name, index, mode). Only writes are traced."""
        modes = mode if isinstance(mode, (list, tuple)) else [mode]
        tid = "trace%d" % (len(self.__dict__.setdefault("_tids", {})) + 1)
        if any(m in ("write", "w") for m in modes):
            fn = lambda _v, f=cb: f(self.__dict__.get("_name", "PY_VAR"), "", "write")  # noqa: E731
            self._traces.append(fn)
            self.__dict__["_tids"][tid] = (cb, fn)
        return tid

    trace_variable = lambda self, mode, cb: self.trace_add(mode, cb)  # noqa: E731

    def trace_info(self) -> list:
        """tkinter's var.trace_info(): [(('write',), callback_name), ...]; only write traces exist here."""
        return [(("write",), tid) for tid in self.__dict__.get("_tids", {})]

    trace_vinfo = trace_info

    def trace_remove(self, mode: Any = None, cbname: Any = None) -> None:
        """Stop a trace by the id trace_add returned, or by the callback itself."""
        for tid, (cb, fn) in list(self.__dict__.get("_tids", {}).items()):
            if cbname in (tid, cb):
                self.__dict__["_tids"].pop(tid)
                if fn in self._traces:
                    self._traces.remove(fn)

    trace_vdelete = trace_remove

    def untrace(self, fn: Callable[[Any], None]) -> None:
        if fn in self._traces:
            self._traces.remove(fn)

    def __repr__(self) -> str:
        return f"Var({self._v!r})"


_callbacks: list[tuple[Callable, tuple]] = []


def _queue(fn: Optional[Callable], *args: Any) -> None:
    if fn is not None:
        _callbacks.append((fn, args))


def _take_callbacks() -> list[tuple[Callable, tuple]]:
    global _callbacks
    out, _callbacks = _callbacks, []
    return out


_ALIAS = {"background": "bg", "foreground": "fg", "borderwidth": "bd"}
# what tkinter's cget answers for an option the program never set (the classic Tk look)
_CGET_DEFAULT = {"bg": "#d9d9d9", "fg": "black", "relief": "flat", "bd": "0", "text": "", "anchor": "center", "justify": "left",
                 "padx": "1", "pady": "1", "cursor": "", "takefocus": "", "font": "TkDefaultFont", "image": "", "command": "",
                 "textvariable": "", "show": "", "wrap": "none", "width": "0", "height": "0", "highlightthickness": "1"}


class Widget:
    """Base class. Create inside a `with Column():` block, or pass parent=."""

    def __init__(self, parent: Optional["Container"] = None, *, width: Optional[float] = None,
                 visible: bool = True, enabled: bool = True, name: Optional[str] = None):
        self._id = next(_ids)
        if name:
            self._wname = str(name)
        if parent is None and not _stack:  # tkinter: master=None means the default root (the newest window)
            from ._window import _current
            parent = _current[-1] if _current else None
        self.master: Optional[Container] = parent if parent is not None else (_stack[-1] if _stack else None)
        if self.master is not None and not hasattr(self.master, "_children"):
            self.master = None  # e.g. parent is a Placeholder or a Menu: nothing to attach to
        if self.master is not None:
            self.master._children.append(self)
        self.width = width
        self._visible = visible
        self._enabled = enabled
        self._rect = (0.0, 0.0, 0.0, 0.0)
        self.hovered = False

    # The container, as .master (tkinter's name, used inside TK 4K) and .parent. Tree replaces .parent with
    # tkinter's Treeview.parent(iid) method, so library code must use .master.
    parent = property(lambda s: s.master, lambda s, v: setattr(s, "master", v))

    # --- common properties; every setter wakes the window so it redraws
    visible = property(lambda s: s._visible, lambda s, v: s._set("_visible", v))
    enabled = property(lambda s: s._enabled, lambda s, v: s._set("_enabled", v))

    def _set(self, name: str, value: Any) -> None:
        if getattr(self, name) != value:
            setattr(self, name, value)
            _core.wake()

    def destroy(self) -> None:
        fn = self.__dict__.get("_mbinds", {}).get("destroy")
        if fn is not None:
            _queue(fn, _Event(self, type="Destroy"))
        if self.master is not None and self in self.master._children:
            self.master._children.remove(self)
        self.master = None
        _core.wake()

    @property
    def rect(self) -> tuple[float, float, float, float]:
        """(x, y, w, h) from the last frame, in window points."""
        return self._rect

    # --- drawing
    def _in_row(self) -> bool:
        return isinstance(self.master, Row)

    def _auto_width(self, row_default: float = 200.0) -> float:
        if self.width is not None:
            return self.width
        g = getattr(self, "_grid", None)
        if g is not None:  # in a grid cell an Entry has Tk's natural width (20 characters) unless it is sticky e+w
            st = str(g.get("sticky", "")).lower()
            return -1.0 if ("e" in st and "w" in st) else 170.0
        return row_default if self._in_row() else -1.0  # -1 = fill the available width

    def _render(self) -> None:
        if not self._visible:
            return
        _core.push_id(str(self._id))
        if not self._enabled:
            _core.begin_disabled(True)
        try:
            self._draw()
            self._rect = _core.item_rect()
            was, self.hovered = self.hovered, _core.item_hovered()
            mb = self.__dict__.get("_mbinds")
            if mb:
                self._fire_generic(mb, was)
        finally:
            if not self._enabled:
                _core.end_disabled()
            _core.pop_id()

    def _draw(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def _fire_generic(self, mb: dict, was: bool) -> None:
        """<Enter>/<Leave>/<Button-3>/<Double-Button-1>/<MouseWheel>/<Configure>/<FocusIn>/<B1-Motion>/... on any widget."""
        x, y, w, h = self._rect
        hov = self.hovered
        d = self.__dict__
        if "map" in mb and not d.get("_mapped"):
            d["_mapped"] = True
            _queue(mb["map"], _Event(self, type="Map"))
        if "focusin" in mb or "focusout" in mb:
            foc = _core.item_focused()
            if foc != d.get("_focused", False):
                d["_focused"] = foc
                fn = mb.get("focusin" if foc else "focusout")
                if fn is not None:
                    _queue(fn, _Event(self, type="FocusIn" if foc else "FocusOut"))
        if "conf" in mb and (int(w), int(h)) != self.__dict__.get("_lastwh"):
            self.__dict__["_lastwh"] = (int(w), int(h))
            _queue(mb["conf"], _Event(self, width=int(w), height=int(h), type="Configure"))
        if hov != was:
            fn = mb.get("enter" if hov else "leave")
            if fn is not None:
                _queue(fn, _Event(self, type="Enter" if hov else "Leave"))
        mx, my, _d, pressed, _r, dbl, ctrl, shift = _core.mouse_state()
        right, middle, wheel, released, r3, r2, down, moved = _core.mouse_extra()
        ev = dict(x=int(mx - x), y=int(my - y), x_root=int(mx), y_root=int(my), state=(4 if ctrl else 0) | (1 if shift else 0))
        if hov and pressed:
            d["_grab"] = True          # a drag that starts here keeps coming here, as in tkinter
        grab = d.get("_grab")
        if grab and down and moved:
            for key in ("drag", "cdrag") if ctrl else ("drag",):
                if key in mb:
                    _queue(mb[key], _Event(self, **ev, num=1))
        if grab and released:
            d["_grab"] = False
            for key in (("r1", "cr1") if ctrl else ("r1",)):
                if key in mb:
                    _queue(mb[key], _Event(self, **ev, num=1))
        if not hov:
            return
        for key, hit, extra in (("b1", pressed and not ctrl and not shift, {"num": 1}),
                                ("cb1", pressed and ctrl, {"num": 1}), ("sb1", pressed and shift, {"num": 1}),
                                ("anyb", pressed or right or middle, {"num": 1 if pressed else 3 if right else 2}),
                                ("dbl", dbl, {"num": 1}),
                                ("b3", right, {"num": 3}), ("b2", middle, {"num": 2}),
                                ("r3", r3, {"num": 3}), ("r2", r2, {"num": 2}),
                                ("wheel", wheel != 0 and not ctrl, {"delta": int(wheel * 120)}),
                                ("cwheel", wheel != 0 and ctrl, {"delta": int(wheel * 120)}),
                                ("wheelup", wheel > 0, {"num": 4}), ("wheeldown", wheel < 0, {"num": 5})):
            if hit and key in mb:
                _queue(mb[key], _Event(self, **ev, **extra))
        if "motion" in mb and (int(mx), int(my)) != self.__dict__.get("_lastxy"):
            self.__dict__["_lastxy"] = (int(mx), int(my))
            _queue(mb["motion"], _Event(self, **ev))

    # ------------------------------------------------------------ tkinter compatibility (runtime)
    # Translated code that was not laid out statically keeps calling .pack()/.grid()/.config()/.bind() on its widgets.
    _CFG = {"text": "text", "textvariable": "_textvar", "command": "_command", "state": "_state", "value": "value",
            "variable": "_var", "onvalue": "onvalue", "offvalue": "offvalue", "fg": "color", "foreground": "color", "show": "_show", "values": "items",
            "image": "image"}

    def _reshow(self) -> None:
        if self.__dict__.pop("_forgot", False):  # pack()/grid() after pack_forget()/grid_remove() shows it again
            self.visible = True

    def pack(self, cnf=None, **kw):
        if isinstance(cnf, dict):   # tkinter: w.pack({"side": "left"}) as well as keywords
            kw = dict(cnf, **kw)
        self._pack = kw
        if "_pack_seq" not in self.__dict__:   # tkinter packs in the order of the pack() calls, not of creation
            self.__dict__["_pack_seq"] = next(_ids)
        self._reshow()
        _compat_note("pack/grid/place options are used at run time only for side, fill, row and column")

    def grid(self, cnf=None, **kw):
        if isinstance(cnf, dict):   # tkinter: w.grid({"side": "left"}) as well as keywords
            kw = dict(cnf, **kw)
        if kw or not hasattr(self, "_grid"):  # grid() with no options after grid_remove() keeps the old cell
            self._grid = kw
        self._reshow()
        _compat_note("pack/grid/place options are used at run time only for side, fill, row and column")

    def place(self, cnf=None, **kw):
        if isinstance(cnf, dict):
            kw = dict(cnf, **kw)
        if kw or not hasattr(self, "_place"):
            self._place = kw
        self._reshow()
        _compat_note("place() is not supported; the widget is laid out in creation order")

    place_configure = place

    def pack_forget(self):
        self.__dict__.pop("_pack_seq", None)
        self.__dict__["_forgot"] = True
        self.visible = False

    grid_forget = place_forget = grid_remove = pack_forget

    def pack_info(self):
        d = {"in": self.master, "anchor": "center", "expand": 0, "fill": "none", "side": "top",
             "ipadx": 0, "ipady": 0, "padx": 0, "pady": 0}
        d.update(self.__dict__.get("_pack") or {})
        return d

    def grid_info(self):
        g = self.__dict__.get("_grid") or {}
        d = {"in": self.master, "row": 0, "column": 0, "rowspan": 1, "columnspan": 1, "sticky": "",
             "ipadx": 0, "ipady": 0, "padx": 0, "pady": 0}
        d.update(g)
        return d

    def place_info(self):
        return dict(self.__dict__.get("_place") or {})

    def keys(self):
        return sorted(set(self._CFG) | {"relief", "bg", "font", "width", "height", "padx", "pady"})

    _CLASS_NAMES = {"Checkbox": "Checkbutton", "Slider": "Scale", "Progress": "Progressbar", "TextArea": "Text",
                    "Radio": "Radiobutton", "Tree": "Treeview", "Tabs": "Notebook", "Dropdown": "Combobox",
                    "Column": "Frame", "Row": "Frame", "Grid": "Frame", "Window": "Tk", "Dialog": "Toplevel",
                    "Table": "Treeview", "Placeholder": "Frame"}

    def winfo_class(self):
        n = type(self).__name__
        for k in type(self).__mro__:
            if k.__name__ in self._CLASS_NAMES:
                return self._CLASS_NAMES[k.__name__]
        return n

    def winfo_name(self):
        return self.__dict__.get("_wname") or "!%s%s" % (type(self).__name__.lower(), self._id)

    # ttk's widget state flags: only "disabled" means anything here
    def state(self, spec=None):
        if spec is None:
            return () if self.enabled else ("disabled",)
        for f in (spec if isinstance(spec, (list, tuple)) else str(spec).split()):
            if f == "disabled":
                self.enabled = False
            elif f == "!disabled":
                self.enabled = True
        return ()

    def instate(self, spec, callback=None):
        ok = True
        for f in (spec if isinstance(spec, (list, tuple)) else str(spec).split()):
            if f.lstrip("!") == "disabled":
                ok = ok and ((not self.enabled) if not f.startswith("!") else self.enabled)
        return bool(callback() if (ok and callback) else ok)

    def flash(self):
        pass

    def invoke(self):
        pass

    def bindtags(self, tags=None):
        if tags is not None:
            return None
        return (str(self.winfo_name()), self.winfo_class(), ".", "all")

    def nametowidget(self, name):
        if name in (".", ""):
            return self._win()
        if not isinstance(name, str):
            return name
        w = self._win()
        for part in [p for p in name.split(".") if p]:
            nxt = next((c for c in getattr(w, "_children", []) if c.winfo_name() == part), None)
            if nxt is None:
                from ._dialogs import TclError
                raise TclError('bad window path name "%s"' % name)
            w = nxt
        return w

    def option_get(self, name, cls):
        return ""

    def clipboard_clear(self, **kw):
        set_clipboard("")

    def clipboard_append(self, string, **kw):
        set_clipboard(get_clipboard() + str(string))

    def clipboard_get(self, **kw):
        t = get_clipboard()
        if not t:
            from ._dialogs import TclError
            raise TclError("CLIPBOARD selection doesn't exist or form \"STRING\" not defined")
        return t

    def wait_variable(self, name=None):
        """Wait (pumping events) until the Var is written; blocking-dialog style code works as in tkinter."""
        hit = [False]
        fn = lambda _v: hit.__setitem__(0, True)  # noqa: E731
        name._traces.append(fn)
        try:
            win = self._win()
            if win is not None:
                win._wait_until(lambda: hit[0])
        finally:
            if fn in name._traces:
                name._traces.remove(fn)

    waitvar = wait_variable

    def wait_visibility(self, *a):
        pass

    def config(self, cnf=None, **kw):
        if isinstance(cnf, str) and not kw:  # widget.configure("text") -> (name, dbName, dbClass, default, value)
            return (cnf, cnf, cnf.title(), "", self.cget(cnf))
        kw = dict(cnf if isinstance(cnf, dict) else {}, **kw)
        for k, v in kw.items():
            tgt = self._CFG.get(k)
            if tgt == "_textvar":
                self.var = v if isinstance(v, Var) else self.var
                if hasattr(self, "text") and not isinstance(getattr(type(self), "text", None), property):
                    self.text = v
            elif tgt == "_command":
                if hasattr(self, "on_click"):
                    self.on_click = v
                else:
                    self.on_change = (lambda _v, f=v: f()) if v else None
            elif tgt == "_state":
                self.enabled = v != "disabled"
            elif tgt == "_var":
                self.var = v
            elif tgt == "_show":
                self.password = bool(v)
            elif tgt:
                setattr(self, tgt, v)
            else:   # cosmetic: the theme decides, but cget() reads it back like tkinter
                self.__dict__.setdefault("_cosm", {})[_ALIAS.get(k, k)] = v
        _core.wake()

    configure = config

    def cget(self, key):
        key = str(key).lstrip("-")
        if key == "state":
            return "normal" if getattr(self, "enabled", True) else "disabled"
        k2 = _ALIAS.get(key, key)
        if k2 in self.__dict__.get("_cosm", {}):
            return self.__dict__["_cosm"][k2]
        tgt = self._CFG.get(key, key)
        v = getattr(self, tgt, None)
        return _CGET_DEFAULT.get(k2, v) if v is None else v

    def __getitem__(self, key):
        return self.cget(key)

    def __setitem__(self, key, value):
        self.config(**{key: value})

    def bind(self, seq, fn=None, add=None):
        """Entry: <Return> -> on_submit, <Key>/<KeyRelease>/<<Modified>> -> on_change; others are noted and ignored."""
        s = str(seq)
        if fn is None:
            return None
        if s in ("<Return>", "<KP_Enter>") and hasattr(self, "on_submit"):
            self.on_submit = lambda _t, f=fn: f(_Event(self))
        elif s in ("<Key>", "<KeyRelease>", "<KeyPress>", "<<Modified>>") and hasattr(self, "on_change"):
            self.on_change = lambda _t, f=fn: f(_Event(self))
        elif s in ("<Button-1>", "<ButtonRelease-1>", "<1>") and hasattr(self, "on_click"):
            self.on_click = lambda f=fn: f(_Event(self))
        elif s.startswith("<<"):
            self.__dict__.setdefault("_vbinds", {})[s] = fn
        elif s in _GENERIC:
            self.__dict__.setdefault("_mbinds", {})[_GENERIC[s]] = fn
        elif _is_key_seq(s) and self._win() is not None and self._win() is not self:
            # tkinter delivers keys to the widget with focus; TK 4K delivers them window-wide (games bind keys on
            # their canvas after focus_set(), which then works the same)
            self._win().bind(s, fn, add)
            _compat_note("key bindings on a widget fire for the whole window in TK 4K")
        else:
            _compat_note(f"bind({s}) on a {type(self).__name__} is not supported yet")
        return None

    def event_generate(self, seq, *_a, **kw):
        fn = self.__dict__.get("_vbinds", {}).get(str(seq))
        if fn is not None:
            _queue(fn, _Event(self))
        elif not str(seq).startswith("<<"):
            _compat_note(f"event_generate({seq}): only <<virtual>> events are delivered")

    def focus_set(self):
        pass

    def _noop(self, *a, **k):
        pass

    focus = focus_force = lift = lower = update = update_idletasks = columnconfigure = rowconfigure = \
        grid_columnconfigure = grid_rowconfigure = pack_propagate = grid_propagate = tkraise = _noop

    # Scrollbar wiring (`sb.config(command=t.yview)`, `t.config(yscrollcommand=sb.set)`): TK 4K widgets scroll
    # themselves, so these are accepted everywhere and do nothing. (Tree/Listbox keep their own.)
    def yview(self, *a, **k):
        return (0.0, 1.0)

    xview = yview_moveto = xview_moveto = yview_scroll = xview_scroll = scan_mark = scan_dragto = yview

    # --- methods tkinter puts on every widget; most go to the window
    def _win(self):
        from ._window import _current
        return _current[-1] if _current else None

    def bind_all(self, seq, fn=None, add=None):
        win = self._win()
        if win is not None:
            win.bind(seq, fn, add)

    bind_class = lambda self, cls, seq=None, fn=None, add=None: self.bind_all(seq, fn, add)  # noqa: E731

    def unbind(self, seq, funcid=None):
        self.__dict__.get("_vbinds", {}).pop(str(seq), None)
        if str(seq) in _GENERIC:
            self.__dict__.get("_mbinds", {}).pop(_GENERIC[str(seq)], None)

    unbind_all = unbind

    def after(self, ms, fn=None, *args):
        win = self._win()
        return win.after(ms, fn, *args) if win is not None and fn is not None else None

    def after_idle(self, fn, *args):
        win = self._win()
        return win.after_idle(fn, *args) if win is not None else None

    def after_cancel(self, tid):
        win = self._win()
        if win is not None:
            win.after_cancel(tid)

    def winfo_width(self):
        return int(self._rect[2])

    def winfo_height(self):
        return int(self._rect[3])

    winfo_reqwidth, winfo_reqheight = winfo_width, winfo_height

    def winfo_x(self):
        return int(self._rect[0])

    def winfo_y(self):
        return int(self._rect[1])

    winfo_rootx, winfo_rooty = winfo_x, winfo_y

    def winfo_exists(self):
        return int(self.master is not None or True)

    def winfo_toplevel(self):
        return self._win()

    def winfo_children(self):
        return list(getattr(self, "_children", []))

    def winfo_ismapped(self):
        return int(self._visible)

    winfo_viewable = winfo_ismapped

    def focus_get(self):
        return None

    def grab_set(self):
        pass

    grab_release = grab_set

    def register(self, fn, *a):
        """root.register(fn) -> a name tkinter would put in validatecommand; here the callable itself."""
        return fn

    def add(self, child=None, **_):
        """PanedWindow.add(child, weight=...): the child is already inside this container."""

    # ---- 0.5.5: the tkinter methods real programs call most that TK 4K lacked (ranked by use in ~1,700 files).
    # Anything else tkinter has goes to the safety net in _compat.missing (a logged no-op, never an AttributeError).
    def __getattr__(self, name):
        from ._compat import missing
        return missing(self, name)

    def bell(self, *a, **k):
        pass  # no sound: a beep is never essential, and it must not stop the program

    def getboolean(self, s):
        if isinstance(s, str):
            v = s.strip().lower()
            if v in ("1", "true", "yes", "on"):
                return True
            if v in ("0", "false", "no", "off"):
                return False
            from ._dialogs import TclError
            raise TclError(f'expected boolean value but got "{s}"')
        return bool(s)

    def getint(self, s):
        try:
            return int(s)
        except (TypeError, ValueError):
            try:
                return int(str(s), 0)
            except ValueError:
                from ._dialogs import TclError
                raise TclError(f'expected integer but got "{s}"') from None

    def getdouble(self, s):
        try:
            return float(s)
        except (TypeError, ValueError):
            from ._dialogs import TclError
            raise TclError(f'expected floating-point number but got "{s}"') from None

    def setvar(self, name="PY_VAR", value="1"):
        _tclvars[str(name)] = value

    def getvar(self, name="PY_VAR"):
        n = str(name)
        if n not in _tclvars:
            from ._dialogs import TclError
            raise TclError(f'can\'t read "{n}": no such variable')
        return _tclvars[n]

    # winfo_*: answered from what TK 4K knows (the last frame's rectangle, the window, the mouse)
    def winfo_id(self):
        return self._id

    def winfo_pathname(self, ident=None, displayof=0):
        names, w = [], self
        while w is not None and w.master is not None:
            names.append(w.winfo_name())
            w = w.master
        return "." + ".".join(reversed(names))

    def winfo_parent(self):
        return self.master.winfo_pathname() if self.master is not None else ""

    def winfo_manager(self):
        d = self.__dict__
        return "place" if d.get("_place") else "grid" if d.get("_grid") else "pack" if self.master is not None else ""

    def winfo_geometry(self):
        x, y, w, h = self._rect
        return f"{int(w)}x{int(h)}+{int(x)}+{int(y)}"

    def winfo_rgb(self, color):
        rgb = _rgb_name(color)
        if rgb is None:
            from ._dialogs import TclError
            raise TclError(f'unknown color name "{color}"')
        return tuple(int(round(float(v) * 65535)) for v in rgb[:3])

    def winfo_fpixels(self, number):
        s = str(number).strip()
        unit = {"c": 72 / 2.54, "m": 72 / 25.4, "i": 72.0, "p": 1.0}.get(s[-1:], None)
        return float(s[:-1]) * unit if unit else float(s)

    def winfo_pixels(self, number):
        return int(round(self.winfo_fpixels(number)))

    def winfo_pointerxy(self):
        try:
            m = _core.mouse_state()
            return (int(m[0]), int(m[1]))
        except Exception:
            return (0, 0)

    winfo_pointerx = lambda self: self.winfo_pointerxy()[0]  # noqa: E731
    winfo_pointery = lambda self: self.winfo_pointerxy()[1]  # noqa: E731

    def winfo_screenwidth(self):
        w = self._win()
        return w.winfo_screenwidth() if w is not None and w is not self else 1920

    def winfo_screenheight(self):
        w = self._win()
        return w.winfo_screenheight() if w is not None and w is not self else 1080

    winfo_vrootwidth, winfo_vrootheight = winfo_screenwidth, winfo_screenheight
    winfo_vrootx = winfo_vrooty = lambda self: 0  # noqa: E731
    winfo_depth = winfo_screendepth = lambda self: 24  # noqa: E731
    winfo_containing = lambda self, x=0, y=0, displayof=0: None  # noqa: E731
    winfo_screen = lambda self: ":0"  # noqa: E731

    def winfo_viewable(self):
        return int(self._visible)

    # virtual events: event_add("<<Paste>>", "<Control-v>") binds the keys on the window to fire the virtual event
    def event_add(self, virtual, *sequences):
        vmap = _virtual_events.setdefault(str(virtual), [])
        win = self._win()
        for seq in sequences:
            if seq not in vmap:
                vmap.append(seq)
                if win is not None and str(seq).startswith("<") and not str(seq).startswith("<<"):
                    win.bind(seq, lambda e, v=str(virtual), w=win: _fire_virtual(w, v))

    def event_delete(self, virtual, *sequences):
        if sequences:
            _virtual_events[str(virtual)] = [x for x in _virtual_events.get(str(virtual), []) if x not in sequences]
        else:
            _virtual_events.pop(str(virtual), None)

    def event_info(self, virtual=None):
        if virtual is None:
            return tuple(_virtual_events)
        return tuple(_virtual_events.get(str(virtual), ()))

    def unbind_class(self, cls, seq):
        pass

    def tk_focusNext(self):
        return self

    tk_focusPrev = tk_focusNext
    focus_lastfor = focus_displayof = lambda self, *a: None  # noqa: E731

    def tk_setPalette(self, *a, **k):
        _compat_note("tk_setPalette/tk_bisque: TK 4K's theme decides the colours (try set_theme)")

    tk_bisque = tk_setPalette
    tk_strictMotif = tk_focusFollowsMouse = lambda self, *a: None  # noqa: E731

    def option_add(self, pattern, value, priority=None):
        w = self._win()
        if w is not None and w is not self:
            w.option_add(pattern, value, priority)

    option_clear = option_readfile = lambda self, *a, **k: None  # noqa: E731
    image_names = lambda self: ()  # noqa: E731
    image_types = lambda self: ("photo",)  # noqa: E731
    info_patchlevel = lambda self: "8.6.13"  # noqa: E731

    def selection_get(self, **kw):
        from ._dialogs import TclError
        raise TclError("PRIMARY selection doesn't exist or form \"STRING\" not defined")

    selection_clear = selection_handle = selection_own = lambda self, *a, **k: None  # noqa: E731
    selection_own_get = lambda self, *a, **k: None  # noqa: E731
    grab_current = lambda self: None  # noqa: E731
    grab_status = lambda self: ""  # noqa: E731
    grab_set_global = lambda self: None  # noqa: E731

    def wait_window(self, window=None):
        """Block (keep drawing) until `window` (default: this widget) is closed or destroyed, like tkinter."""
        w = window if window is not None else self
        win = self._win()
        if win is None or w is win:
            return
        win._wait_until(lambda: (getattr(w, "_open", True) is False) or (w.master is None and not hasattr(w, "_open")))

    def mainloop(self, n=0):
        w = self._win()
        if w is not None:
            w.mainloop()

    def quit(self):
        """Frame.quit() / self.quit in a Frame subclass: ends the main loop, as in tkinter."""
        w = self._win()
        if w is not None:
            w.quit()

    def propagate(self, flag=None):
        return 1 if flag is None else None

    anchor = grid_anchor = lambda self, anchor=None: None  # noqa: E731

    def grid_bbox(self, *a, **k):
        x, y, w, h = self._rect
        return (0, 0, int(w), int(h))

    def grid_location(self, x, y):
        return (0, 0)

    location = grid_location
    bbox = grid_bbox

    def forget(self):
        self.pack_forget()

    def pack_configure(self, **kw):
        return self.pack(**kw)

    def grid_configure(self, **kw):
        return self.grid(**kw)

    def info(self):
        return self.pack_info()

    def deletecommand(self, name):
        pass


class _Event:
    """What a tkinter callback receives. Mouse events fill x/y (relative to the widget), x_root/y_root, num, delta;
    <Configure> fills width/height."""
    def __init__(self, widget, **kw):
        self.widget, self.keysym, self.char, self.x, self.y = widget, "", "", 0, 0
        self.x_root = self.y_root = self.num = self.delta = self.width = self.height = self.state = 0
        self.keycode, self.type = 0, ""
        self.__dict__.update(kw)


_NOT_KEYS = {"Enter", "Leave", "Configure", "Motion", "Destroy", "FocusIn", "FocusOut", "MouseWheel", "Map", "Unmap",
             "Visibility", "Expose", "Activate", "Deactivate"}


def _is_key_seq(s: str) -> bool:
    import re
    m = re.match(r"^<(?:(?:Control|Alt|Shift|Meta|Command|Option|Lock)-)*(?:(?:Key|KeyPress|KeyRelease)-)?([A-Za-z0-9_]+)>$", s)
    return bool(m) and m.group(1) not in _NOT_KEYS and not m.group(1).startswith(("Button", "B1", "B2", "B3", "Double"))\
        and not m.group(1).isdigit()


# Mouse/window sequences any widget can bind (checked after the widget is drawn, see Widget._render)
_GENERIC = {"<Enter>": "enter", "<Leave>": "leave", "<Button-3>": "b3", "<ButtonPress-3>": "b3", "<3>": "b3",
            "<Button-2>": "b2", "<ButtonPress-2>": "b2", "<2>": "b2", "<Double-Button-1>": "dbl", "<Double-1>": "dbl",
            "<Double-ButtonRelease-1>": "dbl", "<MouseWheel>": "wheel", "<Shift-MouseWheel>": "wheel",
            "<Control-MouseWheel>": "cwheel", "<Button-4>": "wheelup", "<4>": "wheelup", "<Button-5>": "wheeldown",
            "<5>": "wheeldown", "<Configure>": "conf", "<Button-1>": "b1", "<ButtonPress-1>": "b1", "<1>": "b1",
            "<ButtonPress>": "anyb", "<Button>": "anyb", "<ButtonRelease-1>": "r1", "<ButtonRelease-3>": "r3",
            "<ButtonRelease-2>": "r2", "<ButtonRelease>": "r1", "<Motion>": "motion", "<B1-Motion>": "drag",
            "<Control-Button-1>": "cb1", "<Control-1>": "cb1", "<Shift-Button-1>": "sb1", "<Shift-1>": "sb1",
            "<Control-ButtonRelease-1>": "cr1", "<Control-B1-Motion>": "cdrag",
            "<FocusIn>": "focusin", "<FocusOut>": "focusout", "<Map>": "map", "<Visibility>": "map", "<Expose>": "map",
            "<Destroy>": "destroy", "<Unmap>": "unmap"}


_compat_seen: set = set()


_tclvars: dict = {}          # setvar/getvar: Tcl's global variables, kept here instead
_virtual_events: dict = {}   # event_add("<<Name>>", "<Control-x>", ...)


def _fire_virtual(win, virtual: str) -> None:
    """Deliver a virtual event to every widget in `win` that bound it (and to the window itself)."""
    todo = [win]
    while todo:
        w = todo.pop()
        fn = w.__dict__.get("_vbinds", {}).get(virtual)
        if fn is not None:
            _queue(fn, _Event(w))
        todo.extend(getattr(w, "_children", []))
    fn = getattr(win, "_binds", {}).get(virtual)
    if fn is not None:
        _queue(fn, _Event(win))


def _compat_note(msg: str) -> None:
    if msg in _compat_seen:
        return
    _compat_seen.add(msg)
    try:
        from . import _alerts
        _alerts.note("todo", msg[:60], once_key="compat:" + msg)
    except Exception:
        pass


class _SizeAttr:
    """`size` is the window/dialog size, but real code often keeps its own `self.size = tk.StringVar()` on a Tk or
    Toplevel subclass. Numbers go to the real size; anything else is the program's own attribute and is left alone."""

    @property
    def size(self):
        return self.__dict__.get("_user_size", self._size)

    @size.setter
    def size(self, v):
        if isinstance(v, (tuple, list)) and len(v) == 2 and all(isinstance(x, (int, float)) for x in v):
            self._size = (v[0], v[1])
            self.__dict__.pop("_user_size", None)
        else:
            self.__dict__["_user_size"] = v


def _with_options(w: Any, opts: Any) -> Any:
    """What `tk.Label(parent, **options)` becomes: build the widget, then apply the options like .config() does."""
    try:
        nm = dict(opts).get("name")
        if nm and hasattr(w, "__dict__"):
            w.__dict__["_wname"] = str(nm)
        opts = {k: v for k, v in dict(opts).items() if k not in ("master", "parent", "name", "cnf")}
    except (TypeError, ValueError):
        opts = {}
    if opts and hasattr(w, "config"):
        w.config(**opts)
    return w


def _val(x: Any) -> Any:
    return x.get() if isinstance(x, Var) else x


def _rgb(c: Any) -> tuple[float, float, float]:
    """'#rrggbb' or (r, g, b) in 0..1 or 0..255 -> floats 0..1."""
    if isinstance(c, str):
        raw = c.strip().lower()
        h = _NAMED.get(raw.replace(" ", ""), raw).lstrip("#")  # a Tk colour name such as "black" or "lightgrey"
        if len(h) == 3:
            h = "".join(ch * 2 for ch in h)
        try:
            return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))  # type: ignore[return-value]
        except ValueError:
            return (0.5, 0.5, 0.5)  # an unknown colour must not crash the window
    r, g, b = c[:3]
    return (r, g, b) if max(r, g, b) <= 1.0 else (r / 255.0, g / 255.0, b / 255.0)


def _draw_image(im: Any, text: str = "") -> bool:
    """A PhotoImage (and the text beside it, like tkinter's compound='left'). Returns True when clicked."""
    clicked = _core.image(im._handle(), float(im.w), float(im.h))
    if text:
        _core.same_line(0.0, -1.0)
        _core.text(text, False, False)
    return clicked


class Label(Widget):
    def __init__(self, text: Any = "", *, dim: bool = False, wrap: bool = False, color: Any = None,
                 image: Any = None, **kw):
        super().__init__(**kw)
        self.text, self.dim, self.wrap, self.color, self.image = text, dim, wrap, color, image

    def _draw(self) -> None:
        s = str(_val(self.text))
        if self.image is not None:
            _draw_image(self.image, s)
            return
        if self.color is not None:
            _core.text_colored(s, *_rgb(self.color), self.wrap)
        elif self.wrap:
            _core.text_wrapped(s, self.dim)
        else:  # in a Row or Grid, sit level with the framed widgets next to it
            _core.text(s, self.dim, isinstance(self.master, (Row, Grid)))


class Button(Widget):
    def __init__(self, text: str = "Button", on_click: Optional[Callable[[], None]] = None, *,
                 primary: bool = False, height: float = 0.0, image: Any = None, **kw):
        super().__init__(**kw)
        self.text, self.on_click, self.primary, self.height, self.image = text, on_click, primary, height, image
        self.clicks = 0

    def invoke(self) -> None:
        _queue(self.on_click)

    def _draw(self) -> None:
        if self.image is not None:
            if _draw_image(self.image, str(_val(self.text)) if self.text != "Button" else ""):
                self.clicks += 1
                _queue(self.on_click)
            return
        w = self.width if self.width is not None else 0.0
        if _core.button(str(_val(self.text)), w, self.height, self.primary):
            self.clicks += 1
            _queue(self.on_click)


class Entry(Widget):
    """Single-line text box. Bind it to a Var, or read/write .text."""

    def __init__(self, text: str = "", *, var: Optional[Var] = None, hint: str = "",
                 password: bool = False, readonly: bool = False,
                 on_change: Optional[Callable[[str], None]] = None,
                 on_submit: Optional[Callable[[str], None]] = None, **kw):
        super().__init__(**kw)
        self.var = var if var is not None else Var(text)
        self.hint, self.password, self.readonly = hint, password, readonly
        self.on_change, self.on_submit = on_change, on_submit

    text = property(lambda s: s.var.get(), lambda s, v: s.var.set(v))

    def get(self) -> str:
        return str(self.var.get())

    def _ix(self, index: Any) -> int:
        n = len(str(self.var.get()))
        k = str(index)
        if k == "end":
            return n
        if k == "insert":
            return min(self.__dict__.get("_cursor", n), n)
        if k in ("sel.first", "sel.last"):
            a, b = self.__dict__.get("_sel", (0, 0))
            return a if k == "sel.first" else b
        try:
            return max(0, min(int(k), n))
        except ValueError:
            from ._dialogs import TclError
            raise TclError(f'bad entry index "{k}"') from None

    def index(self, index: Any) -> int:
        return self._ix(index)

    def icursor(self, index: Any) -> None:
        self.__dict__["_cursor"] = self._ix(index)

    def select_range(self, start: Any, end: Any) -> None:
        a, b = self._ix(start), self._ix(end)
        self.__dict__["_sel"] = (min(a, b), max(a, b))

    selection_range = select_range

    def selection_clear(self) -> None:
        self.__dict__["_sel"] = (0, 0)

    select_clear = selection_clear

    def selection_present(self) -> bool:
        a, b = self.__dict__.get("_sel", (0, 0))
        return a != b

    select_present = selection_present

    def select_from(self, index) -> None:
        self.__dict__["_sel_anchor"] = self._ix(index)

    selection_from = select_from

    def select_to(self, index) -> None:
        a = self.__dict__.get("_sel_anchor", 0)
        self.select_range(min(a, self._ix(index)), max(a, self._ix(index)))

    selection_to = select_adjust = selection_adjust = select_to

    def selection_get(self, **kw) -> str:
        a, b = self.__dict__.get("_sel", (0, 0))
        if a == b:
            from ._dialogs import TclError
            raise TclError("PRIMARY selection doesn't exist or form \"STRING\" not defined")
        return str(self.var.get())[a:b]

    def delete(self, first: Any = 0, last: Any = None) -> None:
        cur = str(self.var.get())
        a = self._ix(first)
        b = a + 1 if last is None else self._ix(last)
        self.var.set(cur[:a] + cur[b:] if b > a else cur)
        c = self.__dict__.get("_cursor")
        if c is not None and b > a and c > a:   # tkinter keeps the insert cursor on the same character
            self.__dict__["_cursor"] = max(a, c - (b - a))

    def insert(self, index: Any, text: Any) -> None:
        cur = str(self.var.get())
        i = self._ix(index)
        c = self._ix("insert")
        self.var.set(cur[:i] + str(text) + cur[i:])
        self.__dict__["_cursor"] = c + len(str(text)) if c >= i else c

    def _draw(self) -> None:
        changed, new = _core.input_text("##entry", str(self.var.get()), self.hint, self.password,
                                        self.readonly, self._auto_width())
        if changed:
            self.var._v = new  # already on screen; skip the extra wake
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)
        if self.on_submit is not None and _core.item_enter():
            _queue(self.on_submit, self.var.get())


class Checkbox(Widget):
    def __init__(self, text: str = "", *, var: Optional[Var] = None, checked: bool = False,
                 on_change: Optional[Callable[[bool], None]] = None, onvalue: Any = True, offvalue: Any = False, **kw):
        super().__init__(**kw)
        self.text, self.on_change = text, on_change
        self.onvalue, self.offvalue = onvalue, offvalue
        self.var = var if var is not None else Var(checked)

    # tkinter: ticked exactly when the variable equals onvalue (a StringVar holding "off" is not ticked)
    @property
    def checked(self) -> bool:
        v = self.var.get()
        return bool(v) if self.onvalue is True else v == self.onvalue

    @checked.setter
    def checked(self, v: Any) -> None:
        self.var.set(self.onvalue if v else self.offvalue)

    def get(self) -> bool:
        return self.checked

    def set(self, v: Any) -> None:
        self.checked = v

    def select(self) -> None:
        self.checked = True

    def deselect(self) -> None:
        self.checked = False

    def toggle(self) -> None:
        self.checked = not self.checked

    def invoke(self) -> None:
        self.toggle()
        _queue(self.on_change, self.checked)

    def _draw(self) -> None:
        changed, new = _core.checkbox(str(_val(self.text)), self.checked)
        if changed:
            self.var._v = self.onvalue if new else self.offvalue
            for fn in list(self.var._traces):
                _queue(fn, self.var._v)
            _queue(self.on_change, new)


class Slider(Widget):
    def __init__(self, lo: float = 0.0, hi: float = 1.0, *, var: Optional[Var] = None,
                 value: float = 0.0, fmt: Optional[str] = None,
                 on_change: Optional[Callable[[float], None]] = None, resolution: Optional[float] = None, **kw):
        super().__init__(**kw)
        if fmt is None:  # whole-number range -> whole-number display, like tkinter's Scale
            fmt = "%.0f" if float(lo).is_integer() and float(hi).is_integer() and hi - lo >= 2 else "%.2f"
        self.lo, self.hi, self.fmt, self.on_change = lo, hi, fmt, on_change
        self.resolution = None
        self.var = var if var is not None else Var(value)
        if resolution:
            self.config(resolution=resolution)

    def config(self, cnf=None, **kw):
        kw = dict(cnf if isinstance(cnf, dict) else {}, **kw)
        r = kw.pop("resolution", None)
        if r:  # tkinter Scale(resolution=0.5): values snap to multiples of it, shown with matching decimals
            self.resolution = float(r)
            dec = max(0, len(("%g" % float(r)).partition(".")[2]))
            self.fmt = "%.0f" if dec == 0 else "%%.%df" % dec
        super().config(**kw)

    configure = config

    value = property(lambda s: s.var.get(), lambda s, v: s.var.set(v))

    def get(self) -> float:
        return self.var.get()

    def set(self, v: Any) -> None:
        a, b = min(self.lo, self.hi), max(self.lo, self.hi)
        self.var.set(self._snap(min(b, max(a, float(v)))))

    def _snap(self, v: Any) -> Any:
        r = self.resolution
        if not r:
            return v
        import math
        x = math.floor(float(v) / r + 0.5) * r        # round half up like Tk, not to even
        return int(x) if float(r).is_integer() else round(x, 10)

    def _draw(self) -> None:
        changed, new = _core.slider("##slider", float(self.var.get()), self.lo, self.hi, self.fmt,
                                    self._auto_width())
        if changed:
            new = self._snap(new)
            self.var._v = new
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)


class Progress(Widget):
    """0..1 progress bar. Pass value=None for 'working, unknown length' (a moving bar)."""

    def __init__(self, value: Any = 0.0, *, text: str = "", height: float = 22.0, maximum: float = 1.0,
                 mode: str = "determinate", **kw):
        super().__init__(**kw)
        self.maximum = float(maximum) if maximum else 1.0
        self.value = value if (value is None or isinstance(value, Var) or self.maximum == 1.0) else float(value) / self.maximum
        self.text, self.height = text, height
        self.mode = mode
        if mode == "indeterminate":  # tkinter: sits still until start() is called
            self.value = 0.0
        self._busy = False

    def start(self, interval: Any = None) -> None:
        """ttk Progressbar.start(): an indeterminate bar sweeps until stop()."""
        self._busy = True
        self.__dict__["_saved"] = self.value
        self.value = None
        _core.wake()

    def stop(self) -> None:
        if self._busy:
            self._busy = False
            self.value = 0.0
            _core.wake()

    def config(self, cnf=None, **kw):  # tkinter: config(value=40, maximum=200); value is in maximum units
        kw = dict(cnf or {}, **kw)
        if "maximum" in kw:
            self.maximum = float(kw.pop("maximum")) or 1.0
        if "mode" in kw:
            self.mode = kw.pop("mode")
        if "value" in kw:
            v = kw.pop("value")
            self.value = None if v is None else float(v) / self.maximum
        super().config(**kw)
        _core.wake()

    configure = config

    def cget(self, key):
        if key == "value":
            return (self.value or 0.0) * self.maximum
        return super().cget(key)

    def step(self, amount: float = 1.0) -> None:
        self.value = min(1.0, (self.value or 0.0) + amount / self.maximum)
        _core.wake()

    def _draw(self) -> None:
        v = _val(self.value)
        if v is None:  # unknown length: a sweeping bar driven by the clock
            import time
            v = (time.monotonic() * 0.6) % 1.0
            global _anim_ms
            _anim_ms = 50  # ask the window for another frame in ~50 ms; no frames at all otherwise
        _core.progress(max(0.0, min(1.0, float(v))), self.text, self._auto_width(), self.height)


class Separator(Widget):
    def _draw(self) -> None:
        _core.separator()


class Placeholder(Widget):
    """Stands in for a tkinter widget TK 4K does not have yet, so a translated app still runs.

    It shows as a greyed-out box naming the missing widget, answers `.get()` with a harmless default,
    and swallows any other call (`insert`, `config`, `yview` ...) after recording it in the log, in the
    exit footer and in the QR error report. `visible=False` keeps it out of the layout (a Menu, say).
    """

    def __init__(self, kind: str = "widget", *, name: str = "", default: Any = "", line: int = 0, **kw):
        super().__init__(**kw)
        object.__setattr__(self, "_info", (kind, name, line))
        self.text = self.value = self._default = default
        from . import _alerts
        _alerts.note("placeholder", f"{kind}{' ' + repr(name) if name else ''} is not in TK 4K yet", line)

    def get(self, *args: Any) -> Any:
        return self._default

    def set(self, value: Any) -> None:
        self.text = self.value = self._default = value

    def __getattr__(self, attr: str):
        # only public method-like names; private/dunder lookups must still fail normally
        if attr.startswith("_"):
            raise AttributeError(attr)
        kind, name, line = self._info

        def swallow(*a: Any, **k: Any):
            from . import _alerts
            _alerts.note("unsupported", f"{name or kind}.{attr}() ignored (placeholder for {kind})", line)
            return _Null()
        return swallow

    def __setitem__(self, key: Any, value: Any) -> None:
        self.__getattr__("config")(**{str(key): value})

    def __getitem__(self, key: Any):
        self.__getattr__("cget")(key)
        return self._default

    def _draw(self) -> None:
        kind, name, _ = self._info
        _core.begin_disabled(True)
        _core.button(f"{kind}{' ' + name if name else ''}: not in TK 4K yet")
        _core.end_disabled()


class _Null:
    """Harmless stand-in returned by skipped calls: any attribute, call or index gives another _Null."""

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return self

    def __call__(self, *a, **k):
        return self

    def __getitem__(self, k):
        return self

    def __setitem__(self, k, v):
        pass

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return False

    def __len__(self):
        return 0

    def __repr__(self):
        return "<skipped tkinter call>"


def unsupported(what: str, line: int = 0) -> _Null:
    """Called by translated code in place of a tkinter call TK 4K cannot do yet.

    Records it (log, exit footer, QR report) and returns a null object so the program carries on.
    """
    from . import _alerts
    _alerts.note("unsupported", what, line)
    return _Null()


class Spacer(Widget):
    def __init__(self, height: float = 8.0, **kw):
        super().__init__(**kw)
        self.height = height

    def _draw(self) -> None:
        _core.spacing()


# ------------------------------------------------------------------ containers
def _fill(w, sticky: bool = False) -> None:
    opt = getattr(w, "_pack", None) or getattr(w, "_grid", None) or {}
    f = str(opt.get("fill", "")) or ""
    st = str(opt.get("sticky", "")) if sticky else ""
    if f in ("x", "both") or ("e" in st and "w" in st):
        _core.set_next_width(-1.0)


class Container(Widget):
    def __init__(self, parent: Optional["Container"] = None, **kw):
        super().__init__(parent, **kw)
        self._children: list[Widget] = []

    def __enter__(self):
        _stack.append(self)
        return self

    def __exit__(self, *exc):
        _stack.pop()
        return False

    def clear(self) -> None:
        self._children.clear()
        _core.wake()

    # tkinter's geometry-manager queries, answered from what was passed to pack()/grid()/place()
    def slaves(self):
        return list(reversed(self._children))

    def pack_slaves(self):
        return [c for c in reversed(self._children) if getattr(c, "_pack", None) is not None]

    def grid_slaves(self, row=None, column=None):
        out = [c for c in reversed(self._children) if getattr(c, "_grid", None) is not None]
        if row is not None:
            out = [c for c in out if int(c._grid.get("row", 0)) == int(row)]
        if column is not None:
            out = [c for c in out if int(c._grid.get("column", 0)) == int(column)]
        return out

    def place_slaves(self):
        return [c for c in reversed(self._children) if getattr(c, "_place", None) is not None]

    def grid_size(self):
        cells = [c._grid for c in self._children if getattr(c, "_grid", None) is not None]
        return (max([int(g.get("column", 0)) + int(g.get("columnspan", 1)) for g in cells], default=0),
                max([int(g.get("row", 0)) + int(g.get("rowspan", 1)) for g in cells], default=0))

    @property
    def children(self):
        return self.__dict__.get("_user_children") or {c.winfo_name(): c for c in self._children}

    @children.setter
    def children(self, v):
        self.__dict__["_user_children"] = v

    # PanedWindow, built on a Row/Column: panes are the children, sashes cannot be dragged or moved yet
    def panes(self):
        return tuple(self._children)

    def forget(self, child):
        child.visible = False

    def sash_coord(self, index):
        return (0, 0)

    def sash_place(self, index, x, y):
        pass

    sash = sash_mark = sash_dragto = sash_place

    # tkinter's columnconfigure(weight=) for runtime grids
    def rowconfigure(self, index=0, weight=None, **kw):
        pass

    grid_rowconfigure = rowconfigure

    def columnconfigure(self, index=0, weight=None, **kw):
        if weight is not None:
            self.__dict__.setdefault("_colw", {})[index] = weight

    grid_columnconfigure = columnconfigure

    def _draw_children(self) -> None:
        kids = [c for c in self._children if c._visible]
        slots = [i for i, c in enumerate(kids) if "_pack_seq" in c.__dict__ and getattr(c, "_pack", None)]
        if len(slots) > 1:  # packed widgets keep the places of packed widgets but follow the order of the pack() calls
            for i, c in zip(slots, sorted((kids[i] for i in slots), key=lambda c: c.__dict__["_pack_seq"])):
                kids[i] = c
        if any(getattr(c, "_grid", None) for c in kids):
            self._draw_grid(kids)
        elif any(getattr(c, "_pack", None) for c in kids):
            self._draw_pack(kids)
        else:
            for child in kids:
                child._render()

    def _draw_pack(self, kids) -> None:
        """tkinter pack at run time: top/bottom stack, consecutive left/right widgets share a row."""
        bottom = [c for c in kids if (getattr(c, "_pack", None) or {}).get("side") == "bottom"]
        main = [c for c in kids if c not in bottom]
        i = 0
        while i < len(main):
            c = main[i]
            side = (getattr(c, "_pack", None) or {}).get("side", "top")
            if side in ("left", "right"):
                run = [c]
                while i + 1 < len(main) and (getattr(main[i + 1], "_pack", None) or {}).get("side", "top") in ("left", "right"):
                    i += 1
                    run.append(main[i])
                left = [w for w in run if w._pack.get("side") == "left"]
                right = [w for w in run if w._pack.get("side") == "right"]
                first = True
                for w in left + list(reversed(right)):
                    if not first:
                        _core.same_line(0.0, -1.0)
                    first = False
                    _fill(w)
                    w._render()
            else:
                _fill(c)
                c._render()
            i += 1
        for c in reversed(bottom):
            _fill(c)
            c._render()

    def _draw_grid(self, kids) -> None:
        cells: dict = {}
        nxt = 0
        for c in kids:
            g = getattr(c, "_grid", None)
            if g is None:  # mixed with pack/none: treat as its own row
                cells[(nxt, 0)] = (c, 1)
                nxt += 1
                continue
            r = int(g.get("row", nxt))
            col = int(g.get("column", 0))
            cells[(r, col)] = (c, int(g.get("columnspan", 1)))
            nxt = r + 1
        ncols = max(col + span for (r, col), (c, span) in cells.items())
        rows = sorted({r for r, _ in cells})
        cw = self.__dict__.get("_colw", {})
        if not _core.begin_table(f"##g{self._id}", ncols):
            return
        try:
            for i in range(ncols):
                _core.table_setup_column(f"c{i}", float(cw.get(i, 0)))
            for r in rows:
                _core.table_next_row()
                for col in range(ncols):
                    _core.table_next_column()
                    hit = cells.get((r, col))
                    if hit:
                        _fill(hit[0], sticky=True)
                        hit[0]._render()
        finally:
            _core.end_table()


class Column(Container):
    """Children stacked top to bottom. gap=None uses the theme's spacing."""

    def __init__(self, parent=None, *, gap: Optional[float] = None, indent: float = 0.0, **kw):
        super().__init__(parent, **kw)
        self.gap, self.indent = gap, indent

    def _draw(self) -> None:
        if self.gap is not None:
            _core.push_spacing(self.gap, self.gap)
        if self.indent:
            _core.indent(self.indent)
        _core.begin_group()
        try:
            self._draw_children()
        finally:
            _core.end_group()
            if self.indent:
                _core.unindent(self.indent)
            if self.gap is not None:
                _core.pop_spacing()


class Row(Container):
    """Children side by side. Give widgets a width= (Entry defaults to 200)."""

    def __init__(self, parent=None, *, gap: Optional[float] = None, **kw):
        super().__init__(parent, **kw)
        self.gap = gap

    def _draw(self) -> None:
        if self.gap is not None:
            _core.push_spacing(self.gap, self.gap)
        _core.begin_group()
        try:
            first = True
            for child in list(self._children):
                if not child._visible:
                    continue
                if not first:
                    _core.same_line(0.0, -1.0 if self.gap is None else self.gap)
                first = False
                child._render()
        finally:
            _core.end_group()
            if self.gap is not None:
                _core.pop_spacing()


class Grid(Container):
    """Children fill cells left to right, top to bottom. weights = relative column widths.

    A column with weight 0 is only as wide as its widest widget.
    """

    def __init__(self, parent=None, *, columns: int = 2, weights: Optional[list[float]] = None, **kw):
        super().__init__(parent, **kw)
        self.columns = columns
        self.weights = weights or [1.0] * columns

    def _draw(self) -> None:
        if not _core.begin_table(f"##grid{self._id}", self.columns):
            return
        try:
            for i in range(self.columns):
                _core.table_setup_column(f"c{i}", self.weights[i] if i < len(self.weights) else 1.0)
            for child in list(self._children):
                if not child._visible:
                    continue
                _core.table_next_column()
                child._render()
        finally:
            _core.end_table()


# ------------------------------------------------------------------ 0.3.0 widgets
class TextArea(Widget):
    """Multi-line text box (tkinter's Text, the plain-text part). Bind a Var or use .text."""

    def __init__(self, text: str = "", *, var: Optional[Var] = None, height: float = 120.0,
                 readonly: bool = False, wrap: bool = True,
                 on_change: Optional[Callable[[str], None]] = None, **kw):
        super().__init__(**kw)
        self.var = var if var is not None else Var(text)
        self.height, self.readonly, self.wrap, self.on_change = height, readonly, wrap, on_change
        self._undo, self._redo, self._last, self._restoring, self._modified = [], [], str(self.var.get()), False, False
        self.var._traces.append(self._record)

    text = property(lambda s: s.var.get(), lambda s, v: s.var.set(v))

    # --- undo/redo/modified: one snapshot per change (tkinter groups typing; this is finer-grained)
    def _record(self, new: Any) -> None:
        new = str(new)
        if self._restoring or new == self._last:
            return
        self._undo.append(self._last)
        del self._redo[:]
        self._last = new
        self._modified = True

    def edit_undo(self) -> None:
        if not self._undo:
            return                      # tkinter with undo off (the default) answers ""; programs do not expect an error
        self._redo.append(str(self.var.get()))
        self._swap(self._undo.pop())

    def edit_redo(self) -> None:
        if not self._redo:
            return
        self._undo.append(str(self.var.get()))
        self._swap(self._redo.pop())

    def _swap(self, text: str) -> None:
        self._restoring = True
        try:
            self.var.set(text)
        finally:
            self._restoring = False
        self._last = text
        self._modified = True

    def edit_reset(self) -> None:
        del self._undo[:], self._redo[:]

    def edit_modified(self, flag: Any = None) -> bool:
        if flag is None:
            return self._modified
        self._modified = bool(flag)
        return self._modified

    def window_create(self, index: Any, **kw: Any) -> None:
        _compat_note("Text.window_create: embedded widgets are not drawn inside the text yet")

    image_create = window_create

    # --- marks and tkinter's index arithmetic ("1.0 lineend", "insert -3c", "mark+2c")
    def _marks(self) -> dict:
        return self.__dict__.setdefault("_markpos", {})

    # tkinter Text indexes ("1.0", "end", "insert", "sel.first", marks); a bad one raises TclError like tkinter
    def _pos(self, index: Any) -> int:
        """Character offset; len(text)+1 means "end" (tkinter keeps an implicit newline after the last line)."""
        import re
        t, raw = str(self.var.get()), str(index).strip()
        m = re.match(r"^(\d+\.(?:\d+|end)|@-?\d+,-?\d+|[A-Za-z_][\w.]*?)(?=$|[ +\-])(.*)$", raw)
        base, rest = (m.group(1), m.group(2)) if m else (raw, "")
        marks = self._marks()
        ok = bool(m) and (base in marks or base in ("end", "insert", "current") or base[:1].isdigit() or base[:1] == "@"
                          or base.endswith((".first", ".last")) or base in self._tg() or base in self._tags_seen())
        if not ok:
            from ._dialogs import TclError
            raise TclError(f'bad text index "{raw}"')
        if base in ("sel.first", "sel.last") and base not in marks:
            sel = [(a, b) for a, b, tg in self._tr() if tg == "sel"]
            if not sel:        # tkinter: no selection is an error programs catch (get(SEL_FIRST, SEL_LAST))
                from ._dialogs import TclError
                raise TclError('text doesn\'t contain any characters tagged with "sel"')
            pos = min(a for a, _ in sel) if base == "sel.first" else max(b for _, b in sel)
        elif base in marks:
            pos = min(marks[base], len(t))
        elif base == "end":
            pos = len(t) + 1
        elif base in ("insert", "current") or not base[:1].isdigit():
            pos = len(t)
        else:
            pos = self._lc(t, base)
        for mod in re.finditer(r"([+-])\s*(\d+)\s*(c|chars?|l|lines?|i|indices)?|(linestart|lineend)|(wordstart|wordend)", rest):
            if mod.group(1):
                n = int(mod.group(2)) * (1 if mod.group(1) == "+" else -1)
                if (mod.group(3) or "c").startswith("l"):
                    pos = min(pos, len(t))
                    ln, col = t[:pos].count("\n"), pos - (t[:pos].rfind("\n") + 1)
                    lines = t.split("\n")
                    ln = max(0, min(len(lines) - 1, ln + n))
                    pos = sum(len(x) + 1 for x in lines[:ln]) + min(col, len(lines[ln]))
                else:
                    pos = max(0, min(len(t) + 1, pos + n))
            elif mod.group(4) == "linestart":
                pos = min(pos, len(t))
                pos = t[:pos].rfind("\n") + 1
            elif mod.group(4) == "lineend":
                pos = min(pos, len(t))
                e = t.find("\n", pos)
                pos = len(t) if e < 0 else e
        return max(0, pos)

    def _tags_seen(self) -> tuple:
        return tuple(r[2] for r in self._tr())

    def _off(self, index: Any) -> int:
        return min(self._pos(index), len(str(self.var.get())))

    @staticmethod
    def _lc(t: str, i: str) -> int:
        try:
            line, col = i.split(".")
            lines = t.split("\n")
            ln = max(1, int(line)) - 1
            if ln >= len(lines):
                return len(t) + 1
            return sum(len(x) + 1 for x in lines[:ln]) + min(int(col) if col != "end" else len(lines[ln]), len(lines[ln]))
        except ValueError:
            return len(t)

    def search(self, pattern: Any, index: Any, stopindex: Any = None, forwards: Any = None, backwards: Any = None,
               exact: Any = None, regexp: Any = None, nocase: Any = None, count: Any = None, elide: Any = None) -> str:
        """tkinter Text.search: returns the index of the match ("" if none); count (a Var) gets its length."""
        import re
        t = str(self.var.get())
        start = self._off(index)
        stop = self._off(stopindex) if stopindex is not None else (0 if backwards else len(t))
        flags = re.I if nocase else 0
        rx = re.compile(str(pattern) if regexp else re.escape(str(pattern)), flags)
        if backwards:
            hits = [m for m in rx.finditer(t[:start]) if m.start() >= stop]
            m = hits[-1] if hits else None
            if m is None and stopindex is None:
                hits = [m for m in rx.finditer(t) if m.start() >= start]
                m = hits[-1] if hits else None
        else:
            m = rx.search(t, start, stop)
            if m is None and stopindex is None:
                m = rx.search(t, 0, min(len(t), start + len(str(pattern))))   # tkinter wraps round to the top
        if m is None:
            return ""
        if count is not None and hasattr(count, "set"):
            count.set(m.end() - m.start())
        return self.index_of(m.start())

    # --- tags: {name: options}, ranges as [start, end) character offsets, kept in step with edits
    def _tg(self) -> dict:
        return self.__dict__.setdefault("_tagopts", {})

    def _tr(self) -> list:
        return self.__dict__.setdefault("_tagrng", [])

    def _shift(self, at: int, n: int) -> None:
        """Text changed at `at` by n characters (n < 0 = deleted)."""
        out = []
        for a, b, t in self._tr():
            if n >= 0:
                a2 = a + n if a >= at else a
                b2 = b + n if b > at else b
            else:
                lo, hi = at, at - n
                a2 = a if a <= lo else max(lo, a + n if a >= hi else lo)
                b2 = b if b <= lo else max(lo, b + n if b >= hi else lo)
            if b2 > a2:
                out.append([a2, b2, t])
        self.__dict__["_tagrng"] = out

    def insert(self, index: Any, chars: Any, *tags: Any) -> None:
        t, at = str(self.var.get()), self._off(index)
        s = str(chars)
        self._shift(at, len(s))
        self.var.set(t[:at] + s + t[at:])
        self._record(self.var.get())   # synchronously: Var traces only run between frames
        for tg in tags:
            for name in ([tg] if isinstance(tg, str) else tg):
                if s:
                    self._tr().append([at, at + len(s), name])
                    self._tg().setdefault(name, {})

    def get(self, start: Any = "1.0", end: Any = None) -> str:
        t = str(self.var.get())
        a = self._pos(start)
        if end is None:
            return t[a:a + 1] if a < len(t) else ("\n" if a == len(t) else "")
        b = self._pos(end)
        return t[a:b] + ("\n" if b > len(t) >= a and a < b else "")

    def delete(self, start: Any = "1.0", end: Any = None) -> None:
        t = str(self.var.get())
        a = self._off(start)
        b = self._off(end) if end is not None else a + 1
        self._shift(a, -(b - a))
        self.var.set(t[:a] + t[b:])
        self._record(self.var.get())

    def tag_configure(self, tag: Any = None, cnf: Any = None, **k: Any) -> Any:
        if tag is None:
            return None
        o = self._tg().setdefault(str(tag), {})
        o.update(cnf if isinstance(cnf, dict) else {}, **k)
        if any(x in k for x in ("font", "spacing1", "spacing3", "lmargin1", "justify")):
            _compat_note("Text tag fonts, margins and spacing are not supported; colours and underline are")
        _core.wake()
        return dict(o)

    tag_config = tag_configure

    def tag_add(self, tag: str, start: Any, end: Any = None, *more: Any) -> None:
        a = self._off(start)
        b = self._off(end) if end is not None else a + 1
        if b > a:
            self._tr().append([a, b, str(tag)])
            self._tg().setdefault(str(tag), {})
        if more:
            self.tag_add(tag, *more)
        _core.wake()

    def tag_remove(self, tag: str, start: Any = "1.0", end: Any = None) -> None:
        a = self._off(start)
        b = self._off(end) if end is not None else a + 1
        out = []
        for x, y, t in self._tr():
            if t != tag or y <= a or x >= b:
                out.append([x, y, t])
                continue
            if x < a:
                out.append([x, a, t])
            if y > b:
                out.append([b, y, t])
        self.__dict__["_tagrng"] = out
        _core.wake()

    def tag_delete(self, *tags: str) -> None:
        self.__dict__["_tagrng"] = [r for r in self._tr() if r[2] not in tags]
        for t in tags:
            self._tg().pop(t, None)

    def tag_names(self, index: Any = None) -> tuple:
        if index is None:
            return ("sel",) + tuple(n for n in self._tg() if n != "sel")
        at = self._off(index)
        return tuple(dict.fromkeys(t for a, b, t in self._tr() if a <= at < b))

    def tag_ranges(self, tag: str) -> tuple:
        out = []
        for a, b, t in sorted(self._tr()):
            if t == tag:
                out += [self.index_of(a), self.index_of(b)]
        return tuple(out)

    def index_of(self, off: int) -> str:
        full = str(self.var.get())
        if off > len(full):
            return f"{full.count(chr(10)) + 2}.0"
        t = full[:off]
        return f"{t.count(chr(10)) + 1}.{len(t) - (t.rfind(chr(10)) + 1)}"

    def index(self, i: Any) -> str:
        return self.index_of(self._pos(i))

    def see(self, index: Any = None, *a: Any) -> None:
        if index is not None:
            self._pos(index)             # a bad index raises like tkinter; scrolling itself is automatic

    def tag_bind(self, *a: Any, **k: Any) -> None:
        _compat_note("Text.tag_bind (clickable text) is not supported yet")

    def mark_set(self, name: Any = None, index: Any = None, *a: Any, **k: Any) -> None:
        if name is not None and index is not None:
            self._marks()[str(name)] = self._off(index)

    def mark_unset(self, *names: Any) -> None:
        for n in names:
            self._marks().pop(str(n), None)

    def mark_names(self) -> tuple:
        return ("insert", "current") + tuple(self._marks())

    mark_gravity = lambda self, *a, **k: "right"  # noqa: E731

    def compare(self, a: Any, op: str, b: Any) -> bool:
        x, y = self._pos(a), self._pos(b)
        return {"<": x < y, "<=": x <= y, "==": x == y, ">=": x >= y, ">": x > y, "!=": x != y}[str(op)]

    def count(self, a: Any, b: Any, *opts: str):
        t, x, y = str(self.var.get()), self._pos(a), self._pos(b)
        lo, hi = min(x, y), max(x, y)
        res = []
        for o in (opts or ("indices",)):
            o = str(o).lstrip("-")
            res.append((t + "\n")[lo:hi].count("\n") if o in ("lines", "displaylines") else hi - lo)
        if len(res) == 1:
            return (res[0],) if res[0] else None      # tkinter answers None for a single zero count
        return tuple(res)

    def replace(self, a: Any, b: Any, chars: Any, *tags: Any) -> None:
        self.delete(a, b)
        self.insert(a, chars, *tags)

    def tag_nextrange(self, tag: str, index1: Any, index2: Any = None) -> tuple:
        lo, hi = self._off(index1), self._off(index2) if index2 is not None else len(str(self.var.get()))
        for a, b, t in sorted(self._tr()):
            if t == tag and lo <= a < hi:
                return (self.index_of(a), self.index_of(b))
        return ()

    def tag_prevrange(self, tag: str, index1: Any, index2: Any = None) -> tuple:
        hi, lo = self._off(index1), self._off(index2) if index2 is not None else 0
        for a, b, t in sorted(self._tr(), reverse=True):
            if t == tag and lo <= a < hi:
                return (self.index_of(a), self.index_of(b))
        return ()

    def tag_cget(self, tag: str, option: str):
        return self._tg().get(str(tag), {}).get(str(option).lstrip("-"), "")

    def tag_raise(self, tag: str, above: Any = None) -> None:
        """Later tags win (tkinter's priority); raising one moves its ranges to the end."""
        rng = self._tr()
        self.__dict__["_tagrng"] = [r for r in rng if r[2] != tag] + [r for r in rng if r[2] == tag]
        _core.wake()

    def tag_lower(self, tag: str, below: Any = None) -> None:
        rng = self._tr()
        self.__dict__["_tagrng"] = [r for r in rng if r[2] == tag] + [r for r in rng if r[2] != tag]
        _core.wake()

    tag_unbind = lambda self, *a, **k: None  # noqa: E731

    def dump(self, index1: Any, index2: Any = None, command: Any = None, **kw: Any) -> list:
        """The text part of tkinter's dump: [("text", chars, index)] for each line in the range."""
        a = self._off(index1)
        b = self._off(index2) if index2 is not None else a + 1
        out, pos = [], a
        for piece in str(self.var.get())[a:b].splitlines(keepends=True):
            out.append(("text", piece, self.index_of(pos)))
            pos += len(piece)
        return out

    def mark_next(self, index: Any):
        at = self._off(index)
        after = sorted((p, n) for n, p in self._marks().items() if p >= at)
        return after[0][1] if after else None

    def mark_previous(self, index: Any):
        at = self._off(index)
        before = sorted((p, n) for n, p in self._marks().items() if p < at)
        return before[-1][1] if before else None

    def edit(self, *args: Any):
        """text.edit("undo") / edit("modified", False): the old single-command form."""
        if not args:
            return None
        fn = {"undo": self.edit_undo, "redo": self.edit_redo, "reset": self.edit_reset,
              "modified": self.edit_modified, "separator": lambda *a: None}.get(str(args[0]))
        return fn(*args[1:]) if fn else None

    dlineinfo = lambda self, index: None  # noqa: E731
    window_names = image_names = peer_names = lambda self: ()  # noqa: E731
    yview_pickplace = lambda self, *a: None  # noqa: E731
    edit_separator = lambda self, *a, **k: None  # noqa: E731

    def _runs(self) -> list:
        """Split the text into (text, fg, bg, underline) runs; later tags win, like tkinter's tag priority."""
        t = str(self.var.get())
        rng, opts = self._tr(), self._tg()
        order = {n: i for i, n in enumerate(opts)}
        cuts = sorted({0, len(t), *[max(0, min(len(t), v)) for a, b, _ in rng for v in (a, b)]})
        base = _rgb(self.color) if getattr(self, "color", None) else _core_text_rgb()
        runs = []
        for a, b in zip(cuts, cuts[1:]):
            on = sorted({n for x, y, n in rng if x <= a and y >= b}, key=lambda n: order.get(n, 0))
            fg, bg, ul = base, None, False
            for n in on:
                o = opts.get(n, {})
                c = o.get("foreground", o.get("fg"))
                if c:
                    fg = _rgb_name(c) or fg
                c = o.get("background", o.get("bg"))
                if c:
                    bg = _rgb_name(c) or bg
                ul = ul or bool(o.get("underline")) or bool(o.get("overstrike"))
            runs.append((t[a:b], *fg, *(bg or (0.0, 0.0, 0.0)), 1.0 if bg else -1.0, ul))
        return runs

    def _draw(self) -> None:
        coloured = self.readonly and any(self._tg().values())
        if coloured:
            # tkinter apps colour a Text and set state="disabled" (logs, chat): draw it as rich text
            w = self.width if self.width is not None else -1.0
            if _core.begin_child(f"##rt{self._id}", w, self.height, True):
                _core.rich_text(self._runs(), -1.0)
            _core.end_child()
            return
        if any(self._tg().values()) and not self.readonly:
            _compat_note("Text tag colours show only while the Text is state='disabled' (read-only)")
        changed, new = _core.input_multiline("##area", str(self.var.get()), self._auto_width(), self.height,
                                             self.readonly, self.wrap)
        if changed:
            old = str(self.var._v)
            self.var._v = new
            self._retag(old, new)
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)

    def _retag(self, old: str, new: str) -> None:
        """Typing: keep tags on the unchanged prefix/suffix."""
        if not self._tr():
            return
        p = 0
        while p < min(len(old), len(new)) and old[p] == new[p]:
            p += 1
        self._shift(p, len(new) - len(old))

    def config(self, cnf=None, **kw):
        kw = dict(cnf if isinstance(cnf, dict) else {}, **kw)
        if "state" in kw:
            self.readonly = kw.pop("state") == "disabled"
            _core.wake()
        if kw:
            super().config(**kw)

    configure = config


_NAMED = {"red": "#ff0000", "green": "#008000", "blue": "#0000ff", "black": "#000000", "white": "#ffffff",
          "yellow": "#ffff00", "orange": "#ffa500", "grey": "#808080", "gray": "#808080", "purple": "#800080",
          "cyan": "#00ffff", "magenta": "#ff00ff", "darkgreen": "#006400", "darkred": "#8b0000", "navy": "#000080",
          "lightgrey": "#d3d3d3", "lightgray": "#d3d3d3", "pink": "#ffc0cb", "brown": "#a52a2a",
          "lightblue": "#add8e6", "lightyellow": "#ffffe0", "darkblue": "#00008b", "gold": "#ffd700",
          "lightgreen": "#90ee90", "lightpink": "#ffb6c1", "skyblue": "#87ceeb", "tomato": "#ff6347", "salmon": "#fa8072",
          "coral": "#ff7f50", "khaki": "#f0e68c", "violet": "#ee82ee", "teal": "#008080", "olive": "#808000",
          "maroon": "#800000", "lime": "#00ff00", "silver": "#c0c0c0", "beige": "#f5f5dc", "ivory": "#fffff0",
          "tan": "#d2b48c", "orchid": "#da70d6", "plum": "#dda0dd", "turquoise": "#40e0d0", "indigo": "#4b0082",
          "crimson": "#dc143c", "darkgrey": "#a9a9a9", "darkgray": "#a9a9a9", "lightcyan": "#e0ffff",
          "steelblue": "#4682b4", "royalblue": "#4169e1", "forestgreen": "#228b22", "seagreen": "#2e8b57",
          "darkorange": "#ff8c00", "chocolate": "#d2691e", "wheat": "#f5deb3", "lavender": "#e6e6fa", "linen": "#faf0e6",
          "lightsalmon": "#ffa07a", "lightgoldenrod": "#eedd82", "aquamarine": "#7fffd4", "azure": "#f0ffff",
          "sienna": "#a0522d", "firebrick": "#b22222", "hotpink": "#ff69b4", "deeppink": "#ff1493",
          "dimgray": "#696969", "dimgrey": "#696969", "slategray": "#708090", "slategrey": "#708090",
          "midnightblue": "#191970", "limegreen": "#32cd32", "springgreen": "#00ff7f", "gainsboro": "#dcdcdc",
          "whitesmoke": "#f5f5f5", "snow": "#fffafa", "mintcream": "#f5fffa", "honeydew": "#f0fff0", "peachpuff": "#ffdab9"}


def _rgb_name(c: Any):
    """'#rgb', '#rrggbb' or a common Tk colour name -> floats; None if unknown."""
    s = str(c).strip().lower()
    s = _NAMED.get(s.replace(" ", ""), s)
    if s.startswith("#") and len(s) == 4:
        s = "#" + "".join(ch * 2 for ch in s[1:])
    if s.startswith("#") and len(s) == 7:
        return _rgb(s)
    return None


def _core_text_rgb() -> tuple[float, float, float]:
    return (-1.0, -1.0, -1.0)  # the theme's text colour (decided in the native core)


class Dropdown(Widget):
    """Drop-down list (ttk.Combobox, read-only style). .index is -1 when nothing is chosen."""

    def __init__(self, items: Optional[list[str]] = None, *, index: int = 0,
                 on_change: Optional[Callable[[int, str], None]] = None, editable: bool = False,
                 var: Optional["Var"] = None, **kw):
        super().__init__(**kw)
        self.items = [str(x) for x in (items or [])]
        self.index = index
        self.on_change = on_change
        self.editable = editable  # ttk.Combobox is editable unless state="readonly"
        self.var = var
        self._text = self.items[index] if 0 <= index < len(self.items) else ""
        if var is not None and str(var.get()):
            self.set(var.get())

    @property
    def value(self) -> str:
        if self.editable:
            return self._text
        return self.items[self.index] if 0 <= self.index < len(self.items) else ""

    # ttk.Combobox names
    def get(self) -> str:
        return self.value

    def set(self, v: Any) -> None:
        v = str(v)
        self.index = self.items.index(v) if v in self.items else -1
        self._text = v
        if self.var is not None and str(self.var.get()) != v:
            self.var.set(v)
        _core.wake()

    def config(self, cnf=None, **kw):
        kw = dict(cnf if isinstance(cnf, dict) else {}, **kw)
        st = kw.get("state")
        if st in ("readonly", "normal"):
            self.editable = st == "normal"
            kw.pop("state")
        if "textvariable" in kw:
            self.var = kw.pop("textvariable")
        if kw:
            super().config(**kw)

    configure = config

    def current(self, i: Optional[int] = None) -> int:
        if i is not None:
            i = int(i)
            if not 0 <= i < len(self.items):
                from ._dialogs import TclError
                raise TclError(f"Index {i} out of range")
            self.index = i
            self._text = self.items[i]
            _core.wake()
        cur = self._text if self.editable else (self.items[self.index] if 0 <= self.index < len(self.items) else "")
        return self.items.index(cur) if cur in self.items else -1

    values = property(lambda s: tuple(s.items), lambda s, v: (setattr(s, "items", [str(x) for x in v]), _core.wake()))

    def bind(self, seq, fn=None, add=None):
        if str(seq) == "<<ComboboxSelected>>" and fn is not None:
            self.on_change = lambda _i, _t, f=fn: f(_Event(self))
        elif fn is not None:
            _compat_note(f"Combobox.bind({seq}) is not supported yet")

    def _draw(self) -> None:
        reload = False
        if self.var is not None and str(self.var.get()) != self.value:  # textvariable changed elsewhere
            self.set(self.var.get())
            reload = True
        if self.editable:
            changed, text, picked = _core.combo_edit("##ce", self._text, self.items, self._auto_width(200.0), reload)
            if changed:
                self._text = text
                self.index = picked if picked >= 0 else (self.items.index(text) if text in self.items else -1)
                if self.var is not None:
                    self.var._v = text
                    for fn in list(self.var._traces):
                        _queue(fn, text)
                if picked >= 0:  # <<ComboboxSelected>> fires on a pick, not on typing
                    _queue(self.on_change, picked, text)
            return
        changed, i = _core.combo("##dd", self.items, self.index, self._auto_width(200.0))
        if changed:
            self.index = i
            self._text = self.items[i]
            if self.var is not None:
                self.var.set(self.items[i])
            _queue(self.on_change, i, self.items[i])


class Table(Widget):
    """Scrolling list of rows with columns (ttk.Treeview in its flat 'headings' form).

    rows: list of tuples of strings. colors: optional list (same length) of '#rrggbb' per row.
    """

    def __init__(self, columns: Optional[list[str]] = None, rows: Optional[list[tuple]] = None, *,
                 colors: Optional[list[Any]] = None, height: float = 160.0, weights: Optional[list[float]] = None,
                 on_select: Optional[Callable[[int], None]] = None, **kw):
        super().__init__(**kw)
        self.columns = list(columns or [""])
        self.weights = weights
        self.height, self.on_select = height, on_select
        self.selected = -1
        self.rows: list[tuple] = []
        self.colors: list[Any] = []
        self.set_rows(rows or [], colors)

    def set_rows(self, rows: list[tuple], colors: Optional[list[Any]] = None) -> None:
        self.rows = [tuple(str(c) for c in r) for r in rows]
        self.colors = list(colors) if colors else [None] * len(self.rows)
        if self.selected >= len(self.rows):
            self.selected = -1
        _core.wake()

    def select(self, i: int) -> None:
        if i != self.selected:
            self.selected = i
            _queue(self.on_select, i)
            _core.wake()

    def _draw(self) -> None:
        w = self.width if self.width is not None else -1.0
        if _core.begin_child("##tbl", w, self.height, True):
            try:
                n = len(self.columns)
                if _core.begin_table("##cols", n):
                    try:
                        for i in range(n):
                            _core.table_setup_column(self.columns[i], self.weights[i] if self.weights else 1.0)
                        for i, row in enumerate(self.rows):
                            _core.push_id(str(i))
                            _core.table_next_row()
                            col = self.colors[i] if i < len(self.colors) else None
                            if col is not None:
                                _core.push_text_color(*_rgb(col))
                            for j in range(n):
                                _core.table_next_column()
                                txt = row[j] if j < len(row) else ""
                                if j == 0:
                                    if _core.selectable(txt + "##r", i == self.selected, True):
                                        self.select(i)
                                else:
                                    _core.text(txt)
                            if col is not None:
                                _core.pop_text_color()
                            _core.pop_id()
                    finally:
                        _core.end_table()
            finally:
                _core.end_child()
        else:
            _core.end_child()


class QRView(Widget):
    """Draws a square on/off matrix (such as a QR code) with a white quiet zone around it."""

    def __init__(self, matrix: Optional[list[list[int]]] = None, *, px: float = 5.0, quiet: int = 4, **kw):
        super().__init__(**kw)
        self.px, self.quiet = px, quiet
        self._n = 0
        self._bits = b""
        self.set_matrix(matrix or [])

    def set_matrix(self, matrix: list[list[int]]) -> None:
        m = len(matrix)
        q = self.quiet
        n = m + 2 * q if m else 0
        buf = bytearray(n * n)
        for y, row in enumerate(matrix):
            for x, v in enumerate(row):
                if v:
                    buf[(y + q) * n + x + q] = 1
        self._n, self._bits = n, bytes(buf)
        _core.wake()

    def _draw(self) -> None:
        if self._n:
            _core.draw_matrix(self._bits, self._n, self.px, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        else:
            _core.text("(no QR yet)", True)


def set_clipboard(text: str) -> None:
    _core.set_clipboard(str(text))


def get_clipboard() -> str:
    return _core.get_clipboard()


class Frame(Column):
    """tkinter's Frame/ttk.Frame/LabelFrame: a Column that accepts (and ignores) the usual styling options."""

    def __init__(self, master=None, *args, parent=None, text: str = "", **ignored):
        super().__init__(parent if parent is not None else master if isinstance(master, Container) else None)
        self.text = text

    def _draw(self) -> None:
        if self.text:
            _core.text(str(_val(self.text)), True)
        super()._draw()


LabelFrame = Frame
