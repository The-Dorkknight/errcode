"""PhotoImage: tkinter's image object, with no extra dependencies.

Reads PNG (8-bit, any colour type, non-interlaced), GIF (first frame) and PPM/PGM in pure Python,
and anything else through Pillow if it happens to be installed. Pixels are kept as RGBA bytes and
uploaded to the GPU (or software renderer) the first time the image is drawn.
"""
from __future__ import annotations

import base64
import struct
import zlib
from typing import Any, Optional

from . import _core

__all__ = ["PhotoImage", "load_rgba"]


# ------------------------------------------------------------------------------------------- decoders
def _png(b: bytes) -> tuple[int, int, bytes]:
    pos, idat, w = 8, [], 0
    pal, trns = b"", b""
    while pos < len(b):
        n, kind = struct.unpack(">I4s", b[pos:pos + 8])
        data = b[pos + 8:pos + 8 + n]
        pos += 12 + n
        if kind == b"IHDR":
            w, h, depth, ctype, _c, _f, inter = struct.unpack(">IIBBBBB", data)
        elif kind == b"PLTE":
            pal = data
        elif kind == b"tRNS":
            trns = data
        elif kind == b"IDAT":
            idat.append(data)
        elif kind == b"IEND":
            break
    if depth != 8 or inter:
        raise ValueError("PNG: only 8-bit, non-interlaced files are read without Pillow")
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    raw = zlib.decompress(b"".join(idat))
    stride = w * ch
    out = bytearray(h * stride)
    prev = bytearray(stride)
    i = 0
    for y in range(h):
        ft = raw[i]
        line = bytearray(raw[i + 1:i + 1 + stride])
        i += 1 + stride
        if ft == 1:
            for x in range(ch, stride):
                line[x] = (line[x] + line[x - ch]) & 255
        elif ft == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 255
        elif ft == 3:
            for x in range(stride):
                a = line[x - ch] if x >= ch else 0
                line[x] = (line[x] + ((a + prev[x]) >> 1)) & 255
        elif ft == 4:
            for x in range(stride):
                a = line[x - ch] if x >= ch else 0
                c = prev[x - ch] if x >= ch else 0
                p = a + prev[x] - c
                pa, pb, pc = abs(p - a), abs(p - prev[x]), abs(p - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else prev[x] if pb <= pc else c)) & 255
        out[y * stride:(y + 1) * stride] = line
        prev = line
    if ctype == 6:
        return w, h, bytes(out)
    rgba = bytearray(w * h * 4)
    if ctype == 2:
        rgba[0::4], rgba[1::4], rgba[2::4] = out[0::3], out[1::3], out[2::3]
        rgba[3::4] = b"\xff" * (w * h)
    elif ctype in (0, 4):
        g = out[0::ch]
        rgba[0::4] = rgba[1::4] = rgba[2::4] = g
        rgba[3::4] = out[1::2] if ctype == 4 else b"\xff" * (w * h)
    else:  # palette
        lut = [pal[k * 3:k * 3 + 3] + (bytes([trns[k]]) if k < len(trns) else b"\xff") for k in range(len(pal) // 3)]
        rgba = bytearray(b"".join(lut[v] for v in out))
    return w, h, bytes(rgba)


def _gif(b: bytes) -> tuple[int, int, bytes]:
    w, h, flags = struct.unpack("<HHB", b[6:11])
    pos = 13
    gct = b""
    if flags & 0x80:
        n = 3 * (2 << (flags & 7))
        gct, pos = b[13:13 + n], 13 + n
    transp = -1
    while pos < len(b):
        tag = b[pos]
        if tag == 0x21:  # extension
            label = b[pos + 1]
            pos += 2
            if label == 0xF9 and b[pos + 1] & 1:
                transp = b[pos + 4]
            while b[pos]:
                pos += b[pos] + 1
            pos += 1
        elif tag == 0x2C:  # image
            ix, iy, iw, ih, f = struct.unpack("<HHHHB", b[pos + 1:pos + 10])
            pos += 10
            ct = gct
            if f & 0x80:
                n = 3 * (2 << (f & 7))
                ct, pos = b[pos:pos + n], pos + n
            mcs = b[pos]
            pos += 1
            data = bytearray()
            while b[pos]:
                data += b[pos + 1:pos + 1 + b[pos]]
                pos += b[pos] + 1
            idx = _lzw(bytes(data), mcs, iw * ih)
            if f & 0x40:  # interlaced: rows come 0,8,16.. 4,12.. 2,6.. 1,3..
                order = [r for s, st in ((0, 8), (4, 8), (2, 4), (1, 2)) for r in range(s, ih, st)]
                fixed = bytearray(iw * ih)
                for k, r in enumerate(order):
                    fixed[r * iw:(r + 1) * iw] = idx[k * iw:(k + 1) * iw]
                idx = fixed
            rgba = bytearray(w * h * 4)
            for y in range(ih):
                for x in range(iw):
                    v = idx[y * iw + x]
                    if v == transp or v * 3 + 2 >= len(ct):
                        continue
                    o = ((iy + y) * w + ix + x) * 4
                    rgba[o:o + 4] = ct[v * 3:v * 3 + 3] + b"\xff"
            return w, h, bytes(rgba)
        else:
            break
    raise ValueError("GIF: no image found")


def _lzw(data: bytes, mcs: int, n: int) -> bytearray:
    clear, end = 1 << mcs, (1 << mcs) + 1
    size = mcs + 1
    table = [bytes([i]) for i in range(clear)] + [b"", b""]
    out = bytearray()
    prev = None
    bitpos, total = 0, len(data) * 8
    while bitpos + size <= total and len(out) < n:
        v = int.from_bytes(data[bitpos >> 3:(bitpos >> 3) + 3], "little") >> (bitpos & 7) & ((1 << size) - 1)
        bitpos += size
        if v == clear:
            table = table[:clear + 2]
            size, prev = mcs + 1, None
            continue
        if v == end:
            break
        if v < len(table):
            e = table[v]
            if prev is not None:
                table.append(prev + e[:1])
        else:
            e = prev + prev[:1]
            table.append(e)
        out += e
        prev = e
        if len(table) == 1 << size and size < 12:
            size += 1
    return out[:n]


def _ppm(b: bytes) -> tuple[int, int, bytes]:
    toks, pos = [], 2
    while len(toks) < 3:
        while b[pos:pos + 1].isspace():
            pos += 1
        if b[pos:pos + 1] == b"#":
            pos = b.index(b"\n", pos)
            continue
        s = pos
        while not b[pos:pos + 1].isspace():
            pos += 1
        toks.append(int(b[s:pos]))
    w, h, mx = toks
    px = b[pos + 1:]
    rgba = bytearray(w * h * 4)
    if b[:2] == b"P6":
        rgba[0::4], rgba[1::4], rgba[2::4] = px[0:w * h * 3:3], px[1:w * h * 3:3], px[2:w * h * 3:3]
    else:  # P5 grey
        rgba[0::4] = rgba[1::4] = rgba[2::4] = px[:w * h]
    rgba[3::4] = b"\xff" * (w * h)
    return w, h, bytes(rgba)


def load_rgba(blob: bytes) -> tuple[int, int, bytes]:
    """Decode image bytes -> (width, height, RGBA bytes)."""
    if blob[:8] == b"\x89PNG\r\n\x1a\n":
        try:
            return _png(blob)
        except ValueError:
            pass
    elif blob[:4] == b"GIF8":
        return _gif(blob)
    elif blob[:2] in (b"P5", b"P6"):
        return _ppm(blob)
    try:  # anything else (JPEG, 16-bit PNG, ...) if Pillow is around
        import io
        from PIL import Image
        im = Image.open(io.BytesIO(blob)).convert("RGBA")
        return im.width, im.height, im.tobytes()
    except ImportError:
        raise ValueError("this image format needs Pillow (pip install pillow); PNG, GIF and PPM work without it")


# ------------------------------------------------------------------------------------------- PhotoImage
class PhotoImage:
    """tkinter.PhotoImage: PhotoImage(file=...), PhotoImage(data=base64 or bytes), PhotoImage(width=, height=)."""

    def __init__(self, name: Any = None, cnf: Any = None, master: Any = None, *, file: Optional[str] = None,
                 data: Any = None, width: int = 0, height: int = 0, **_ignored):
        if file:
            with open(file, "rb") as f:
                self.w, self.h, self.px = load_rgba(f.read())
        elif data:
            blob = data if isinstance(data, bytes) else data.encode() if isinstance(data, str) else bytes(data)
            if not blob[:8].startswith((b"\x89PNG", b"GIF8", b"P5", b"P6", b"\xff\xd8")):
                blob = base64.b64decode(blob)  # tkinter takes base64 (str or bytes) as well as raw bytes
            self.w, self.h, self.px = load_rgba(blob)
        else:
            self.w, self.h = int(width), int(height)
            self.px = bytes(self.w * self.h * 4)
        self._tex = 0
        self._dirty = True

    def width(self) -> int:
        return self.w

    def height(self) -> int:
        return self.h

    def _handle(self) -> int:
        """Upload on first use (the renderer must exist); re-upload after put()."""
        if self._dirty and self.w and self.h:
            if self._tex:
                _core.texture_free(self._tex)
            self._tex = _core.texture_create(self.px, self.w, self.h)
            self._dirty = False
        return self._tex

    def _scaled(self, fx: float, fy: float) -> "PhotoImage":
        out = PhotoImage(width=max(1, int(self.w * fx)), height=max(1, int(self.h * fy)))
        src, dst = self.px, bytearray(out.w * out.h * 4)
        for y in range(out.h):
            sy = min(self.h - 1, int(y / fy))
            for x in range(out.w):
                s = (sy * self.w + min(self.w - 1, int(x / fx))) * 4
                d = (y * out.w + x) * 4
                dst[d:d + 4] = src[s:s + 4]
        out.px = bytes(dst)
        return out

    def copy(self) -> "PhotoImage":
        out = PhotoImage(width=max(1, self.w), height=max(1, self.h))
        out.px = bytes(self.px)
        return out

    def __getattr__(self, name):
        from ._compat import missing
        return missing(self, name)

    def subsample(self, x: int, y: Optional[int] = None) -> "PhotoImage":
        return self._scaled(1 / x, 1 / (y or x))

    def zoom(self, x: int, y: Optional[int] = None) -> "PhotoImage":
        return self._scaled(x, y or x)

    def put(self, color: Any, to: Any = None) -> None:
        """put('#rrggbb', (x, y)) or put('#rrggbb', (x1, y1, x2, y2))."""
        c = str(color).lstrip("#{").rstrip("}").split()[0].lstrip("#")
        rgba = bytes(int(c[i:i + 2], 16) for i in (0, 2, 4)) + b"\xff"
        t = tuple(to) if to else (0, 0, self.w, self.h)
        x1, y1 = t[0], t[1]
        x2, y2 = (t[2], t[3]) if len(t) == 4 else (x1 + 1, y1 + 1)
        px = bytearray(self.px)
        for y in range(max(0, y1), min(self.h, y2)):
            for x in range(max(0, x1), min(self.w, x2)):
                px[(y * self.w + x) * 4:(y * self.w + x) * 4 + 4] = rgba
        self.px = bytes(px)
        self._dirty = True
        _core.wake()

    def get(self, x: int, y: int) -> tuple:
        o = (y * self.w + x) * 4
        return tuple(self.px[o:o + 3])

    def blank(self) -> None:
        self.px = bytes(self.w * self.h * 4)
        self._dirty = True

    def __del__(self):
        try:
            if self._tex:
                _core.texture_free(self._tex)
        except Exception:
            pass
