"""Blocking dialogs: what tkinter's filedialog / simpledialog / messagebox-with-an-answer become.

tkinter's askopenfilename() returns the answer. TK 4K draws a frame at a time, so the dialog opens as a pop-up and
the call waits in a small nested event loop (Window._wait_until) that keeps drawing, until the person answers.

Tests and unattended runs can pre-load answers: `ui.dialog_answers.extend(["/tmp/a.txt", None, "7"])`.
The first queued answer is used for the next dialog instead of showing one; None means "cancelled".
"""
from __future__ import annotations

import fnmatch
import os
from typing import Any, Optional

dialog_answers: list = []          # test hook / unattended runs: answers used before any dialog is shown


class TclError(Exception):
    """tkinter.TclError: raised by TK 4K where tkinter would raise it (bad index, destroyed widget...)."""


def _window():
    from ._widgets2 import _find_window
    return _find_window(None)


def _block(open_dialog, default):
    """Open a dialog with open_dialog(win, finish) and wait for finish(value). Returns `default` if the window closes."""
    if dialog_answers:
        a = dialog_answers.pop(0)
        return default if a is None else a
    win = _window()
    if win is None:
        return default
    box: dict = {}

    def finish(v):
        box["v"] = v
    open_dialog(win, finish)
    win._wait_until(lambda: "v" in box)
    v = box.get("v")
    return default if v is None else v


def _patterns(filetypes) -> list:
    out = []
    for ft in filetypes or ():
        try:
            pats = ft[1]
        except (IndexError, TypeError):
            continue
        for p in (pats.split() if isinstance(pats, str) else pats):
            out.append(p.lower())
    return [p for p in out if p not in ("*", "*.*")]


def _chooser(win, finish, *, mode: str, start: str, title: str, initialfile: str, filetypes, multiple: bool, ext: str):
    from ._widgets import Var, Entry, Button, Label, Row
    from ._widgets2 import Dialog, Listbox
    d = Dialog(title, win, size=(560, 460))
    cur = Var(os.path.abspath(os.path.expanduser(start or os.getcwd())))
    name = Var(initialfile or "")
    res = {"v": None}
    pats = _patterns(filetypes)
    lb = None

    def entries():
        p = cur.get()
        try:
            names = sorted(os.listdir(p), key=lambda n: (not os.path.isdir(os.path.join(p, n)), n.lower()))
        except OSError as e:
            return ["(cannot read: %s)" % e.strerror]
        out = [".."]
        for n in names:
            isd = os.path.isdir(os.path.join(p, n))
            if n.startswith("."):
                continue
            if not isd and (mode == "dir" or (pats and not any(fnmatch.fnmatch(n.lower(), q) for q in pats))):
                continue
            out.append(n + ("/" if isd else ""))
        return out

    def refresh():
        lb.items = entries()
        lb.sel = []

    def done(v):
        res["v"] = v
        d.close()

    def pick(_s=None):
        base = cur.get()
        sel = [lb.items[i] for i in lb.sel if 0 <= i < len(lb.items)]
        if mode == "dir":
            if sel and sel[0] not in ("..", "(cannot read") and sel[0].endswith("/"):
                done(os.path.normpath(os.path.join(base, sel[0].rstrip("/"))))
            else:
                done(os.path.normpath(base))
            return
        if sel and (sel[0] == ".." or sel[0].endswith("/")) and len(sel) == 1:
            cur.set(os.path.normpath(os.path.join(base, sel[0].rstrip("/"))))
            refresh()
            return
        files = [os.path.normpath(os.path.join(base, n)) for n in sel if not n.endswith("/") and n != ".."]
        if mode == "save":
            n = name.get().strip() or (os.path.basename(files[0]) if files else "")
            if not n:
                return
            if ext and not os.path.splitext(n)[1]:
                n += ext if ext.startswith(".") else "." + ext
            done(os.path.normpath(os.path.join(base, n)))
        elif files:
            done(tuple(files) if multiple else files[0])

    def typed(_t=None):
        p = os.path.expanduser(cur.get().strip())
        if os.path.isfile(p) and mode == "open":
            done((p,) if multiple else p)
        elif os.path.isdir(p):
            cur.set(os.path.normpath(p))
            refresh()

    with d:
        Entry(var=cur, on_submit=typed)
        lb = Listbox(entries(), height=12, selectmode="extended" if multiple else "browse")
        if mode == "save":
            Label("File name")
            Entry(var=name, on_submit=lambda _t=None: pick())
        with Row():
            Button({"open": "Open", "save": "Save", "dir": "Choose"}[mode], pick, primary=True)
            Button("Up", lambda: (cur.set(os.path.dirname(cur.get())), refresh()))
            Button("Cancel", d.close)
    d.on_close = lambda: finish(res["v"] if res["v"] is not None else "")
    d.open()
    return d


def _file(mode: str, kw: dict, multiple: bool = False):
    start = kw.get("initialdir") or os.getcwd()
    r = _block(lambda w, fin: _chooser(w, fin, mode=mode, start=start, title=kw.get("title") or
                                       {"open": "Open file", "save": "Save as", "dir": "Choose folder"}[mode],
                                       initialfile=kw.get("initialfile") or "", filetypes=kw.get("filetypes"),
                                       multiple=multiple, ext=kw.get("defaultextension") or ""), "")
    if multiple:
        return tuple(r) if r else ()
    return r or ""


def askopenfilename(**kw) -> str:
    return _file("open", kw)


def askopenfilenames(**kw) -> tuple:
    r = _file("open", kw, multiple=True)
    return (r,) if isinstance(r, str) and r else r


def asksaveasfilename(**kw) -> str:
    return _file("save", kw)


def askdirectory(**kw) -> str:
    return _file("dir", kw)


def askopenfile(mode: str = "r", **kw):
    p = askopenfilename(**kw)
    return open(p, mode) if p else None


def askopenfiles(mode: str = "r", **kw) -> tuple:
    return tuple(open(p, mode) for p in askopenfilenames(**kw))


def asksaveasfile(mode: str = "w", **kw):
    p = asksaveasfilename(**kw)
    return open(p, mode) if p else None


# ------------------------------------------------------------------------------------------ simpledialog
def _ask_text(title, prompt, initial, parent=None):
    from ._widgets2 import ask_string
    return _block(lambda w, fin: ask_string(w, str(title), str(prompt), fin, str(initial)), None)


def askstring(title=None, prompt="", **kw) -> Optional[str]:
    return _ask_text(title or "", prompt, kw.get("initialvalue", "") or "")


def _ask_num(conv, title, prompt, kw):
    while True:
        s = _ask_text(title or "", prompt, kw.get("initialvalue", "") if kw.get("initialvalue") is not None else "")
        if s is None:
            return None
        try:
            v = conv(s.strip())
        except ValueError:
            from . import toast
            toast("Not a valid number, try again")
            if dialog_answers:   # unattended: do not loop forever
                return None
            continue
        lo, hi = kw.get("minvalue"), kw.get("maxvalue")
        if (lo is not None and v < lo) or (hi is not None and v > hi):
            from . import toast
            toast(f"Please enter a value between {lo} and {hi}")
            if dialog_answers:
                return None
            continue
        return v


def askinteger(title=None, prompt="", **kw) -> Optional[int]:
    return _ask_num(int, title, prompt, kw)


def askfloat(title=None, prompt="", **kw) -> Optional[float]:
    return _ask_num(float, title, prompt, kw)


def askcolor(color=None, **kw):
    """colorchooser.askcolor: a hex-code prompt. Returns ((r, g, b), '#rrggbb') or (None, None) like tkinter."""
    s = _ask_text(kw.get("title") or "Pick a colour", "Colour as #rrggbb", color or "#")
    if s:
        s = s.strip()
        if len(s) == 7 and s[0] == "#":
            try:
                return (int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16)), s.lower()
            except ValueError:
                pass
    return None, None


# ------------------------------------------------------------------------------------------ messagebox questions
_DISMISS = object()


def _choice(title, text, buttons, default):
    """buttons: [(label, value)]. Returns the value of the pressed button; `default` if the dialog is dismissed."""
    from ._widgets import Button, Label, Row
    from ._widgets2 import Dialog

    def build(win, finish):
        d = Dialog(str(title or ""), win, size=(380, 0))
        res = {"v": _DISMISS}

        def pick(v):
            res["v"] = v
            d.close()
        with d:
            Label(str(text), wrap=True)
            with Row():
                for i, (lab, val) in enumerate(buttons):
                    Button(lab, (lambda v=val: pick(v)), primary=(i == 0))
        d.on_close = lambda: finish(res["v"])
        d.open()
    r = _block(build, _DISMISS)
    return default if r is _DISMISS else r


def ask(text, default=True, *a, **k):
    """messagebox.askyesno / askokcancel / askretrycancel: waits for the answer (True / False)."""
    title = a[0] if a and isinstance(a[0], str) else k.get("title", "")
    if _window() is None and not dialog_answers:
        return default
    return bool(_choice(title, text, [("Yes", True), ("No", False)], False))


def askquestion(title=None, message="", **kw) -> str:
    return _choice(title, message, [("Yes", "yes"), ("No", "no")], "no")


def askyesnocancel(title=None, message="", **kw):
    return _choice(title, message, [("Yes", True), ("No", False), ("Cancel", None)], None)


# the messagebox functions themselves, for code that passes them around (`create_button(mb.askyesno, ...)`)
def askyesno(title=None, message="", **kw) -> bool:
    return bool(_choice(title, message, [("Yes", True), ("No", False)], False))


def askokcancel(title=None, message="", **kw) -> bool:
    return bool(_choice(title, message, [("OK", True), ("Cancel", False)], False))


def askretrycancel(title=None, message="", **kw) -> bool:
    return bool(_choice(title, message, [("Retry", True), ("Cancel", False)], False))


def _show(message) -> str:
    from . import toast
    toast(message)
    return "ok"


def showinfo(title=None, message="", **kw) -> str:
    return _show(message)


showwarning = showerror = showinfo
