"""Alerts, logging and QR error reports for translated apps and for the porting tool itself.

Pure Python (no native core needed), so `python -m tk4k.port` works anywhere.

Everything that goes wrong in a prototype port is *recorded, never hidden*:

  * every event goes to the `tk4k.port` logger (and to a log file when one is set up);
  * a footer is printed to stderr when the program ends;
  * the events become one short report string, shown as a QR code when the optional `segno`
    package is installed;
  * if the optional ErrCode plug-in is installed, the same events are recorded as ErrCode
    codes (901-909) and the report becomes an ErrCode `EC2-` report. ErrCode is PolyForm
    Noncommercial and TK 4K is Apache-2.0, so it is never bundled or required.
"""
from __future__ import annotations

import atexit
import base64
import io
import json
import logging
import os
import sys
import time
import zlib
from typing import Optional

logging.getLogger("tk4k").addHandler(logging.NullHandler())   # quiet when used as a library
log = logging.getLogger("tk4k.port")

# kind -> (ErrCode app id, severity name, message). Meaning for people reading a decoded report.
KINDS = {
    "placeholder": (1, "WARN", "A widget TK 4K does not have yet was replaced by a placeholder"),
    "unsupported": (2, "WARN", "A call TK 4K does not support yet was skipped"),
    "todo": (3, "ERROR", "The translator left part of the program untranslated"),
    "parse": (4, "ERROR", "The translator could not read the source file"),
    "crash": (5, "FATAL", "The translator itself crashed"),
    "callback": (6, "ERROR", "A callback of the translated program raised an error"),
}

_events: list[dict] = []
_state: dict = {"app": None, "installed": False, "footer_done": False, "qr": True, "file_handler": None,
                "errcode": None}


# ------------------------------------------------------------------ recording
def note(kind: str, detail: str = "", line: int = 0, *, once_key: Optional[str] = None) -> None:
    """Record one event. `once_key` makes repeats of the same event count up instead of logging again."""
    if kind not in KINDS:
        kind = "unsupported"
    key = once_key or f"{kind}:{detail}:{line}"
    for e in _events:
        if e["key"] == key:
            e["count"] += 1
            return
    _events.append({"key": key, "kind": kind, "detail": detail, "line": line, "count": 1, "t": time.time()})
    sev = KINDS[kind][1]
    msg = f"[{kind}] {detail}" + (f" (original line {line})" if line else "")
    log.log(logging.ERROR if sev in ("ERROR", "FATAL") else logging.WARNING, msg)
    ec = _state["errcode"]
    if ec is not None:
        try:
            ec.record("APP." + kind_to_key(kind), detail=(detail or kind)[:40])
        except Exception:  # ErrCode must never break the program
            pass


def kind_to_key(kind: str) -> str:
    return {"placeholder": "TK4K_PLACEHOLDER", "unsupported": "TK4K_UNSUPPORTED", "todo": "TK4K_TODO",
            "parse": "TK4K_PARSE", "crash": "TK4K_CRASH", "callback": "TK4K_CALLBACK"}[kind]


def events() -> list[dict]:
    return list(_events)


def reset() -> None:
    _events.clear()
    _state["footer_done"] = False


def has_problem() -> bool:
    return bool(_events)


# ------------------------------------------------------------------ the report string and QR
PREFIX = "TK4K1-"


def compact_payload(app: Optional[str] = None, evs: Optional[list[dict]] = None, extra: Optional[dict] = None) -> str:
    """One short string (A-Z, 2-7, '-') that fits a QR code in alphanumeric mode.

    TK4K1- + base32(zlib(json)). Kept small on purpose (at most 8 events, 32 characters each) so the QR stays
    easy to scan from a screen. Decode with `python -m tk4k.port --decode STRING`.
    """
    evs = _events if evs is None else evs
    data = {"v": 1, "app": (app or _state["app"] or "")[:24], "t": int(time.time() / 60),
            "e": [[e["kind"], e["detail"][:32], e["line"], e["count"]] for e in evs[:8]]}
    if len(evs) > 8:
        data["more"] = len(evs) - 8
    if extra:
        data["x"] = extra
    raw = zlib.compress(json.dumps(data, separators=(",", ":")).encode(), 9)
    return PREFIX + base64.b32encode(raw).decode().rstrip("=")


def decode_payload(text: str) -> dict:
    """Inverse of compact_payload. Spaces and line breaks are ignored."""
    s = "".join(text.split()).upper()
    if not s.startswith(PREFIX):
        raise ValueError("not a TK4K1 report")
    body = s[len(PREFIX):]
    body += "=" * (-len(body) % 8)
    return json.loads(zlib.decompress(base64.b32decode(body)))


def describe(data: dict) -> str:
    lines = [f"TK 4K port report for {data.get('app') or '(unnamed)'}  at {time.strftime('%Y-%m-%d %H:%M', time.gmtime(data.get('t', 0) * 60))} UTC"]
    for kind, detail, line, count in data.get("e", []):
        meaning = KINDS.get(kind, (0, "", kind))[2]
        lines.append(f"  {kind:11s} x{count:<3d} {detail}" + (f"  (line {line})" if line else "") + f"\n              {meaning}")
    if len(lines) == 1:
        lines.append("  no problems recorded")
    if data.get("more"):
        lines.append(f"  ... and {data['more']} more (see the report file)")
    for k, v in (data.get("x") or {}).items():
        lines.append(f"  {k}: {v}")
    return "\n".join(lines)


def qr_available() -> bool:
    try:
        import segno  # noqa: F401
        return True
    except ImportError:
        return False


def qr_terminal(payload: str) -> str:
    import segno
    buf = io.StringIO()
    segno.make(payload, error="m", micro=False).terminal(out=buf, compact=True)
    return buf.getvalue()


def qr_save(payload: str, path: str, scale: int = 8) -> None:
    import segno
    segno.make(payload, error="m", micro=False).save(path, scale=scale, border=4)


# ------------------------------------------------------------------ ErrCode bridge (optional)
def _try_errcode(app: Optional[str]):
    if os.environ.get("TK4K_ERRCODE", "1") == "0":
        return None
    try:
        import errcode
        from errcode import table
    except Exception:
        return None
    try:
        sev = {"WARN": table.WARN, "ERROR": table.ERROR, "FATAL": table.FATAL}
        for kind, (i, s, msg) in KINDS.items():
            errcode.define_app(i, kind_to_key(kind), sev[s], msg)
        return errcode
    except Exception:
        return None


def use_errcode(app: Optional[str] = None):
    """Switch on the optional ErrCode bridge without installing its exception hooks. Returns the module or None."""
    ec = _try_errcode(app)
    _state["errcode"] = ec
    if ec is not None:
        try:
            ec.reset()
            ec.collector().app = app
        except Exception:
            _state["errcode"] = None
            return None
    return ec


def errcode_report():
    """The ErrCode Report for this process, or None when ErrCode is not installed."""
    ec = _state["errcode"]
    if ec is None:
        return None
    try:
        return ec.report()
    except Exception:
        return None


# ------------------------------------------------------------------ install
def install_alerts(app: Optional[str] = None, *, log_file: Optional[str] = "auto", qr: bool = True,
                   stream=None) -> None:
    """Switch on logging, the exit footer and (if available) ErrCode for a translated program.

    Never raises. Call it once at the top of the program (the translator adds this line).
    """
    if _state["installed"]:
        return
    _state.update(installed=True, app=app, qr=qr, stream=stream)
    try:
        logging.getLogger("tk4k").setLevel(logging.DEBUG)
        env = os.environ.get("TK4K_LOG")          # TK4K_LOG=0 turns the log file off, TK4K_LOG=path moves it
        if env is not None:
            log_file = None if env in ("0", "") else env
        if log_file == "auto":  # next to the program that is running: name.tk4k.log
            main = getattr(sys.modules.get("__main__"), "__file__", None)
            log_file = os.path.splitext(os.path.abspath(main))[0] + ".tk4k.log" if main else None
        if log_file:
            try:
                fh = logging.FileHandler(log_file, mode="a", encoding="utf-8")
                fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%Y-%m-%d %H:%M:%S"))
                logging.getLogger("tk4k").addHandler(fh)
                _state["file_handler"] = fh
            except OSError:
                log_file = None  # read-only folder: console alerts still work
        if not any(isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
                   for h in logging.getLogger("tk4k").handlers):
            sh = logging.StreamHandler(stream or sys.stderr)
            sh.setLevel(logging.WARNING)
            sh.setFormatter(logging.Formatter("[tk4k] %(message)s"))
            logging.getLogger("tk4k").addHandler(sh)
        logging.getLogger("tk4k").propagate = False
        _state["errcode"] = _try_errcode(app)
        if _state["errcode"] is not None:
            _state["errcode"].install(app=app, show=False)  # we print one combined footer ourselves
        log.info("alerts on for %s (log file: %s, ErrCode: %s, QR: %s)", app or "?", log_file or "none",
                 "yes" if _state["errcode"] else "no", "yes" if qr_available() else "no (pip install segno)")
        atexit.register(footer)
    except Exception:  # pragma: no cover - alerts must never stop the app
        pass


def footer(stream=None) -> None:
    """Print the end-of-run summary once, if anything was recorded."""
    if _state["footer_done"] or not _events:
        return
    _state["footer_done"] = True
    out = stream or _state.get("stream") or sys.stderr
    try:
        app = _state["app"] or ""
        payload = compact_payload(app)
        ecr = errcode_report()
        print(f"\n[tk4k] {len(_events)} thing(s) to look at in {app or 'this program'}:", file=out)
        for e in _events:
            print(f"[tk4k]   {e['kind']:11s} x{e['count']:<3d} {e['detail']}", file=out)
        if ecr is not None and ecr.worst >= 1:
            print(f"[tk4k] ErrCode: {ecr.quick}  {ecr.payload}", file=out)
        else:
            print(f"[tk4k] report: {payload}", file=out)
        fh = _state.get("file_handler")
        if _state["qr"]:
            if qr_available():
                pl = ecr.payload if ecr is not None and ecr.worst >= 1 else payload
                if fh is not None:  # a PNG you can open on screen and scan with a phone
                    png = os.path.splitext(fh.baseFilename)[0] + ".qr.png"
                    try:
                        qr_save(pl, png)
                        print(f"[tk4k] QR picture: {png}", file=out)
                    except Exception:
                        pass
                if len(pl) <= 400:
                    print(qr_terminal(pl), file=out)
            else:
                print("[tk4k] (pip install segno to get this report as a QR code)", file=out)
        if fh is not None:
            print(f"[tk4k] details: {fh.baseFilename}", file=out)
    except Exception:  # pragma: no cover
        pass
