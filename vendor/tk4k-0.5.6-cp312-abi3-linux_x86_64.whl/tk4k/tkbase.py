"""Base classes with tkinter's constructor signature, for programs that subclass tkinter widgets.

    class Board(tk.Canvas):                       # tkinter
        def __init__(self, master):
            super().__init__(master, width=400, height=300, bg="black")

TK 4K's own widgets take their main values first (`Canvas(width, height)`, `Button(text, on_click=...)`), so
`super().__init__(master, ...)` would put the master where the width goes. The porter makes such classes inherit from
`ui.tkbase.Canvas` (and so on) instead: same TK 4K widget, tkinter's `(master=None, cnf=None, **options)` signature.
"""
from __future__ import annotations

from typing import Any

from . import _widgets as _w
from . import _widgets2 as _w2


def _rest(self, kw: dict) -> None:
    if kw:
        try:
            self.config(**kw)      # text/textvariable/command/state/fg...; cosmetic options are ignored
        except Exception:  # an option TK 4K cannot take must not stop the constructor
            pass


def _num(v: Any, default: float) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


class Canvas(_w2.Canvas):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        h = kw.pop("height", None)
        _w2.Canvas.__init__(self, _num(kw.pop("width", 378.0), 378.0), None if h is None else _num(h, 265.0),
                            bg=kw.pop("bg", kw.pop("background", "white")), parent=master)
        kw.pop("highlightthickness", None)
        _rest(self, kw)


class Text(_w.TextArea):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        h, w = kw.pop("height", None), kw.pop("width", None)
        _w.TextArea.__init__(self, height=_num(h, 6.0) * 20 if h is not None else 120.0, parent=master)
        if w is not None:
            self.width = _num(w, 40.0) * 8
        _rest(self, kw)


class Label(_w.Label):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w.Label.__init__(self, kw.pop("text", ""), parent=master)
        _rest(self, kw)


class Button(_w.Button):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w.Button.__init__(self, kw.pop("text", ""), on_click=kw.pop("command", None), parent=master)
        _rest(self, kw)


class Entry(_w.Entry):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w.Entry.__init__(self, parent=master)
        _rest(self, kw)


class Listbox(_w2.Listbox):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w2.Listbox.__init__(self, height=int(_num(kw.pop("height", 10), 10)),
                             selectmode=str(kw.pop("selectmode", "browse")), parent=master)
        _rest(self, kw)


class Checkbutton(_w.Checkbox):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w.Checkbox.__init__(self, kw.pop("text", ""), parent=master)
        _rest(self, kw)


class Scale(_w.Slider):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w.Slider.__init__(self, lo=_num(kw.pop("from_", 0), 0.0), hi=_num(kw.pop("to", 100), 100.0), parent=master)
        kw.setdefault("resolution", 1)      # tkinter's default: whole numbers
        _rest(self, kw)


class Spinbox(_w2.Spinbox):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w2.Spinbox.__init__(self, _num(kw.pop("from_", 0), 0.0), _num(kw.pop("to", 100), 100.0),
                             _num(kw.pop("increment", 1), 1.0), values=kw.pop("values", None), parent=master)
        _rest(self, kw)


class Treeview(_w2.Tree):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w2.Tree.__init__(self, tuple(kw.pop("columns", ())), show=kw.pop("show", "tree headings"),
                          selectmode=kw.pop("selectmode", "browse"), parent=master)
        _rest(self, kw)


class Combobox(_w.Dropdown):
    def __init__(self, master: Any = None, cnf: Any = None, **kw: Any):
        kw = dict(cnf or {}, **kw)
        _w.Dropdown.__init__(self, list(kw.pop("values", ()) or ()), index=-1, parent=master,   # blank until chosen, like ttk
                             editable=kw.pop("state", "normal") != "readonly")
        _rest(self, kw)


Message = Label
# tkinter class name -> adapter (the porter uses this table)
ADAPTERS = {"Canvas": "Canvas", "Text": "Text", "ScrolledText": "Text", "Label": "Label", "Message": "Message",
            "Button": "Button", "Entry": "Entry", "Listbox": "Listbox", "Checkbutton": "Checkbutton",
            "Scale": "Scale", "Spinbox": "Spinbox", "Treeview": "Treeview", "Combobox": "Combobox"}
