"""TK 4K: a small, modern, Tk-shaped GUI toolkit for Python.

    import tk4k as ui

    name = ui.Var("")
    with ui.Window("Hello", size=(400, 200)) as win:
        ui.Label("Your name:")
        ui.Entry(var=name)
        ui.Button("Greet", on_click=lambda: win.toast(f"Hi {name.get()}"), primary=True)
    win.run()
"""
from ._theme import DARK, LIGHT, THEMES, Theme
from ._dialogs import (TclError, askcolor, askdirectory, askfloat, askinteger, askopenfile, askopenfilename,
                       askopenfilenames, askopenfiles, askquestion, asksaveasfile, asksaveasfilename, askstring,
                       askyesnocancel, askyesno, askokcancel, askretrycancel, showinfo, showwarning, showerror,
                       dialog_answers)

try:  # the native part (SDL3 + Dear ImGui). tk4k.classic works without it.
    from . import _core  # noqa: F401
    from ._widgets import (Button, Checkbox, Column, Container, Entry, Grid, Label, Placeholder,
                           Progress, QRView, Row, Separator, Slider, Spacer, Table, TextArea, Dropdown, Frame, LabelFrame,
                           Var, Widget, get_clipboard, set_clipboard, unsupported, _with_options)
    from ._widgets2 import (Canvas, Dialog, Listbox, Menu, Radio, Scrollbar, Spinbox, Style, Tab, Tabs, Toplevel,
                            Tree, Font, SimpleDialog, families, nametofont, ask_open_file, ask_string, ask_yes_no, message)
    from ._window import Window
    from ._image import PhotoImage
    from . import tkbase  # noqa: F401  (tkinter-signature base classes for ported subclasses)
except ImportError as _native_error:  # pragma: no cover  (only when the compiled module is missing)
    _NATIVE_ERROR = _native_error

    def __getattr__(name):
        if name.startswith("_") or name in ("port", "classic", "testing"):
            raise AttributeError(name)  # submodules that work without the compiled core
        raise ImportError(f"tk4k.{name} needs the compiled core, which could not be loaded: {_NATIVE_ERROR}")

def _window_now():
    from ._window import _current
    return _current[-1] if _current else None


def mainloop(n=0):
    """tkinter's module-level mainloop(): run the most recently created Window."""
    from ._window import Window
    w = _window_now()
    if w is not None:
        Window.run(w)   # not w.run(): a subclass may define its own run()


def toast(text, *a, **k):
    """What translated messagebox.showinfo(...) calls become: a short message on the current window."""
    w = _window_now()
    if w is not None:
        w.toast(str(text))


def ask(text, default=True, *a, **k):
    """messagebox.askyesno/askokcancel: a real dialog that waits for the answer. See tk4k._dialogs."""
    from ._dialogs import ask as _ask
    return _ask(text, default, *a, **k)


def install_alerts(*args, **kwargs):
    """Logging, an exit footer and QR error reports for translated apps. See tk4k._alerts."""
    from ._alerts import install_alerts as _install
    return _install(*args, **kwargs)


__version__ = "0.5.6"
__build_date__ = "2026-11-22 17:50"

CREDITS = (
    "TK 4K stands on decades of work by people far smarter than the person writing this. "
    "Tcl and Tk were created by John Ousterhout and are kept alive by the Tcl Core Team. "
    "tkinter was written by Steen Lumholt and Guido van Rossum, documented by Fredrik Lundh, "
    "and looked after by many maintainers since. Omar Cornut built Dear ImGui and the SDL team "
    "built SDL. Every one of them gave up time and sleep so the rest of us could build things. "
    "TK 4K only exists because they did. It is not affiliated with Tcl/Tk.\n\n"
    "The author's own contribution is a little over a thousand lines of glue, and a firm belief that "
    "Python is written in snake hisses rather than binary. "
    "Any bugs are mine; the good ideas are theirs."
)

__all__ = ["PhotoImage", "Font", "families", "nametofont", "SimpleDialog", "Button", "Checkbox", "Column", "Container", "CREDITS", "DARK", "Entry", "Grid", "LIGHT",
           "Canvas", "Dialog", "Listbox", "Menu", "Radio", "Scrollbar", "Spinbox", "Style", "Tab", "Tabs", "Toplevel", "Tree", "ask_open_file", "ask_string", "TclError", "askcolor", "askdirectory", "askfloat", "askinteger", "askopenfile", "askopenfilename", "askopenfilenames", "askopenfiles", "askquestion", "asksaveasfile", "asksaveasfilename", "askstring", "askyesnocancel", "askyesno", "askokcancel", "askretrycancel", "showinfo", "showwarning", "showerror", "dialog_answers", "ask_yes_no", "message", "mainloop", "toast", "ask", "Label", "Frame", "LabelFrame", "Placeholder", "Progress", "QRView", "Table", "TextArea", "Dropdown", "get_clipboard", "set_clipboard", "Row", "Separator", "Slider", "Spacer", "THEMES", "Theme", "Var",
           "Widget", "Window", "install_alerts", "unsupported", "__version__", "__build_date__"]
