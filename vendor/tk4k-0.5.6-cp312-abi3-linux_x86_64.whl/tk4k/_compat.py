"""The safety net for tkinter methods TK 4K does not have yet.

Real tkinter code calls hundreds of methods (439 public names across the widget classes, see _tkapi.py). TK 4K has
most of the ones programs use; for the rest, an AttributeError is the worst outcome: the program stops on a call that
usually only tweaks something (`root.overrideredirect(1)`, `text.tag_raise("sel")`). So a *tkinter* method TK 4K lacks
becomes a no-op that returns a harmless default and is recorded once in the log, the exit footer and the QR report.

Names that are not tkinter methods still raise AttributeError (a typo in the program must still be a typo), and
private names are never caught. Set TK4K_STRICT_API=1 to get the AttributeError back (used to measure gaps).
"""
from __future__ import annotations

import os
from typing import Any

from ._tkapi import ALL

_TUPLE = ("bbox", "coords", "curselection", "find", "gettags", "tag_ranges", "tag_names", "mark_names", "panes",
          "slaves", "image_names", "window_names", "peer_names", "children", "selection", "event_info", "identify")


def strict() -> bool:
    return os.environ.get("TK4K_STRICT_API") == "1"


def default_for(name: str) -> Any:
    """What a skipped call returns: something the next line of a typical program can use."""
    if name.startswith("winfo_"):
        return 0
    if name.startswith(_TUPLE) or name.endswith(("_bbox", "_names", "_slaves", "_ranges")):
        return ()
    if name in ("index", "count", "compare", "getint", "getdouble", "getboolean"):
        return 0
    return None


def missing(obj: Any, name: str):
    """Called from __getattr__ of TK 4K classes: a logged no-op for tkinter method names, AttributeError otherwise."""
    cls = type(obj).__name__
    if name == "tk":
        return NoTcl()
    if name.startswith("_") or name not in ALL:
        raise AttributeError(f"'{cls}' object has no attribute '{name}'")
    if strict():
        raise AttributeError(f"'{cls}' object has no attribute '{name}' (a tkinter method TK 4K does not have yet)")

    def skipped(*a: Any, **k: Any) -> Any:
        from . import _alerts
        _alerts.note("unsupported", f"{cls}.{name}() is a tkinter method TK 4K does not have yet; ignored",
                     once_key=f"api:{cls}.{name}")
        return default_for(name)
    skipped.__name__ = name
    return skipped


class NoTcl:
    """`widget.tk`: real tkinter's Tcl interpreter. TK 4K has none, so any use says so clearly (TclError, not a crash
    deep inside). Programs that need it should run with tk4k.classic."""

    def __getattr__(self, name: str):
        if name.startswith("__"):
            raise AttributeError(name)

        def call(*a: Any, **k: Any):
            from ._dialogs import TclError
            raise TclError(f"tk.{name}(): TK 4K has no Tcl interpreter; run this program with python -m tk4k.classic")
        return call
