"""Themes: a handful of colours, plus shape. Change one number, restyle the whole app."""
from __future__ import annotations

from dataclasses import dataclass, field


def _mix(a: int, b: int, t: float) -> int:
    """Blend colour a towards colour b by t (0..1). Colours are 0xRRGGBB."""
    out = 0
    for shift in (16, 8, 0):
        ca, cb = (a >> shift) & 255, (b >> shift) & 255
        out |= int(round(ca + (cb - ca) * t)) << shift
    return out


@dataclass
class Theme:
    """Colours are 0xRRGGBB integers. Sizes are in design pixels (scaled for high-DPI)."""

    bg: int
    surface: int
    widget: int
    hover: int
    active: int
    text: int
    text_dim: int
    accent: int
    accent_hover: int
    accent_active: int
    border: int
    on_accent: int = 0xFFFFFF
    dark: bool = True
    rounding: float = 6.0
    pad_x: float = 10.0
    pad_y: float = 6.0
    gap: float = 8.0
    font_size: float = 16.0

    def colours(self) -> list[int]:
        return [self.bg, self.surface, self.widget, self.hover, self.active, self.text,
                self.text_dim, self.accent, self.accent_hover, self.accent_active,
                self.border, self.on_accent]

    @classmethod
    def make(cls, dark: bool = True, accent: int | None = None, **shape) -> "Theme":
        if dark:
            accent = 0x4C8DFF if accent is None else accent
            return cls(bg=0x14161B, surface=0x1B1E25, widget=0x242832, hover=0x2D3340,
                       active=0x384153, text=0xE6E8EC, text_dim=0x8B93A1,
                       accent=accent, accent_hover=_mix(accent, 0xFFFFFF, 0.18),
                       accent_active=_mix(accent, 0x000000, 0.18), border=0x303644,
                       dark=True, **shape)
        accent = 0x2F6FEB if accent is None else accent
        return cls(bg=0xF3F4F7, surface=0xFFFFFF, widget=0xFFFFFF, hover=0xEBEEF4,
                   active=0xDDE3EE, text=0x1D2129, text_dim=0x6B7380,
                   accent=accent, accent_hover=_mix(accent, 0xFFFFFF, 0.15),
                   accent_active=_mix(accent, 0x000000, 0.18), border=0xCDD2DB,
                   dark=False, **shape)


DARK = Theme.make(True)
LIGHT = Theme.make(False)
THEMES = {"dark": DARK, "light": LIGHT}
