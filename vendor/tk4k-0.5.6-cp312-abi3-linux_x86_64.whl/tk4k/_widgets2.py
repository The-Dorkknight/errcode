"""TK 4K 0.4.0 widgets: the hard ones. Canvas, Menu, Tabs, Radio, Spinbox, Listbox, Tree, Dialog (+ in-app file dialog).

Method names follow tkinter on purpose (insert, delete, curselection, create_line, add_command ...) so translated
code keeps working, but every widget also has plain Python properties for new code.
"""
from __future__ import annotations

import os
from typing import Any, Callable, Optional

from . import _core
from ._widgets import (Frame, _SizeAttr, _rgb_name, Button, Column, Container, Entry, Label, Row, Separator, Var, Widget, _compat_note, _Event,
                       _queue, _rgb, _val)

# ---------------------------------------------------------------------------------------- colours
_NAMED = {"white": "#ffffff", "black": "#000000", "red": "#ff0000", "green": "#008000", "blue": "#0000ff",
          "yellow": "#ffff00", "gray": "#bebebe", "grey": "#bebebe", "orange": "#ffa500", "purple": "#a020f0",
          "cyan": "#00ffff", "magenta": "#ff00ff", "pink": "#ffc0cb", "brown": "#a52a2a", "lightblue": "#add8e6",
          "lightgray": "#d3d3d3", "darkgray": "#a9a9a9", "navy": "#000080", "gold": "#ffd700"}


def _col(c: Any, default: Optional[str] = None):
    if c is None or c == "":
        c = default
    if c is None:
        return None
    if isinstance(c, str):
        c = _NAMED.get(c.lower(), c)
        if not c.startswith("#"):
            return _rgb_name(c)   # the long table of Tk colour names lives in _widgets (None if unknown)
    return _rgb(c)


# ---------------------------------------------------------------------------------------- Canvas
class Canvas(Widget):
    """Retained 2-D drawing area with tkinter's item API: create_line/rectangle/oval/polygon/text, move, delete, itemconfig."""

    def __init__(self, width: float = 378.0, height: Optional[float] = None, *, bg: str = "white", **kw):  # Tk's own default is 10c x 7c
        super().__init__(**kw)
        self._explicit_h = height is not None   # a canvas holding windows is exactly this tall and scrolls inside
        self.cw, self.ch, self.bg = float(width), float(height if height is not None else 265.0), bg
        self._items: dict[int, dict] = {}
        self._next = 1
        self._handlers: dict[str, Callable] = {}
        self._was_down = False

    # --- creating items (return an id, like tkinter)
    def _add(self, kind: str, coords: list, opts: dict) -> int:
        i = self._next
        self._next += 1
        tags = opts.pop("tags", ())
        self._items[i] = {"k": kind, "c": [float(v) for v in coords], "o": opts,
                          "t": {tags} if isinstance(tags, str) else set(tags)}
        _core.wake()
        return i

    def create_line(self, *coords, **o):
        return self._add("line", _flat(coords), o)

    def create_rectangle(self, *coords, **o):
        return self._add("rect", _flat(coords), o)

    def create_oval(self, *coords, **o):
        return self._add("oval", _flat(coords), o)

    def create_polygon(self, *coords, **o):
        return self._add("poly", _flat(coords), o)

    def create_arc(self, *coords, **o):
        """Arc, pieslice or chord inside the box x1,y1,x2,y2: start/extent in degrees, counter-clockwise from 3 o'clock.
        Drawn as a polygon (or a line for style='arc'), so it moves, scales and finds like any other item."""
        import math
        x1, y1, x2, y2 = _flat(coords)[:4]
        start, extent, style = float(o.pop("start", 0)), float(o.pop("extent", 90)), o.pop("style", "pieslice")
        cx, cy, rx, ry = (x1 + x2) / 2, (y1 + y2) / 2, abs(x2 - x1) / 2, abs(y2 - y1) / 2
        n = max(2, int(abs(extent) / 6) + 1)
        pts: list = []
        for i in range(n + 1):
            a = math.radians(start + extent * i / n)
            pts += [cx + rx * math.cos(a), cy - ry * math.sin(a)]
        if style == "arc":
            o["fill"] = o.pop("outline", None) or o.get("fill") or "black"
            return self._add("line", pts, o)
        return self._add("poly", ([cx, cy] + pts) if style == "pieslice" else pts, o)

    def create_text(self, x, y=None, **o):
        if y is None:  # create_text((x, y), ...) is also valid tkinter
            x, y = x
        o.setdefault("text", "")
        return self._add("text", [x, y], o)

    def create_image(self, x, y=None, **o):
        """create_image(x, y, image=PhotoImage, anchor='center'|'nw'|...); the position may be one (x, y) pair."""
        if y is None:
            x, y = x
        return self._add("image", [x, y], o)

    def winfo_width(self):
        """Before the first frame there is no measured rectangle yet: answer with the size the canvas will have."""
        self._fill_size()
        return int(self._rect[2]) if self._rect[2] > 1 else int(self.cw)

    def winfo_height(self):
        self._fill_size()
        return int(self._rect[3]) if self._rect[3] > 1 else int(self.ch)

    winfo_reqwidth, winfo_reqheight = winfo_width, winfo_height

    def postscript(self, *a, **k) -> str:
        """Canvas.postscript writes the drawing as PostScript; TK 4K cannot, so it says so and returns ''."""
        _compat_note("Canvas.postscript is not supported (no PostScript export)")
        return ""

    def create_window(self, x, y=None, **o):
        """create_window((x, y), window=widget): the classic scrollable-frame idiom. A canvas that holds a window item
        is drawn as a scrolling region showing that widget (the mouse wheel scrolls it); positions are not used."""
        if y is None and isinstance(x, (tuple, list)):
            x, y = x
        w = o.get("window")
        if w is not None:
            w.master = None  # it is drawn by this canvas, not by the container it was created in
        _compat_note("create_window: the widget is shown in a scrolling region; its x/y position is not used")
        return self._add("window", [x, y or 0], o)

    def _box(self, it: dict) -> tuple[float, float, float, float]:
        k, c, o = it["k"], it["c"], it["o"]
        if k == "window":
            r = getattr(o.get("window"), "_rect", None) or (0.0, 0.0, self.cw, self.ch)
            return 0.0, 0.0, float(r[2]), float(r[3])
        if k == "image":
            im = o.get("image")
            w, h = (im.w, im.h) if im is not None else (0, 0)
            x, y = _anchor(c[0], c[1], w, h, o.get("anchor", "center"))
            return x, y, x + w, y + h
        if k == "text":
            w = 7.0 * len(str(o.get("text", "")))
            x, y = _anchor(c[0], c[1], w, 16.0, o.get("anchor", "center"))
            return x, y, x + w, y + 16.0
        xs, ys = c[0::2], c[1::2]
        pad = float(o.get("width", 1)) / 2 + (2.0 if k == "line" else 0.0)
        return min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad

    def bbox(self, *what):
        boxes = [self._box(self._items[i]) for w in (what or ("all",)) for i in self._which(w)]
        if not boxes:
            return None
        return (int(min(b[0] for b in boxes)), int(min(b[1] for b in boxes)),
                int(max(b[2] for b in boxes)), int(max(b[3] for b in boxes)))

    def find_overlapping(self, x1, y1, x2, y2):
        return tuple(i for i, it in self._items.items()
                     if (lambda b: b[0] <= x2 and b[2] >= x1 and b[1] <= y2 and b[3] >= y1)(self._box(it)))

    def find_closest(self, x, y, *a):
        hit = self.find_overlapping(x, y, x, y)
        if hit:
            return (hit[-1],)
        if not self._items:
            return ()
        def d(i):
            b = self._box(self._items[i])
            return (max(b[0] - x, 0, x - b[2])) ** 2 + (max(b[1] - y, 0, y - b[3])) ** 2
        return (min(self._items, key=d),)

    def find_withtag(self, what):
        return tuple(self._which(what))

    def gettags(self, what):
        ids = self._which(what)
        return tuple(sorted(self._items[ids[0]]["t"])) if ids else ()

    def addtag_withtag(self, new, what):
        for i in self._which(what):
            self._items[i]["t"].add(new)

    def dtag(self, what, tag=None):
        for i in self._which(what):
            self._items[i]["t"].discard(tag if tag is not None else what)

    def tag_raise(self, what, above=None):
        for i in self._which(what):
            self._items[i] = self._items.pop(i)  # dicts keep order: last drawn = on top
        _core.wake()

    lift = tag_raise

    def tag_lower(self, what, below=None):
        ids = self._which(what)
        keep = {i: self._items[i] for i in ids}
        rest = {i: v for i, v in self._items.items() if i not in keep}
        self._items = {**keep, **rest}
        _core.wake()

    def type(self, what):
        ids = self._which(what)
        names = {"rect": "rectangle", "poly": "polygon"}
        return names.get(self._items[ids[0]]["k"], self._items[ids[0]]["k"]) if ids else None

    # --- editing items
    def _which(self, what) -> list[int]:
        if what == "all":
            return list(self._items)
        if isinstance(what, int):
            return [what] if what in self._items else []
        return [i for i, it in self._items.items() if what in it["t"]]

    def delete(self, *what) -> None:
        for w in what:
            for i in self._which(w):
                self._items.pop(i, None)
        _core.wake()

    def move(self, what, dx, dy) -> None:
        for i in self._which(what):
            c = self._items[i]["c"]
            for k in range(0, len(c) - 1, 2):
                c[k] += dx
                c[k + 1] += dy
        _core.wake()

    def coords(self, what, *new):
        ids = self._which(what)
        if not ids:
            return []
        if new:
            self._items[ids[0]]["c"] = [float(v) for v in _flat(new)]
            _core.wake()
        return list(self._items[ids[0]]["c"])

    def itemconfig(self, what, **o) -> None:
        for i in self._which(what):
            self._items[i]["o"].update(o)
        _core.wake()

    itemconfigure = itemconfig

    def itemcget(self, what, option):
        ids = self._which(what)
        return self._items[ids[0]]["o"].get(option) if ids else None

    def find_all(self):
        return tuple(self._items)

    # --- 0.5.5: the rest of the item API real programs use
    def canvasx(self, screenx, gridspacing=None):
        return float(screenx)   # TK 4K canvases do not scroll their own coordinates

    def canvasy(self, screeny, gridspacing=None):
        return float(screeny)

    def find_enclosed(self, x1, y1, x2, y2):
        return tuple(i for i, it in self._items.items()
                     if (lambda b: b[0] >= x1 and b[1] >= y1 and b[2] <= x2 and b[3] <= y2)(self._box(it)))

    def find_above(self, what):
        ids, order = self._which(what), list(self._items)
        if not ids:
            return ()
        k = order.index(ids[-1])
        return (order[k + 1],) if k + 1 < len(order) else ()

    def find_below(self, what):
        ids, order = self._which(what), list(self._items)
        if not ids:
            return ()
        k = order.index(ids[0])
        return (order[k - 1],) if k > 0 else ()

    def find(self, command, *args):
        return getattr(self, "find_" + str(command))(*args)

    def addtag(self, new, command, *args):
        for i in self.find(command, *args):
            self._items[i]["t"].add(new)

    addtag_all = lambda self, new: self.addtag(new, "all")  # noqa: E731
    addtag_above = lambda self, new, what: self.addtag(new, "above", what)  # noqa: E731
    addtag_below = lambda self, new, what: self.addtag(new, "below", what)  # noqa: E731
    addtag_closest = lambda self, new, x, y, *a: self.addtag(new, "closest", x, y)  # noqa: E731
    addtag_enclosed = lambda self, new, *b: self.addtag(new, "enclosed", *b)  # noqa: E731
    addtag_overlapping = lambda self, new, *b: self.addtag(new, "overlapping", *b)  # noqa: E731

    def moveto(self, what, x="", y=""):
        """Move so the item's top-left corner is at (x, y); an empty string keeps that coordinate."""
        b = self.bbox(what)
        if b is None:
            return
        dx = float(x) - b[0] if x != "" else 0.0
        dy = float(y) - b[1] if y != "" else 0.0
        self.move(what, dx, dy)

    def scale(self, what, xorigin, yorigin, xscale, yscale):
        for i in self._which(what):
            c = self._items[i]["c"]
            for k in range(0, len(c) - 1, 2):
                c[k] = float(xorigin) + (c[k] - float(xorigin)) * float(xscale)
                c[k + 1] = float(yorigin) + (c[k + 1] - float(yorigin)) * float(yscale)
        _core.wake()

    # text items: insert / dchars / index (icursor and selection are accepted)
    def _textix(self, it, index):
        t = str(it["o"].get("text", ""))
        return len(t) if str(index) in ("end", "insert") else max(0, min(len(t), int(index)))

    def insert(self, what, index, string):
        for i in self._which(what):
            it = self._items[i]
            if it["k"] == "text":
                t, k = str(it["o"].get("text", "")), self._textix(it, index)
                it["o"]["text"] = t[:k] + str(string) + t[k:]
        _core.wake()

    def dchars(self, what, first, last=None):
        for i in self._which(what):
            it = self._items[i]
            if it["k"] == "text":
                t = str(it["o"].get("text", ""))
                a = self._textix(it, first)
                b = self._textix(it, last) + 1 if last is not None else a + 1
                it["o"]["text"] = t[:a] + t[b:]
        _core.wake()

    def index(self, what, index):
        ids = [i for i in self._which(what) if self._items[i]["k"] == "text"]
        return self._textix(self._items[ids[0]], index) if ids else 0

    icursor = select_adjust = select_from = select_to = lambda self, *a: None  # noqa: E731
    select_clear = lambda self: None  # noqa: E731
    select_item = lambda self: None  # noqa: E731

    def tag_bind(self, what, seq, fn=None, add=None):
        """Item events: <Button-1> on any item with that tag/id is checked against the click point."""
        if fn is not None:
            self.__dict__.setdefault("_tagb", []).append((what, str(seq), fn))

    def tag_unbind(self, what, seq, funcid=None):
        self.__dict__["_tagb"] = [t for t in self.__dict__.get("_tagb", []) if t[:2] != (what, str(seq))]

    _OWN = {"<Button-1>": "<Button-1>", "<1>": "<Button-1>", "<ButtonPress-1>": "<Button-1>",
            "<B1-Motion>": "<B1-Motion>", "<ButtonRelease-1>": "<ButtonRelease-1>", "<Motion>": "<Motion>"}

    def bind(self, seq, fn=None, add=None):
        """<Button-1>, <B1-Motion>, <ButtonRelease-1>, <Motion> with canvas x/y; others (<Button-3>, <MouseWheel>,
        <Configure>, keys...) go to the generic widget path."""
        if fn is None:
            return
        own = self._OWN.get(str(seq))
        if own:
            self._handlers[own] = fn
        else:
            super().bind(seq, fn, add)

    # --- drawing
    def _draw_windows(self, wins) -> None:
        h = max(self.ch, 260.0) if not self.__dict__.get("_explicit_h") else self.ch
        if _core.begin_child(f"##cw{self._id}", -1.0, float(h), False):
            try:
                for it in wins:
                    w = it["o"].get("window")
                    if w is not None:
                        w._render()
            finally:
                _core.end_child()

    def _fill_size(self) -> None:
        """pack(fill='both', expand=True): the canvas takes the free room, so winfo_width()/height() match tkinter's."""
        pk = getattr(self, "_pack", None) or {}
        fill = str(pk.get("fill", "")).lower()
        if fill not in ("both", "x", "y"):
            return
        ww, wh = _core.window_size()
        x, y = self._rect[0], self._rect[1]
        below = 0.0
        if self.master is not None:
            kids = getattr(self.master, "_children", [])
            if self in kids:   # about one button row of room for each visible widget packed after the canvas
                below = 36.0 * sum(1 for c in kids[kids.index(self) + 1:] if c._visible)
        if fill in ("both", "x"):
            self.cw = max(self.cw, ww - x - 12.0)
        if fill in ("both", "y"):
            self.ch = max(self.ch, wh - y - 12.0 - below)

    def _draw(self) -> None:
        wins = [it for it in self._items.values() if it["k"] == "window"]
        if not (wins and self._explicit_h):   # a scrolling window-holder keeps the size it was given
            self._fill_size()
        if wins:
            self._draw_windows(wins)
            return
        bg = _col(self.bg, "#ffffff") or (1.0, 1.0, 1.0)
        x, y, hov, down, pressed, released = _core.canvas_begin("##canvas", self.cw, self.ch, *bg)
        try:
            for it in list(self._items.values()):
                self._paint(it)
        finally:
            _core.canvas_end()
        ev = _CanvasEvent(self, x, y)
        h = self._handlers
        if pressed and "<Button-1>" in h:
            _queue(h["<Button-1>"], ev)
        if down and not pressed and "<B1-Motion>" in h:
            _queue(h["<B1-Motion>"], ev)
        if hov and "<Motion>" in h and not down:
            _queue(h["<Motion>"], ev)
        if self._was_down and not down and "<ButtonRelease-1>" in h:
            _queue(h["<ButtonRelease-1>"], ev)
        tb = self.__dict__.get("_tagb")
        if tb:
            self._fire_tags(tb, x, y, hov, down, pressed, ev)
        self._was_down = down

    _SEQ = {"<Button-1>": "press", "<1>": "press", "<ButtonPress-1>": "press", "<ButtonRelease-1>": "release",
            "<B1-Motion>": "drag", "<Enter>": "enter", "<Leave>": "leave", "<Motion>": "motion",
            "<Double-Button-1>": "double", "<Double-1>": "double"}

    def _fire_tags(self, tb, x, y, hov, down, pressed, ev) -> None:
        """tag_bind: the topmost item under the mouse gets the event (and the one grabbed on press keeps the drag)."""
        hit = self.find_overlapping(x, y, x, y) if hov else ()
        top = hit[-1] if hit else None
        if pressed:
            self.__dict__["_grab"] = top
        grab = self.__dict__.get("_grab")
        was = self.__dict__.get("_over")
        dbl = pressed and _core.mouse_state()[5]
        last = self.__dict__.get("_last_xy")
        moved = last is not None and (abs(last[0] - x) + abs(last[1] - y)) > 0.5
        self.__dict__["_last_xy"] = (x, y)
        for what, seq, fn in tb:
            kind = self._SEQ.get(seq)
            mine = set(self._which(what))
            if kind == "press" and pressed and top in mine:
                _queue(fn, ev)
            elif kind == "double" and dbl and top in mine:
                _queue(fn, ev)
            elif kind == "drag" and down and not pressed and grab in mine and moved:
                _queue(fn, ev)
            elif kind == "release" and self._was_down and not down and grab in mine:
                _queue(fn, ev)
            elif kind == "motion" and top in mine and not down:
                _queue(fn, ev)
            elif kind == "enter" and top in mine and was not in mine:
                _queue(fn, ev)
            elif kind == "leave" and was in mine and top not in mine:
                _queue(fn, ev)
        self.__dict__["_over"] = top
        if not down:
            self.__dict__["_grab"] = None

    def _paint(self, it: dict) -> None:
        k, c, o = it["k"], it["c"], it["o"]
        fill = _col(o.get("fill"))
        out = _col(o.get("outline"), "#000000")
        wd = float(o.get("width", 1))
        if k == "line":
            col = fill or (0.0, 0.0, 0.0)
            for a in range(0, len(c) - 3, 2):
                _core.cv_line(c[a], c[a + 1], c[a + 2], c[a + 3], *col, wd)
        elif k in ("rect", "oval", "poly"):
            f = (*fill, 1.0) if fill else (0.0, 0.0, 0.0, -1.0)
            ln = (*out, 1.0) if (out and wd > 0 and o.get("outline", "x") != "") else (0.0, 0.0, 0.0, -1.0)
            if k == "rect":
                _core.cv_rect(*c[:4], *f, *ln, wd)
            elif k == "oval":
                _core.cv_oval(*c[:4], *f, *ln, wd)
            else:
                _core.cv_poly(c, *f, *ln, wd)
        elif k == "text":
            x1, y1, _x2, _y2 = self._box(it)
            _core.cv_text(x1, y1, str(o.get("text", "")), *(fill or (0.0, 0.0, 0.0)))
        elif k == "image" and o.get("image") is not None:
            im = o["image"]
            x1, y1, x2, y2 = self._box(it)
            _core.cv_image(im._handle(), x1, y1, x2 - x1, y2 - y1)


def _anchor(x, y, w, h, a) -> tuple[float, float]:
    """tkinter anchors: the point (x, y) is the item's n/s/e/w/nw/.../center."""
    a = str(a or "center").lower()
    if a == "center":  # "center" contains the letters n and e, so it must not reach the compass tests below
        return x - w / 2, y - h / 2
    dx = 0.0 if "w" in a else (-w if "e" in a else -w / 2)
    dy = 0.0 if "n" in a else (-h if "s" in a else -h / 2)
    return x + dx, y + dy


class _TabIndex(int):
    def __new__(cls, v, tabs):
        o = super().__new__(cls, v)
        o._tabs = tabs
        return o

    def __call__(self, t: Any = "current") -> int:
        return self._tabs._pos(t)


class _CanvasEvent(_Event):
    def __init__(self, w, x, y):
        super().__init__(w)
        self.x, self.y = int(x), int(y)


def _flat(coords) -> list:
    out: list = []
    for c in coords:
        if isinstance(c, (list, tuple)):
            out += list(c)
        else:
            out.append(c)
    return out


# ---------------------------------------------------------------------------------------- Menu
class Menu:
    """A menu bar, a drop-down or a right-click popup. Build it like tkinter: add_command / add_separator /
    add_cascade / add_checkbutton / add_radiobutton; change items with entryconfig(index, state=..., label=...).

    Attach the top-level Menu with `window.config(menu=bar)` or `window.menubar = bar`; show a popup with
    `menu.tk_popup(event.x_root, event.y_root)`.
    """

    def __init__(self, parent: Any = None, *, tearoff: Any = 0, **_ignored):
        # each entry: [kind, label, command, accelerator, variable, value, options]; kind cmd|chk|rad|sep|sub
        self.entries: list[list] = []
        self.__dict__["_parent"] = parent

    def _entry(self, kind, label="", command=None, accelerator="", variable=None, value=None, menu=None, **o):
        if kind == "sub":
            return ["sub", str(label), None, "", None, None, dict(o, menu=menu)]
        return [kind, str(label), command, str(accelerator or ""), variable, value, o]

    def add(self, itemType: str, cnf: Any = None, **kw):
        kind = {"command": "cmd", "checkbutton": "chk", "radiobutton": "rad", "separator": "sep",
                "cascade": "sub"}.get(str(itemType), "cmd")
        kw = dict(cnf or {}, **kw)
        self.entries.append(["sep", "", None, "", None, None, {}] if kind == "sep" else self._entry(kind, **kw))

    def add_command(self, cnf: Any = None, **kw):
        self.add("command", cnf, **kw)

    def add_checkbutton(self, cnf: Any = None, **kw):
        self.add("checkbutton", cnf, **kw)

    def add_radiobutton(self, cnf: Any = None, **kw):
        """A radio entry: ticked while `variable` equals `value`; choosing it sets the variable."""
        self.add("radiobutton", cnf, **kw)

    def add_separator(self, cnf: Any = None, **kw):
        self.add("separator")

    def add_cascade(self, cnf: Any = None, **kw):
        self.add("cascade", cnf, **kw)

    def insert(self, index: Any, itemType: str, cnf: Any = None, **kw):
        self.add(itemType, cnf, **kw)
        e = self.entries.pop()
        self.entries.insert(self._ix(index, end_is_len=True), e)

    insert_command = lambda self, index, cnf=None, **kw: self.insert(index, "command", cnf, **kw)  # noqa: E731
    insert_checkbutton = lambda self, index, cnf=None, **kw: self.insert(index, "checkbutton", cnf, **kw)  # noqa: E731
    insert_radiobutton = lambda self, index, cnf=None, **kw: self.insert(index, "radiobutton", cnf, **kw)  # noqa: E731
    insert_separator = lambda self, index, cnf=None, **kw: self.insert(index, "separator")  # noqa: E731
    insert_cascade = lambda self, index, cnf=None, **kw: self.insert(index, "cascade", cnf, **kw)  # noqa: E731

    def _ix(self, index: Any, end_is_len: bool = False) -> int:
        n = len(self.entries)
        if index in ("end", "last"):
            return n if end_is_len else n - 1
        if index in ("active",):
            return self.__dict__.get("_active", 0)
        if isinstance(index, int) or str(index).isdigit():
            return int(index)
        if str(index).startswith("@"):
            return 0
        for i, e in enumerate(self.entries):   # a label pattern, as in tkinter
            if e[0] != "sep" and e[1] == str(index):
                return i
        from ._dialogs import TclError
        raise TclError(f'bad menu entry index "{index}"')

    def index(self, index: Any):
        return None if not self.entries and index in ("end", "last") else self._ix(index)

    def delete(self, index1: Any, index2: Any = None):
        a = self._ix(index1)
        b = self._ix(index2) if index2 is not None else a
        del self.entries[a:b + 1]
        _core.wake()

    def entryconfig(self, index: Any, cnf: Any = None, **kw):
        e = self.entries[self._ix(index)]
        for k, v in dict(cnf or {}, **kw).items():
            if k == "label":
                e[1] = str(v)
            elif k == "command":
                e[2] = v
            elif k == "accelerator":
                e[3] = str(v)
            elif k == "variable":
                e[4] = v
            elif k == "value":
                e[5] = v
            elif k == "menu" and e[0] == "sub":
                e[6]["menu"] = v
            else:
                e[6][k] = v
        _core.wake()

    entryconfigure = entryconfig

    def entrycget(self, index: Any, option: str):
        e = self.entries[self._ix(index)]
        return {"label": e[1], "command": e[2], "accelerator": e[3], "variable": e[4], "value": e[5]}.get(
            option, e[6].get(option, "normal" if option == "state" else ""))

    def type(self, index: Any) -> str:
        return {"cmd": "command", "chk": "checkbutton", "rad": "radiobutton", "sep": "separator",
                "sub": "cascade"}[self.entries[self._ix(index)][0]]

    def invoke(self, index: Any):
        e = self.entries[self._ix(index)]
        if e[0] in ("sep", "sub") or e[6].get("state") == "disabled":
            return None
        return self._choose(e, now=True)   # tkinter runs the command at once and returns its result

    def activate(self, index: Any):
        self.__dict__["_active"] = self._ix(index)

    def _choose(self, e, now: bool = False):
        if e[0] == "chk" and e[4] is not None:
            on, off = e[6].get("onvalue", True), e[6].get("offvalue", False)
            e[4].set(off if e[4].get() == on or (on is True and e[4].get() not in (off,) and bool(e[4].get())) else on)
        elif e[0] == "rad" and e[4] is not None:
            e[4].set(e[5] if e[5] is not None else e[1])
        if now:
            return e[2]() if e[2] is not None else None
        _queue(e[2])

    # --- right-click menus: tk_popup(x, y) / post(x, y); the menu opens at the mouse
    def tk_popup(self, x: Any = 0, y: Any = 0, entry: Any = ""):
        from ._window import _current
        win = _current[-1] if _current else None
        if win is not None:
            win.__dict__.setdefault("_popmenus", [])
            if self not in win._popmenus:
                win._popmenus.append(self)
            self.__dict__["_want_open"] = True
            _core.wake()

    post = tk_popup

    def unpost(self):
        self.__dict__["_want_open"] = False
        _core.wake()

    grab_release = lambda self: None  # noqa: E731
    bind = configure = config = lambda self, *a, **k: None  # noqa: E731

    def _render_popup(self) -> bool:
        """Called by the window each frame while the popup is wanted; False once it has closed."""
        name = f"##popmenu{id(self)}"
        if self.__dict__.pop("_want_open", None):
            _core.open_popup(name)
        if _core.begin_popup(name):
            try:
                self._draw_items()
            finally:
                _core.end_popup()
            return True
        return False

    def _draw_items(self) -> None:
        for e in self.entries:
            kind = e[0]
            if kind == "sep":
                _core.menu_separator()
                continue
            enabled = e[6].get("state", "normal") != "disabled"
            if kind == "sub":
                sub = e[6].get("menu")
                if sub is not None and _core.begin_menu(e[1], enabled):
                    try:
                        sub._draw_items()
                    finally:
                        _core.end_menu()
                continue
            if kind == "chk":
                on = e[6].get("onvalue", True)
                chk = 1 if (e[4] is not None and (e[4].get() == on or (on is True and bool(e[4].get())))) else 0
            elif kind == "rad":
                chk = 1 if (e[4] is not None and e[4].get() == (e[5] if e[5] is not None else e[1])) else 0
            else:
                chk = -1
            if _core.menu_item(e[1], e[3], chk, enabled):
                self._choose(e)

    def _draw_bar(self) -> None:
        if _core.begin_main_menu_bar():
            try:
                self._draw_items()
            finally:
                _core.end_main_menu_bar()

    def __getattr__(self, name):
        from ._compat import missing
        return missing(self, name)


# ---------------------------------------------------------------------------------------- Tabs
class Tab(Column):
    """One page of a Tabs widget."""

    def __init__(self, title: str = "Tab", parent=None, **kw):
        super().__init__(parent, **kw)
        self.title = title


class Tabs(Container):
    """Tabbed pages (ttk.Notebook). Children are Tab objects, or any Frame given a title with add(frame, text=...)."""

    def enable_traversal(self, *a, **k):  # ttk.Notebook: Ctrl+Tab switching; TK 4K tabs are clicked
        return None

    def __init__(self, parent=None, *, on_change: Optional[Callable[[int], None]] = None, **kw):
        super().__init__(parent, **kw)
        self._cur = 0
        self.on_change = on_change
        self._want: Optional[int] = None

    # tkinter's Notebook.index(tab) is a method; TK 4K's .index was the current tab. Both work:
    # nb.index == 1 and nb.index("end") / nb.index("current") / nb.index(frame).
    index = property(lambda s: _TabIndex(s._cur, s), lambda s, v: setattr(s, "_cur", int(v)))

    def _pages(self) -> list:
        """Only Tab objects and children given to add() are tabs: in tkinter a Frame(nb) is not a tab until nb.add()."""
        return [c for c in self._children if isinstance(c, Tab) or hasattr(c, "_tab_title")]

    def _pos(self, t: Any) -> int:
        if isinstance(t, Widget):
            return self._pages().index(t)
        if t in ("end",):
            return len(self._pages())
        if t in ("current", None):
            return self._cur
        return int(t)

    def forget(self, t: Any) -> None:
        c = self._pages()[self._pos(t)]
        self._children.remove(c)
        self._cur = min(self._cur, max(0, len(self._pages()) - 1))
        _core.wake()

    hide = forget

    def tabs(self) -> tuple:
        return tuple(range(len(self._pages())))

    def bind(self, seq, fn=None, add=None):
        if str(seq) == "<<NotebookTabChanged>>" and fn is not None:
            self.on_change = lambda _i, f=fn: f(_Event(self))
        else:
            super().bind(seq, fn, add)

    def add(self, child: Widget, text: str = "", **_) -> None:
        child._tab_title = text
        if child not in self._children:
            self._children.append(child)

    def insert(self, pos: Any, child: Widget, text: str = "", **kw) -> None:
        """Notebook.insert(pos, frame, text=...): a tab at that position ('end' = append)."""
        if child in self._children:
            self._children.remove(child)
        child._tab_title = text or getattr(child, "_tab_title", "")
        pages = self._pages()
        at = len(pages) if pos == "end" else self._pos(pos)
        idx = self._children.index(pages[at]) if at < len(pages) else len(self._children)
        self._children.insert(idx, child)
        _core.wake()

    def select(self, i: Any = None):
        if i is None:
            return self._cur
        self._want = self._pos(i)
        _core.wake()

    def tab(self, i: Any, option: Optional[str] = None, **kw):
        c = self._pages()[self._pos(i)]
        if "text" in kw:
            c._tab_title = kw["text"]
            _core.wake()
        t = self._title(c)
        if option is not None:
            return t if option == "text" else ""
        return None if kw else {"text": t}

    @staticmethod
    def _title(c: Widget) -> str:
        return str(getattr(c, "_tab_title", None) or getattr(c, "title", "Tab"))

    def _draw(self) -> None:
        if not _core.begin_tab_bar(f"##tabs{self._id}"):
            return
        try:
            for n, c in enumerate(self._pages()):
                want = self._want == n
                if _core.begin_tab_item(self._title(c) + f"###t{n}", want):
                    try:
                        if self._cur != n and not want:
                            self._cur = n
                            _queue(self.on_change, n)
                        if want:
                            self._want = None
                            if self._cur != n:
                                self._cur = n
                                _queue(self.on_change, n)
                        if n == self._cur and not self.__dict__.get("_shown"):
                            self.__dict__["_shown"] = True   # tkinter fires <<NotebookTabChanged>> when first mapped
                            _queue(self.on_change, n)
                        c._render()
                    finally:
                        _core.end_tab_item()
        finally:
            _core.end_tab_bar()


# ---------------------------------------------------------------------------------------- Radio, Spinbox
class Radio(Widget):
    """One round button of a group: all share a Var, each has its own value."""

    def __init__(self, text: str = "", value: Any = 1, *, var: Optional[Var] = None,
                 on_change: Optional[Callable[[Any], None]] = None, **kw):
        super().__init__(**kw)
        self.text, self.value = text, value
        self.var = var if var is not None else Var(None)
        self.on_change = on_change

    def invoke(self) -> None:
        self.var.set(self.value)
        _queue(self.on_change, self.value)

    def select(self) -> None:
        self.var.set(self.value)

    def deselect(self) -> None:
        if self.var.get() == self.value:
            self.var.set("")

    def _draw(self) -> None:
        if _core.radio(str(_val(self.text)), self.var.get() == self.value):
            self.var.set(self.value)
            _queue(self.on_change, self.value)


class Spinbox(Widget):
    """A number box with up/down steps (tk.Spinbox / ttk.Spinbox). .get() returns text like tkinter; .value is a number."""

    def __init__(self, lo: float = 0, hi: float = 100, step: float = 1, *, var: Optional[Var] = None, value: Any = None,
                 on_change: Optional[Callable[[Any], None]] = None, values: Any = None, wrap: bool = False, **kw):
        super().__init__(**kw)
        self.lo, self.hi, self.step = lo, hi, step
        # Spinbox(values=("Mon", "Tue")): steps through the list (strings) instead of numbers
        self.values = [str(v) for v in values] if values else None
        self.wrap = bool(wrap)
        first = self.values[0] if self.values else lo
        self.var = var if var is not None else Var(first if value is None else value)
        self.on_change = on_change

    @property
    def value(self):
        if self.values:
            return str(self.var.get())
        v = float(self.var.get() or 0)
        return int(v) if float(self.step).is_integer() and float(self.lo).is_integer() else v

    @value.setter
    def value(self, v):
        self.var.set(v)

    def get(self) -> str:
        return str(self.value)

    def set(self, v) -> None:
        self.var.set(v)

    def _step_list(self, d: int) -> None:
        vals, cur = self.values, str(self.var.get())
        k = vals.index(cur) if cur in vals else 0
        k = (k + d) % len(vals) if self.wrap else max(0, min(len(vals) - 1, k + d))
        self.var.set(vals[k])
        _queue(self.on_change, self.value)

    def config(self, cnf=None, **kw):
        if "values" in kw:
            v = kw.pop("values")
            self.values = [str(x) for x in v] if v else None
            if self.values and str(self.var.get()) not in self.values:
                self.var.set(self.values[0])
        super().config(cnf, **kw)

    configure = config

    def invoke(self, element: str = "buttonup") -> None:
        """Spinbox.invoke('buttonup'|'buttondown'): one step, then the command."""
        if self.values:
            return self._step_list(1 if element == "buttonup" else -1)
        d = self.step if element == "buttonup" else -self.step
        v = min(self.hi, max(self.lo, float(self.var.get() or 0) + d))
        self.var.set(int(v) if float(self.step).is_integer() and float(self.lo).is_integer() else v)
        _queue(self.on_change, self.value)

    def delete(self, *a) -> None:
        pass

    def insert(self, _i, text) -> None:
        if self.values:
            self.var.set(str(text))
            return
        try:
            self.var.set(float(text))
        except ValueError:
            pass

    def _draw(self) -> None:
        if self.values:   # a list: [ value ] [-] [+]
            _core.text(str(self.var.get()), False)
            _core.same_line(0.0, -1.0)
            if _core.button(f"-##sd{self._id}", 28.0, 0.0, False):
                self._step_list(-1)
            _core.same_line(0.0, -1.0)
            if _core.button(f"+##su{self._id}", 28.0, 0.0, False):
                self._step_list(1)
            return
        dec = 0 if float(self.step).is_integer() and float(self.lo).is_integer() else 2
        ch, nv = _core.spin("##spin", float(self.var.get() or 0), float(self.lo), float(self.hi), float(self.step),
                            self._auto_width(120.0), dec)
        if ch:
            self.var.set(int(nv) if dec == 0 else nv)
            _queue(self.on_change, self.value)


# ---------------------------------------------------------------------------------------- Listbox
class Listbox(Widget):
    """Scrolling list of strings. tkinter names: insert, delete, get, curselection, size, selection_set."""

    def __init__(self, items: Optional[list] = None, *, height: int = 6, selectmode: str = "browse",
                 on_select: Optional[Callable[[list], None]] = None, **kw):
        super().__init__(**kw)
        self.items = [str(i) for i in (items or [])]
        self.rows, self.selectmode, self.on_select = int(height), selectmode, on_select
        self.sel: list[int] = []

    def _ix(self, i, end_is_last: bool = True) -> int:
        """tkinter: "end" is the last row for most commands, the slot after it for index() and insert()."""
        if isinstance(i, (tuple, list)):   # lb.delete(lb.curselection()): Tk reads a 1-tuple as its item
            if not i:
                from ._dialogs import TclError
                raise TclError('bad listbox index "": must be active, anchor, end, @x,y, or a number')
            i = i[0]
        if str(i) == "end":
            return len(self.items) - 1 if end_is_last else len(self.items)
        if str(i) in ("active", "anchor"):
            return self.__dict__.get("_active", 0)
        try:
            return int(i)
        except (TypeError, ValueError):
            if str(i).startswith("@"):
                return self.nearest(float(str(i).partition(",")[2] or 0))
            from ._dialogs import TclError
            raise TclError(f'bad listbox index "{i}": must be active, anchor, end, @x,y, or a number') from None

    def activate(self, index) -> None:
        self.__dict__["_active"] = max(0, min(self._ix(index), max(0, len(self.items) - 1)))

    def nearest(self, y) -> int:
        return max(0, min(int(y // 20), len(self.items) - 1))

    def itemconfig(self, index, cnf=None, **kw) -> None:
        """Per-row colours: bg/background, fg/foreground (kept in step with insert/delete)."""
        k = self._ix(index)
        if not 0 <= k < len(self.items):
            from ._dialogs import TclError
            raise TclError(f'item number "{index}" out of range')
        self.__dict__.setdefault("_iopt", {}).setdefault(k, {}).update(cnf or {}, **kw)
        _core.wake()

    itemconfigure = itemconfig

    def itemcget(self, index, option):
        if not 0 <= self._ix(index) < len(self.items):
            from ._dialogs import TclError
            raise TclError(f'item number "{index}" out of range')
        return self.__dict__.get("_iopt", {}).get(self._ix(index), {}).get(option, "")

    def _shift_opts(self, at: int, n: int) -> None:
        io = self.__dict__.get("_iopt")
        if io:
            self.__dict__["_iopt"] = {(i + n if i >= at else i): v for i, v in io.items() if not (n < 0 and at <= i < at - n)}

    def insert(self, index, *items) -> None:
        self._shift_opts(self._ix(index, False), len(items))
        at = self._ix(index, False)
        act = self.__dict__.get("_active", 0)
        if act >= at:       # tkinter moves the active row along when rows go in above it
            self.__dict__["_active"] = max(0, min(act + len(items), len(self.items) + len(items) - 1))
        for k, it in enumerate(items):
            self.items.insert(at + k, str(it))
        _core.wake()

    def delete(self, first, last=None) -> None:
        a = self._ix(first)
        b = (len(self.items) - 1 if str(last) == "end" else self._ix(last)) if last is not None else a
        if b < a:
            return
        del self.items[a:b + 1]
        n = b - a + 1
        self._shift_opts(a, -n)
        # selected rows after the deleted ones move up; deleted ones drop out (tkinter behaviour)
        self.sel = [i - n if i > b else i for i in self.sel if not a <= i <= b]
        _core.wake()

    def get(self, first, last=None):
        if last is None:
            k = self._ix(first)
            return self.items[k] if 0 <= k < len(self.items) else ""
        b = len(self.items) - 1 if str(last) == "end" else self._ix(last)
        return tuple(self.items[max(0, self._ix(first)):b + 1])

    def size(self) -> int:
        return len(self.items)

    def curselection(self) -> tuple:
        return tuple(sorted(self.sel))

    def _range(self, first, last=None) -> range:
        a = self._ix(first)
        b = (len(self.items) - 1 if str(last) == "end" else self._ix(last)) if last is not None else a
        return range(min(a, b), max(a, b) + 1)

    def selection_set(self, first, last=None) -> None:
        """Adds to the selection, like tkinter (programs clear first with selection_clear(0, END))."""
        add = [i for i in self._range(first, last) if 0 <= i < len(self.items)]
        self.sel = sorted(set(self.sel) | set(add))
        _core.wake()

    def selection_clear(self, first=None, last=None) -> None:
        if first is None:
            self.sel = []
        else:
            drop = set(self._range(first, last))
            self.sel = [i for i in self.sel if i not in drop]
        _core.wake()

    def selection_includes(self, index) -> bool:
        return self._ix(index) in self.sel

    def selection_anchor(self, index) -> None:
        self.__dict__["_active"] = self._ix(index)

    def index(self, i) -> int:
        return self._ix(i, False)

    select_set, select_clear, select_includes, select_anchor = selection_set, selection_clear, selection_includes, selection_anchor

    def see(self, *a) -> None:
        pass

    yview = see

    def bind(self, seq, fn=None, add=None):
        if str(seq) in ("<<ListboxSelect>>", "<ButtonRelease-1>", "<Button-1>") and fn is not None:
            self.on_select = lambda _s, f=fn: f(_Event(self))
        elif fn is not None:
            super().bind(seq, fn, add)

    def _draw(self) -> None:
        h = max(1, self.rows) * 24.0 + 8.0
        w = self.width if self.width is not None else -1.0
        if _core.begin_child(f"##lb{self._id}", w, h, True):
            try:
                io = self.__dict__.get("_iopt", {})
                for i, txt in enumerate(self.items):
                    _core.push_id(str(i))
                    o = io.get(i)
                    fg = bg = None
                    if o:
                        bg = _rgb_name(o.get("bg", o.get("background", ""))) if o.get("bg", o.get("background")) else None
                        fg = _rgb_name(o.get("fg", o.get("foreground", ""))) if o.get("fg", o.get("foreground")) else None
                        if bg:
                            _core.fill_line(*bg, 1.0)
                        if fg:
                            _core.push_text_color(*fg)
                    hit = _core.selectable(txt, i in self.sel, False)
                    if fg:
                        _core.pop_text_color()
                    if hit:
                        if self.selectmode in ("multiple", "extended"):
                            self.sel = [x for x in self.sel if x != i] if i in self.sel else self.sel + [i]
                        else:
                            self.sel = [i]
                        _queue(self.on_select, list(self.sel))
                    _core.pop_id()
            finally:
                _core.end_child()
        else:
            _core.end_child()


# ---------------------------------------------------------------------------------------- Tree
class _StrKeys(dict):
    """Treeview item ids are strings in tkinter (insert(iid=0) returns '0'); ints given by programs are converted."""

    def __getitem__(self, k):
        return dict.__getitem__(self, str(k) if k is not None else "")

    def __setitem__(self, k, v):
        dict.__setitem__(self, str(k), v)

    def __contains__(self, k):
        return dict.__contains__(self, str(k) if k is not None else "")

    def get(self, k, d=None):
        return dict.get(self, str(k) if k is not None else "", d)

    def pop(self, k, *d):
        return dict.pop(self, str(k) if k is not None else "", *d)


def _ids(iids) -> list:
    return [str(i) for i in (iids[0] if iids and isinstance(iids[0], (list, tuple)) else iids)]


class Tree(Widget):
    """Hierarchical table (ttk.Treeview). insert/delete/get_children/item/selection/heading follow tkinter."""

    def __init__(self, columns: tuple = (), *, show: Any = "tree headings", height: float = 220.0,
                 on_select: Optional[Callable[[tuple], None]] = None, selectmode: str = "browse", **kw):
        super().__init__(**kw)
        self.selectmode = str(selectmode)
        self._binds: dict[str, Callable] = {}
        self._rowy: list[tuple[float, float, str]] = []  # (top, bottom, iid) of the rows drawn last frame
        self._was_down = False
        self.cols = tuple(columns)
        self.show = show if isinstance(show, str) else " ".join(show)
        self.height, self.on_select = height, on_select
        self.heads: dict[str, str] = {}
        self._nodes: dict[str, dict] = _StrKeys({"": {"children": [], "text": "", "values": (), "parent": None}})
        self._n = 0
        self.sel: list[str] = []

    def heading(self, col, text: Any = "", **kw):
        if text == "text" and not kw:                 # heading("#0", "text") reads it back (tkinter's option form)
            return self.heads.get(str(col), "")
        if text:
            self.heads[str(col)] = text
        if "text" in kw:
            self.heads[str(col)] = kw["text"]

    _COLDEF = {"width": 200, "minwidth": 20, "anchor": "w", "stretch": 1, "id": None}

    def column(self, col, option=None, **kw):
        c = str(col)
        if c != "#0" and c not in self.cols and not (c.startswith("#") and c[1:].isdigit()):
            from ._dialogs import TclError
            raise TclError(f"Invalid column index {c}")
        o = self.__dict__.setdefault("_colopts", {}).setdefault(c, {})
        o.update(kw)
        if option is not None and not kw:             # column("#0", "width") reads one back
            return o.get(option, self._COLDEF.get(option, "") if option != "id" else str(col))
        if not kw and option is None:
            return {**{k: v for k, v in self._COLDEF.items() if k != "id"}, "id": str(col), **o}

    def tag_configure(self, tag, **o):
        self.__dict__.setdefault("_tags", {}).setdefault(tag, {}).update(o)
        _core.wake()

    def _chk(self, iid):
        """tkinter raises TclError("Item X not found") for an id the tree does not hold."""
        k = iid if isinstance(iid, str) else str(iid[0] if isinstance(iid, (tuple, list)) and iid else iid)
        if k not in self._nodes:
            from ._dialogs import TclError
            raise TclError(f"Item {k} not found")
        return k

    def tag_has(self, tag, iid=None):
        if iid is not None:
            self._chk(iid)
            return tag in self._nodes[iid]["tags"]
        return tuple(i for i, n in self._nodes.items() if i and tag in n.get("tags", ()))

    def tag_bind(self, tag, seq=None, fn=None, add=None):
        if fn is not None:
            self.__dict__.setdefault("_tagb", []).append((tag, str(seq), fn))

    # --- tree structure (tkinter names)
    def parent(self, iid):  # tkinter's Treeview.parent(iid); the container is .master
        return self._nodes[self._chk(iid)]["parent"]

    def index(self, iid):
        self._chk(iid)
        return self._nodes[self._nodes[iid]["parent"]]["children"].index(iid)

    def exists(self, iid):
        return iid in self._nodes

    def next(self, iid):
        s = self._nodes[self.parent(iid)]["children"]
        k = s.index(iid)
        return s[k + 1] if k + 1 < len(s) else ""

    def prev(self, iid):
        s = self._nodes[self.parent(iid)]["children"]
        k = s.index(iid)
        return s[k - 1] if k > 0 else ""

    def move(self, iid, parent, index):
        """Treeview.move: re-parent / re-order (what drag-and-drop code calls)."""
        self._chk(iid), self._chk(parent)
        p = parent
        while p:  # refuse to move a node under itself
            if p == iid:
                raise ValueError("cannot move an item under itself")
            p = self._nodes[p]["parent"]
        old = self._nodes[self._nodes[iid]["parent"]]["children"]
        if iid in old:
            old.remove(iid)
        self._nodes[iid].pop("detached_from", None)
        sibs = self._nodes[parent]["children"]
        k = len(sibs) if str(index) == "end" else max(0, min(len(sibs), int(index)))
        sibs.insert(k, iid)
        self._nodes[iid]["parent"] = parent
        _core.wake()

    reattach = move

    def detach(self, *iids):
        """Hide a row (and its children) but keep it: reattach()/move() brings it back."""
        for i in _ids(iids):
            self._chk(i)
            sibs = self._nodes[self._nodes[i]["parent"]]["children"]
            if i in sibs:
                sibs.remove(i)
            self._nodes[i]["detached_from"] = self._nodes[i]["parent"]
            if i in self.sel:
                self.sel.remove(i)
        _core.wake()

    def identify_row(self, y):
        """Row under window y (event.y from a Tree binding), '' if none."""
        top = self._rect[1] / max(1e-6, _core.ui_scale())
        for a, b, iid in self._rowy:
            if a <= y + top < b:
                return iid
        return ""

    def identify(self, component, x, y):
        return self.identify_row(y) if component in ("item", "row") else ""

    def bbox(self, item, column=None):
        """Where a row was drawn last frame (x, y, width, height), '' if it is not visible."""
        top = self._rect[1] / max(1e-6, _core.ui_scale())
        for a, b, iid in self._rowy:
            if iid == str(item):
                return (0, int(a - top), int(self._rect[2] / max(1e-6, _core.ui_scale())), int(b - a))
        return ""

    def identify_region(self, x, y):
        top = self._rect[1] / max(1e-6, _core.ui_scale())
        if self._rowy and y + top < self._rowy[0][0]:
            return "heading"
        return "tree" if self.identify_row(y) else "nothing"

    def identify_column(self, x):
        """'#0' is the tree column, '#1'... the data columns (equal widths assumed)."""
        n = len(self.cols) + (1 if "tree" in self.show else 0)
        w = max(1.0, self._rect[2] / max(1e-6, _core.ui_scale()))
        k = max(0, min(n - 1, int(x // (w / max(1, n)))))
        return f"#{k if 'tree' in self.show else k + 1}"

    def set_children(self, item, *newchildren):
        """Mostly used to re-order rows (sorting): each listed row moves under `item`, in this order."""
        new = _ids(newchildren)
        for c in list(self._nodes[self._chk(item)]["children"]):
            if c not in new:
                self.detach(c)                 # tkinter: rows not listed are detached
        for c in new:
            self.move(c, item, "end")

    def selection_add(self, *iids):
        for i in _ids(iids):
            self._chk(i)
            if i not in self.sel:
                self.sel.append(i)

    def selection_remove(self, *iids):
        drop = set(self._chk(i) for i in _ids(iids))
        self.sel = [i for i in self.sel if i not in drop]

    def selection_toggle(self, *iids):
        for i in _ids(iids):
            self._chk(i)
            (self.sel.remove if i in self.sel else self.sel.append)(i)

    def insert(self, parent: str = "", index: Any = "end", iid: Optional[str] = None, *, text: str = "",
               values: tuple = (), tags: Any = (), open: bool = False, **_) -> str:
        parent = str(parent) if parent is not None else ""
        self._chk(parent)
        if iid is not None and iid != "":
            iid = str(iid)
            if iid in self._nodes:
                from ._dialogs import TclError
                raise TclError(f"Item {iid} already exists")
        else:
            self._n += 1                       # tkinter numbers only the ids it makes itself, in hex: I001 ... I00A
            iid = f"I{self._n:03X}"
            while iid in self._nodes:
                self._n += 1
                iid = f"I{self._n:03X}"
        self._nodes[iid] = {"children": [], "text": str(text), "values": tuple(str(v) for v in values), "parent": parent,
                            "tags": [tags] if isinstance(tags, str) else list(tags), "open": bool(open)}
        sibs = self._nodes[parent]["children"]
        if str(index) == "end":
            sibs.append(iid)
        else:
            sibs.insert(int(index), iid)
        _core.wake()
        return iid

    def delete(self, *iids) -> None:
        for iid in _ids(iids):
            self._chk(iid)
            n = self._nodes.pop(iid, None)
            if n is None:
                continue
            for c in list(n["children"]):
                self.delete(c)
            p = self._nodes.get(n["parent"])
            if p and iid in p["children"]:
                p["children"].remove(iid)
            if iid in self.sel:
                self.sel.remove(iid)
        _core.wake()

    def get_children(self, parent: str = "") -> tuple:
        return tuple(self._nodes[self._chk(parent)]["children"])

    def item(self, iid: str, option: Optional[str] = None, **kw):
        n = self._nodes[self._chk(iid)]
        for k, v in kw.items():
            if k in ("text", "values"):
                n[k] = v if k == "text" else tuple(str(x) for x in v)
            elif k == "tags":
                n["tags"] = [v] if isinstance(v, str) else list(v)
            elif k == "open":
                n["open"] = bool(v)
        if kw:
            _core.wake()
        d = {"text": n["text"], "values": n["values"], "tags": list(n.get("tags", ())), "open": n.get("open", False)}
        return d.get(option) if option else d

    def set(self, iid: str, column: Any = None, value: Any = None):
        n = self._nodes[self._chk(iid)]
        names = list(self.cols)
        if str(column) == "#0":
            from ._dialogs import TclError
            raise TclError("Display column #0 cannot be set")
        if column is None:
            return dict(zip(names, n["values"]))
        k = names.index(column) if column in names else int(column)
        if value is None:
            return n["values"][k]
        v = list(n["values"]) + [""] * (len(names) - len(n["values"]))
        v[k] = str(value)
        n["values"] = tuple(v)

    def selection(self) -> tuple:
        return tuple(self.sel)

    def selection_set(self, *iids) -> None:
        self.sel = [self._chk(i) for i in _ids(iids)]

    def focus(self, *a):
        if a and a[0] not in (None, ""):
            self._chk(a[0])
            self.__dict__["_focus"] = str(a[0] if isinstance(a[0], str) else a[0][0])
            return ""
        f = self.__dict__.get("_focus")
        return f if f in self._nodes else (self.sel[0] if self.sel else "")

    def see(self, *a) -> None:
        if a:
            self._chk(a[0])

    yview = xview = see

    _MOUSE = ("<Button-1>", "<1>", "<ButtonPress-1>", "<ButtonRelease-1>", "<B1-Motion>", "<Double-1>",
              "<Double-Button-1>", "<Motion>")

    def bind(self, seq, fn=None, add=None):
        s = str(seq)
        if fn is None:
            return
        if s == "<<TreeviewSelect>>":
            self.on_select = lambda _s, f=fn: f(_Event(self))
        elif s in self._MOUSE:
            self._binds[s] = fn
        else:
            super().bind(seq, fn, add)   # <Button-3>, <Enter>, <Configure>... the generic path

    def _draw(self) -> None:
        tree_col = "tree" in self.show
        names = (["#0"] if tree_col else []) + list(self.cols)
        if not names:
            names = ["#0"]
            tree_col = True
        w = self.width if self.width is not None else -1.0
        if not _core.begin_child(f"##tv{self._id}", w, self.height, True):
            _core.end_child()
            return
        try:
            if _core.begin_table(f"##tvt{self._id}", len(names)):
                try:
                    for n in names:
                        _core.table_setup_column(self.heads.get(n, "" if n == "#0" else n), 1.0)
                    if "headings" in self.show:
                        _core.table_headers_row()
                    self._rowy = []
                    self._rows("", tree_col, len(names))
                finally:
                    _core.end_table()
        finally:
            _core.end_child()
        self._mouse()

    def _mouse(self) -> None:
        """tkinter-style mouse bindings: event.x/.y relative to the widget, so identify_row(event.y) works."""
        tb = self.__dict__.get("_tagb")
        if not self._binds and not tb:
            return
        mx, my, down, pressed, released, dbl, _c, _s = _core.mouse_state()
        sc = max(1e-6, _core.ui_scale())
        x0, y0, w, h = (v / sc for v in self._rect)
        inside = x0 <= mx < x0 + w and y0 <= my < y0 + h
        ev = _CanvasEvent(self, mx - x0, my - y0)
        b = self._binds
        lastm, self._lastm = getattr(self, "_lastm", None), (mx, my)
        if pressed and inside:
            self._was_down = True
            for k in ("<Button-1>", "<1>", "<ButtonPress-1>"):
                if k in b:
                    _queue(b[k], ev)
            if dbl:
                for k in ("<Double-1>", "<Double-Button-1>"):
                    if k in b:
                        _queue(b[k], ev)
        elif down and self._was_down and "<B1-Motion>" in b and lastm != (mx, my):
            _queue(b["<B1-Motion>"], ev)
        elif inside and not down and "<Motion>" in b:
            _queue(b["<Motion>"], ev)
        if released and self._was_down:
            self._was_down = False
            if "<ButtonRelease-1>" in b:
                _queue(b["<ButtonRelease-1>"], ev)
        if tb and pressed and inside:
            row = self.identify_row(my - y0)
            for tag, seq, fn in tb:
                if row and tag in self._nodes[row].get("tags", ()):
                    if (seq in ("<Button-1>", "<1>", "<ButtonPress-1>")
                            or (dbl and seq in ("<Double-1>", "<Double-Button-1>"))):
                        _queue(fn, ev)

    def _click(self, iid: str) -> None:
        """browse: one row; extended: Ctrl toggles, Shift selects a range of visible rows."""
        old = list(self.sel)
        _x, _y, _d, _p, _r, _dbl, ctrl, shift = _core.mouse_state()
        if self.selectmode == "extended" and ctrl:
            self.selection_toggle(iid)
        elif self.selectmode == "extended" and shift and self.sel:
            order = [r[2] for r in self._rowy]
            a = order.index(self.sel[-1]) if self.sel[-1] in order else 0
            b = order.index(iid) if iid in order else a
            self.sel = order[min(a, b):max(a, b) + 1]
        elif self.selectmode == "none":
            return
        else:
            self.sel = [iid]
        if self.sel != old:
            _queue(self.on_select, tuple(self.sel))

    def _rows(self, parent: str, tree_col: bool, ncols: int) -> None:
        for iid in list(self._nodes[parent]["children"]):
            n = self._nodes[iid]
            _core.push_id(iid)
            _core.table_next_row()
            _core.table_next_column()
            kids = bool(n["children"])
            label = n["text"] if tree_col else (n["values"][0] if n["values"] else "")
            fg = bg = None
            for t in n.get("tags", ()):
                o = self.__dict__.get("_tags", {}).get(t, {})
                fg = _rgb_name(o.get("foreground", o.get("fg"))) if o.get("foreground", o.get("fg")) else fg
                bg = _rgb_name(o.get("background", o.get("bg"))) if o.get("background", o.get("bg")) else bg
            if bg:
                _core.table_row_bg(*bg, 1.0)
            if fg:
                _core.push_text_color(*fg)
            if kids:
                _core.set_next_open(bool(n.get("open")))
            if kids or tree_col:
                is_open, clicked = _core.tree_node(label + "##n", iid in self.sel, not kids)
            else:
                clicked = _core.selectable(label + "##n", iid in self.sel, True)
                is_open = False
            rx, ry, rw, rh = _core.item_rect_ui()
            self._rowy.append((ry, ry + rh, iid))
            if kids:
                n["open"] = is_open
            if clicked:
                self._click(iid)
            vals = n["values"][(0 if tree_col else 1):]
            for k in range(ncols - 1):
                _core.table_next_column()
                _core.text(vals[k] if k < len(vals) else "")
            if fg:
                _core.pop_text_color()
            if kids and is_open:
                self._rows(iid, tree_col, ncols)
                _core.tree_pop()
            _core.pop_id()


# ---------------------------------------------------------------------------------------- Dialogs

def _str_iid(fn):
    def w(self, iid="", *a, **k):
        return fn(self, str(iid) if iid is not None else "", *a, **k)
    w.__name__, w.__doc__ = fn.__name__, fn.__doc__
    return w


for _m in ("index", "next", "prev", "move", "item", "set", "parent", "exists", "get_children"):
    setattr(Tree, _m, _str_iid(getattr(Tree, _m)))
_tree_delete = Tree.delete
Tree.delete = lambda self, *iids: _tree_delete(self, *_ids(iids))  # noqa: E731
del _m

class Dialog(_SizeAttr, Column):
    """A modal pop-up window. `with Dialog("Title", win): ...` builds it; open()/close() show and hide it."""

    def __init__(self, title: str = "Dialog", parent=None, *, size: tuple = (360, 0), on_close=None, **kw):
        root = parent if parent is not None else None
        super().__init__(None, **kw)
        self.title_text, self._size, self.on_close = title, tuple(size), on_close
        self._open = False
        self._asked = False
        self._owner = _find_window(root)   # not `_win`: that is Widget._win(), the method
        if self._owner is not None:
            self._owner._dialogs.append(self)

    # Subclasses written for tkinter often define their own open() / close() (a Toplevel subclass with `def open(self)`
    # is common), so TK 4K's own code calls the private _do_open / _do_close and never the overridable names.
    def _do_open(self) -> None:
        self._open, self._asked = True, False
        _core.wake()

    def _do_close(self) -> None:
        if self._open:
            self._open = False
            _queue(self.on_close)
            _core.wake()

    open = _do_open
    close = _do_close
    destroy = _do_close

    def _render_dialog(self) -> None:
        name = f"{self.title_text}###dlg{self._id}"
        if self._open and not self._asked:
            _core.open_popup(name)
            self._asked = True
        if not self._asked:
            return
        vis, still = _core.begin_modal(name, float(self._size[0]), float(self._size[1]))
        if vis:
            try:
                if not self._open:
                    _core.close_popup()
                else:
                    self._draw_children()
            finally:
                _core.end_modal()
            if not still:
                fn = self.__dict__.get("_wm_delete")
                if fn is not None and self._open:
                    self._asked = False   # stays open until the handler calls destroy()
                    _queue(fn)
                else:
                    self._do_close()
        elif self._open and self._asked:
            self._open = False  # closed by the pop-up system itself (Escape, click outside)


class Toplevel(Dialog):
    """tkinter's Toplevel: opens at once as a pop-up (TK 4K has one OS window)."""

    def __init__(self, master=None, **kw):
        super().__init__("Window", master, size=(360, 0))
        self._do_open()

    def title(self, text=None):  # tkinter: top.title("x")
        if text is not None:
            self.title_text = str(text)

    def geometry(self, spec: str = "") -> None:
        import re
        m = re.match(r"(\d+)x(\d+)", str(spec))
        if m:
            self._size = (int(m.group(1)), int(m.group(2)))

    wm_title = title
    wm_geometry = geometry

    # window-manager calls that have no meaning for a pop-up: accepted so subclassed Toplevels keep working
    def _wm_noop(self, *a, **k):
        return None

    transient = resizable = minsize = maxsize = iconbitmap = iconphoto = attributes = wm_attributes = _wm_noop
    lift = lower = focus_set = focus_force = grab_set = grab_release = _wm_noop
    update_idletasks = columnconfigure = rowconfigure = _wm_noop
    wm_transient = wm_resizable = wm_minsize = wm_maxsize = wm_iconbitmap = wm_iconphoto = group = wm_group = _wm_noop
    iconname = wm_iconname = overrideredirect = wm_overrideredirect = _wm_noop

    def withdraw(self):
        """Hidden but still alive (wait_window keeps waiting), like tkinter; deiconify() shows it again."""
        self.__dict__["_withdrawn"] = True
        self._open, self._asked = False, False
        _core.wake()

    def deiconify(self):
        if self.__dict__.pop("_withdrawn", False) or not self._open:
            self._do_open()

    wm_withdraw, wm_deiconify, iconify, wm_iconify = withdraw, deiconify, withdraw, withdraw

    def state(self, newstate=None):
        if newstate is None:
            return "withdrawn" if self.__dict__.get("_withdrawn") else "normal"
        (self.withdraw if newstate in ("withdrawn", "iconic") else self.deiconify)()

    wm_state = state

    def update(self, *a, **k):
        if self._owner is not None:
            self._owner.update()

    def protocol(self, name=None, func=None):
        """protocol("WM_DELETE_WINDOW", fn): fn runs instead of closing, and may call destroy()."""
        if name == "WM_DELETE_WINDOW" and func is not None:
            self.__dict__["_wm_delete"] = func

    def wait_window(self, w=None):
        """Block (in a nested loop) until this pop-up is closed."""
        win = self._owner
        if win is not None:
            win._wait_until(lambda: not self._open and not self.__dict__.get("_withdrawn"))

    def winfo_exists(self):
        return int(self._open)

    def destroy(self):   # tkinter: destroy() is the way a Toplevel goes away; subclasses may call super().destroy()
        self.__dict__.pop("_withdrawn", None)
        self._do_close()


class SimpleDialog(Toplevel):
    """tkinter.simpledialog.Dialog: subclass it, override body(master), validate(), apply() (and buttonbox()).
    Like tkinter it blocks until closed, then .result holds whatever apply() stored (None after Cancel)."""

    def __init__(self, parent=None, title=None):
        super().__init__(parent)
        if title:
            self.title_text = str(title)
        self.result = None
        self.master = parent if parent is not None and hasattr(parent, "_children") else None
        body = Frame(parent=self)
        self.initial_focus = self.body(body) or self
        self.buttonbox()
        from . import _dialogs
        if _dialogs.dialog_answers:  # scripted run (tests, the porter's check): answer without a person
            a = _dialogs.dialog_answers.pop(0)
            if a is not None:
                self.result = a
            self.destroy()
            return
        self.wait_window()

    def body(self, master):
        return None

    def buttonbox(self):
        box = Row(self)
        Button("OK", self.ok, parent=box, primary=True)
        Button("Cancel", self.cancel, parent=box)

    def validate(self):
        return True

    def apply(self):
        pass

    def ok(self, event=None):
        if not self.validate():
            return
        self.apply()
        self.cancel()

    def cancel(self, event=None):
        self.destroy()


def _find_window(w: Any):
    from . import _window
    if isinstance(w, _window.Window):
        return w
    while w is not None and not isinstance(w, _window.Window):
        w = getattr(w, "parent", None)
    return w if w is not None else (_window._current[-1] if _window._current else None)


def message(win, title: str, text: str, on_close: Optional[Callable] = None) -> Dialog:
    d = Dialog(title, win, size=(380, 0))
    with d:
        Label(text, wrap=True)
        Button("OK", d.close, primary=True)
    d.on_close = on_close
    d.open()
    return d


def ask_yes_no(win, title: str, text: str, on_answer: Callable[[bool], None], yes: str = "Yes", no: str = "No") -> Dialog:
    d = Dialog(title, win, size=(380, 0))
    answer = {"v": False}

    def pick(v):
        answer["v"] = v
        d.close()
    with d:
        Label(text, wrap=True)
        with Row():
            Button(yes, lambda: pick(True), primary=True)
            Button(no, lambda: pick(False))
    d.on_close = lambda: on_answer(answer["v"])
    d.open()
    return d


def ask_string(win, title: str, prompt: str, on_answer: Callable[[Optional[str]], None], initial: str = "") -> Dialog:
    d = Dialog(title, win, size=(380, 0))
    v = Var(initial)
    res = {"v": None}

    def ok(_t=None):
        res["v"] = v.get()
        d.close()
    with d:
        Label(prompt, wrap=True)
        Entry(var=v, on_submit=ok)
        with Row():
            Button("OK", ok, primary=True)
            Button("Cancel", d.close)
    d.on_close = lambda: on_answer(res["v"])
    d.open()
    return d


def ask_open_file(win, on_answer: Callable[[Optional[str]], None], start: Optional[str] = None,
                  title: str = "Open file") -> Dialog:
    """An in-app file chooser (TK 4K has no native dialogs yet): folders first, type a path or click."""
    d = Dialog(title, win, size=(520, 420))
    cur = Var(os.path.abspath(os.path.expanduser(start or os.getcwd())))
    res = {"v": None}
    lb = None

    def entries():
        p = cur.get()
        try:
            names = sorted(os.listdir(p), key=lambda n: (not os.path.isdir(os.path.join(p, n)), n.lower()))
        except OSError as e:
            return ["(cannot read: %s)" % e.strerror]
        return [".."] + [n + ("/" if os.path.isdir(os.path.join(p, n)) else "") for n in names]

    def refresh():
        lb.items = entries()
        lb.sel = []

    def choose(_sel=None):
        if not lb.sel:
            return
        n = lb.items[lb.sel[0]]
        full = os.path.normpath(os.path.join(cur.get(), n.rstrip("/")))
        if n == ".." or n.endswith("/"):
            cur.set(full)
            refresh()
        else:
            res["v"] = full
            d.close()

    def go(_t=None):
        p = os.path.expanduser(cur.get().strip())
        if os.path.isfile(p):
            res["v"] = p
            d.close()
        else:
            cur.set(p)
            refresh()
    with d:
        Entry(var=cur, on_submit=go)
        lb = Listbox(entries(), height=12)
        with Row():
            Button("Open", choose, primary=True)
            Button("Up", lambda: (cur.set(os.path.dirname(cur.get())), refresh()))
            Button("Cancel", d.close)
    lb.on_select = lambda s: None
    d.on_close = lambda: on_answer(res["v"])
    d.open()
    return d


# ---------------------------------------------------------------------------------------- no-op compat
class Style:
    """ttk.Style stand-in: TK 4K themes are set with Window.set_theme(); style calls are noted and ignored."""

    def __init__(self, *a, **k):
        pass

    def theme_use(self, name=None):
        _compat_note("ttk.Style().theme_use is ignored: use Window.set_theme('dark'|'light')")
        return "default"

    def configure(self, *a, **k):
        _compat_note("ttk.Style().configure is ignored (the TK 4K theme decides)")

    map = lookup = theme_names = layout = element_create = configure

    def theme_create(self, name, parent=None, settings=None):
        _compat_note("ttk.Style().theme_create is ignored (the TK 4K theme decides)")

    theme_settings = theme_create
    element_names = lambda self: ()  # noqa: E731
    element_options = lambda self, element: ()  # noqa: E731

    def __getattr__(self, name):
        from ._compat import missing
        return missing(self, name)


class Scrollbar(Widget):
    """Scrollbars are built into TK 4K's lists, tables, trees and text boxes; this is an invisible stand-in."""

    def __init__(self, *a, **k):
        super().__init__(parent=k.get("parent"))
        self._visible = False

    def set(self, *a):
        self.__dict__["_pos"] = tuple(float(x) for x in a[:2]) if len(a) >= 2 else (0.0, 1.0)

    def get(self):
        return self.__dict__.get("_pos", (0.0, 1.0))

    def _draw(self) -> None:
        pass


class Font:
    """tkinter.font.Font. TK 4K draws with one theme font, so this only answers questions about size."""

    def __init__(self, root: Any = None, font: Any = None, name: Any = None, exists: bool = False, **opts):
        self.opts = {"family": "Inter", "size": 10, "weight": "normal", "slant": "roman",
                     "underline": 0, "overstrike": 0}
        if isinstance(font, (tuple, list)):
            self.opts.update(dict(zip(("family", "size"), font[:2])))
        self.opts.update(opts)

    def _px(self) -> float:
        s = abs(int(self.opts.get("size", 10) or 10))
        return s * 1.33 if int(self.opts.get("size", 10) or 10) > 0 else s  # points -> pixels; negative = pixels

    def measure(self, text: str, displayof: Any = None) -> int:
        return int(len(str(text)) * self._px() * 0.55 + 0.5)  # average Inter advance

    def metrics(self, *opt: str, **_):
        px = self._px()
        m = {"ascent": int(px * 0.8), "descent": int(px * 0.25), "linespace": int(px * 1.2), "fixed": 0}
        return m[opt[0]] if opt else m

    def actual(self, option: Any = None, displayof: Any = None):
        return self.opts.get(option) if option else dict(self.opts)

    def cget(self, k: str):
        return self.opts.get(k)

    def configure(self, **kw):
        self.opts.update(kw)
        _compat_note("Fonts: TK 4K uses the theme font; size/weight changes are recorded, not drawn")

    config = configure

    def copy(self) -> "Font":
        return Font(**self.opts)

    def __getattr__(self, name):
        from ._compat import missing
        return missing(self, name)


def nametofont(name: str) -> Font:
    return Font()


def families(root: Any = None) -> tuple:
    return ("Inter",)
