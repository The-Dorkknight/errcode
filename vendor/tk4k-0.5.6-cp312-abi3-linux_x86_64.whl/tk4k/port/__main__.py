"""Command line for tk4k.port. See `python -m tk4k.port --help`."""
from __future__ import annotations

import argparse
import os
import sys
import time

from .. import _alerts, __version__
from . import main_exit_code, port_file

GRADE_TEXT = {"safe": "SAFE: translated with no loss",
              "review": "REVIEW: translated, some things approximated",
              "unsafe": "UNSAFE: placeholders / unsupported calls in the result (it runs, but check the report)",
              "failed": "FAILED: the translator could not process this file",
              "skipped": "SKIPPED: nothing to translate in this file"}


def _uses_tkinter(path: str) -> bool:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            t = f.read(200000)
    except OSError:
        return False
    return "tkinter" in t or "Tkinter" in t


def _files(target: str):
    if os.path.isdir(target):
        for root, dirs, names in os.walk(target):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "venv", ".venv", "build")]
            for n in sorted(names):
                if n.endswith(".py") and not n.endswith("_tk4k.py"):
                    p = os.path.join(root, n)
                    if _uses_tkinter(p):
                        yield p
    else:
        yield target


def _alert(r, out, qr_to_terminal: bool) -> None:
    bar = "=" * 72
    big = r.grade in ("unsafe", "failed")
    if big:
        print(bar, file=out)
    print(f"[tk4k.port] {os.path.basename(r.source)}  {GRADE_TEXT.get(r.grade, r.grade)}", file=out)
    print(f"[tk4k.port]   {r.translated} translated, {r.approximations} approximations, {r.todo} placeholders/unsupported", file=out)
    shown = 0
    for n in r.notes:
        if n["level"] == "todo" and shown < 8:
            shown += 1
            print(f"[tk4k.port]   ! line {n['line'] or '?'}: {n['msg']}", file=out)
    if r.todo > shown:
        print(f"[tk4k.port]   ... and {r.todo - shown} more (see the report)", file=out)
    pred = [n for n in r.notes if n.get("anticipated")]
    if pred:
        lv = [n["level"] for n in pred]
        print(f"[tk4k.port]   predicted before running: {lv.count('todo')} will not work, {lv.count('approx')} will "
              f"differ, {lv.count('advice')} common tkinter mistakes", file=out)
        for n in [n for n in pred if n["level"] != "todo"][:6]:
            print(f"[tk4k.port]   ~ line {n['line'] or '-'}: {n['msg'][len('anticipated: '):][:150]}", file=out)
    if r.error:
        print(f"[tk4k.port]   ERROR: {r.error}", file=out)
    for label, p in (("translated", r.out_path), ("report", r.report_path), ("log", r.log_path), ("QR", r.qr_path)):
        if p:
            print(f"[tk4k.port]   {label}: {p}", file=out)
    if big and r.payload:
        print(f"[tk4k.port]   error report: {r.payload}", file=out)
        if qr_to_terminal and _alerts.qr_available() and len(r.payload) <= 400:
            print(_alerts.qr_terminal(r.payload), file=out)
        elif big and not _alerts.qr_available():
            print("[tk4k.port]   (pip install segno to get this as a QR code)", file=out)
    if big:
        print(bar, file=out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m tk4k.port",
                                 description="Translate tkinter apps into TK 4K apps. Nothing is dropped silently.")
    ap.add_argument("target", nargs="?", help="a .py file, or a folder to grade/translate")
    ap.add_argument("-o", "--out", help="output file (single file only; default NAME_tk4k.py next to the source)")
    ap.add_argument("--check", action="store_true", help="grade only: write no files")
    ap.add_argument("--qr", action="store_true", help="always write a QR error report (default: only if unsafe/failed)")
    ap.add_argument("--no-qr", action="store_true", help="never print a QR code in the terminal")
    ap.add_argument("--decode", metavar="REPORT", help="read a TK4K1-... (or ErrCode EC2-...) report string")
    ap.add_argument("--jobs", "-j", default="1",
                    help="worker processes (default 1, gentle on old PCs; 'auto' = all cores but one)")
    ap.add_argument("--timeout", type=float, default=600.0,
                    help="seconds one file may take before it is stopped and reported (default 600)")
    ap.add_argument("--in-process", action="store_true",
                    help="no worker processes (debugging); a crash or hang in one file then stops the run")
    ap.add_argument("--version", action="version", version=f"tk4k.port {__version__}")
    a = ap.parse_args(argv)

    if a.decode:
        s = a.decode
        if s.strip().upper().startswith("EC"):
            try:
                import errcode
                print("\n".join(errcode.decode(s).lines()))
                return 0
            except ImportError:
                print("This is an ErrCode report; pip install errcode (or use its decoder page) to read it.", file=sys.stderr)
                return 2
        try:
            print(_alerts.describe(_alerts.decode_payload(s)))
            return 0
        except Exception as e:
            print(f"could not decode: {e}", file=sys.stderr)
            return 2
    if not a.target and sys.stdin.isatty():          # launched by double-click: ask for the file
        try:
            a.target = input("Drag a tkinter .py file (or a folder) onto this window, then press Enter: ").strip().strip("\"'")
        except EOFError:
            a.target = None
    if not a.target:
        ap.error("give a .py file or a folder (or --decode REPORT)")

    try:
        import libcst  # noqa: F401
    except ImportError:
        print("[tk4k.port] LibCST is needed to read your code:  pip install libcst   (or pip install \"tk4k[port]\")", file=sys.stderr)
        return 2
    files = list(_files(a.target))
    if not files:
        print("[tk4k.port] no tkinter files found", file=sys.stderr)
        return 0
    many = len(files) > 1
    t0 = time.time()
    if a.in_process:
        results = []
        for i, f in enumerate(files, 1):
            if many:
                print(f"[tk4k.port] {i}/{len(files)} {f}  ({time.time() - t0:.0f}s so far)", file=sys.stderr, flush=True)
            results.append(port_file(f, a.out if not many else None, write=not a.check, qr=True if a.qr else None))
    elif not many and a.out:  # -o needs the in-process path (workers write next to the source)
        results = [port_file(files[0], a.out, write=not a.check, qr=True if a.qr else None)]
    else:
        from ._supervise import run_many
        jobs = max(1, (os.cpu_count() or 2) - 1) if a.jobs == "auto" else max(1, int(a.jobs))
        results = run_many(files, write=not a.check, qr=True if a.qr else None, jobs=jobs, timeout_s=a.timeout)
    for r in results:
        if not many or r.grade in ("unsafe", "failed"):
            _alert(r, sys.stderr, qr_to_terminal=not a.no_qr and not many)
    if many:
        from collections import Counter
        c = Counter(r.grade for r in results)
        line = f"{len(results)} files in {time.time() - t0:.0f}s: " + ", ".join(f"{k} {v}" for k, v in sorted(c.items()))
        print(f"[tk4k.port] {line}", file=sys.stderr)
        if not a.check and os.path.isdir(a.target):
            import json
            summary = os.path.join(a.target, "tk4k_port_summary.json")
            try:
                with open(summary, "w", encoding="utf-8") as f:
                    json.dump({"tk4k": __version__, "summary": line, "seconds": round(time.time() - t0, 1),
                               "files": [{"source": r.source, "grade": r.grade, "seconds": round(r.seconds, 2),
                                          "todo": r.todo, "error": r.error} for r in results]}, f, indent=1)
                print(f"[tk4k.port] summary: {summary}", file=sys.stderr)
            except OSError as e:
                print(f"[tk4k.port] could not write the summary: {e}", file=sys.stderr)
    return main_exit_code(results)


if __name__ == "__main__":
    sys.exit(main())
