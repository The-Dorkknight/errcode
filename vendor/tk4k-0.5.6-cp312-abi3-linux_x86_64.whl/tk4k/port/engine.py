"""tk4k.port engine: translate a tkinter app into a TK 4K app, with a report.

Research prototype grown into a package (see docs/PORT_TOOL_DESIGN.md). Scope:
  * apps whose UI is built in straight-line module-level code (most tutorial and hobby tools);
  * widgets TK 4K has: Tk, Frame/LabelFrame, Label, Button, Entry, Checkbutton, Scale,
    ttk.Progressbar, ttk.Separator, and StringVar/IntVar/DoubleVar/BooleanVar;
  * pack (any sides, as nested rows/columns) and grid (static row/column numbers).

NOTHING IS DELETED. A widget TK 4K does not have becomes a `ui.Placeholder(...)` (a greyed box that
answers .get() and swallows other calls); any other tkinter call becomes `ui.unsupported(...)`.
Both are recorded in the log, in the exit footer and in the QR error report, so the translated app
always runs and always says what is missing.

  safe   = translated with no loss
  review = translated, but something was approximated (fonts/colours dropped, layout approximated, dialogs -> toasts)
  unsafe = placeholders or unsupported calls are in the output (TK 4K has to grow the widget)
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ._names import STAR
from .._tkapi import ALL as TK_ALL

# tkinter widget classes a program may subclass -> tk4k.tkbase adapter (kept in step with tk4k/tkbase.py ADAPTERS)
_ADAPTERS = {"Canvas": "Canvas", "Text": "Text", "ScrolledText": "Text", "Label": "Label", "Message": "Message",
             "Button": "Button", "Entry": "Entry", "Listbox": "Listbox", "Checkbutton": "Checkbutton",
             "Scale": "Scale", "Spinbox": "Spinbox", "Treeview": "Treeview", "Combobox": "Combobox"}


def _real(kind, meth):
    """TK 4K's class `kind` really defines `meth` (not only the run-time safety net)."""
    from ._anticipate import _ui_has
    return _ui_has(kind, meth)

import libcst as cst
from libcst.metadata import MetadataWrapper, PositionProvider, QualifiedName, QualifiedNameProvider, QualifiedNameSource

# ----------------------------------------------------------------------------------- rules (data)
# kind: window | container | widget | var | dialog
RULES = {
    "Tk": {"kind": "window"},
    "Frame": {"kind": "container"}, "ttk.Frame": {"kind": "container"},
    "LabelFrame": {"kind": "container", "title": "text"}, "ttk.LabelFrame": {"kind": "container", "title": "text"},
    "Label": {"kind": "widget", "to": "Label", "opts": {"text": "text", "textvariable": "text", "image": "image"}},
    "ttk.Label": {"kind": "widget", "to": "Label", "opts": {"text": "text", "textvariable": "text", "image": "image"}},
    "Button": {"kind": "widget", "to": "Button", "opts": {"text": "text", "command": "on_click", "image": "image"}},
    "ttk.Button": {"kind": "widget", "to": "Button", "opts": {"text": "text", "command": "on_click", "image": "image"}},
    "Entry": {"kind": "widget", "to": "Entry", "opts": {"textvariable": "var", "show": "password"}},
    "ttk.Entry": {"kind": "widget", "to": "Entry", "opts": {"textvariable": "var", "show": "password"}},
    "Checkbutton": {"kind": "widget", "to": "Checkbox", "opts": {"text": "text", "variable": "var", "command": "on_change0",
                                                                  "onvalue": "onvalue", "offvalue": "offvalue"}},
    "ttk.Checkbutton": {"kind": "widget", "to": "Checkbox", "opts": {"text": "text", "variable": "var", "command": "on_change0",
                                                                     "onvalue": "onvalue", "offvalue": "offvalue"}},
    "Message": {"kind": "widget", "to": "Label", "opts": {"text": "text", "textvariable": "text"}, "extra": "wrap=True"},
    "ttk.Sizegrip": {"kind": "widget", "to": "Spacer", "opts": {}},
    "scrolledtext.ScrolledText": {"kind": "widget", "to": "TextArea", "opts": {}},
    "Scale": {"kind": "widget", "to": "Slider", "opts": {"from_": "lo", "to": "hi", "variable": "var", "command": "on_change1", "resolution": "resolution"}},
    "ttk.Scale": {"kind": "widget", "to": "Slider", "opts": {"from_": "lo", "to": "hi", "variable": "var", "command": "on_change1", "resolution": "resolution"}},
    "ttk.Progressbar": {"kind": "widget", "to": "Progress", "opts": {"value": "value", "variable": "value", "mode": "mode"}},
    "ttk.Separator": {"kind": "widget", "to": "Separator", "opts": {}},
    "StringVar": {"kind": "var", "default": '""'}, "IntVar": {"kind": "var", "default": "0"},
    "DoubleVar": {"kind": "var", "default": "0.0"}, "BooleanVar": {"kind": "var", "default": "False"},
}
COSMETIC = {"font", "fg", "bg", "foreground", "background", "relief", "bd", "borderwidth", "padx", "pady",
            "anchor", "justify", "width", "height", "cursor", "style", "orient", "length", "wraplength",
            "highlightthickness", "activebackground", "activeforeground", "takefocus", "compound",
            "mode", "maximum", "underline", "selectcolor", "indicatoron", "tickinterval", "resolution", "showvalue",
            "bootstyle"}
LAYOUT_KEEP = {"side", "row", "column"}  # used to build the tree; other geometry options are approximated
PLACEHOLDER = {"kind": "placeholder", "to": "Placeholder"}
PH_DEFAULT = {"Spinbox": '"0"', "ttk.Spinbox": '"0"', "Combobox": '""', "ttk.Combobox": '""', "Listbox": "()"}
# tkinter constants -> the plain values they stand for
CONSTS = {n: n.lower() for n in (
    "END LEFT RIGHT TOP BOTTOM BOTH X Y N S E W NW NE SW SE NSEW NS EW CENTER NORMAL DISABLED ACTIVE HORIZONTAL "
    "VERTICAL INSERT SEL WORD CHAR NONE SUNKEN RAISED FLAT GROOVE RIDGE SOLID ANCHOR SINGLE BROWSE MULTIPLE "
    "EXTENDED READONLY BOLD ITALIC ROMAN ALL").split()}
CONSTS.update({n: n.lower() for n in (
    "FIRST LAST CURRENT ARC CHORD PIESLICE ROUND BUTT PROJECTING MITER BEVEL INSIDE OUTSIDE HIDDEN BASELINE DOTBOX "
    "UNDERLINE NUMERIC UNITS PAGES MOVETO SCROLL CASCADE CHECKBUTTON RADIOBUTTON COMMAND SEPARATOR").split()})
CONSTS.update({"YES": "1", "NO": "0", "TRUE": "1", "FALSE": "0", "ON": "1", "OFF": "0",
               "SEL_FIRST": "sel.first", "SEL_LAST": "sel.last"})
# methods the translated widgets understand; any other method call becomes ui.unsupported(...)
COMMON_METHODS = {"config", "configure", "destroy", "cget", "keys", "focus_set", "focus", "bind", "unbind", "state",
                  "instate", "invoke", "flash", "select", "deselect", "toggle", "start", "stop", "step", "pack_forget",
                  "grid_forget", "grid_remove", "winfo_width", "winfo_height", "winfo_class", "after", "update"}
OK_METHODS = {"Entry": COMMON_METHODS | {"get", "delete", "insert", "icursor", "index", "select_range",
                                         "selection_range", "selection_clear", "selection_get"},
              "Slider": COMMON_METHODS | {"get", "set"}}
OK_WINDOW = {"after", "after_idle", "after_cancel", "toast", "quit", "run", "post", "set_theme", "bind", "focus_set", "focus_force", "protocol", "register", "columnconfigure", "rowconfigure",
             "wm_attributes", "attributes", "event_generate", "title", "geometry", "minsize", "resizable", "destroy",
             "mainloop", "config", "configure", "bind_all"}
DIALOG_FUNCS = {"filedialog." + f for f in (
    "askopenfilename", "askopenfilenames", "asksaveasfilename", "askdirectory", "askopenfile", "askopenfiles",
    "asksaveasfile")} | {"simpledialog.askstring", "simpledialog.askinteger", "simpledialog.askfloat",
                         "colorchooser.askcolor", "messagebox.askquestion", "messagebox.askyesnocancel"}
# Tk accepts any unambiguous abbreviation of an option name; these are the ones seen in real code
OPT_ABBREV = {"textvar": "textvariable", "textvari": "textvariable", "text_var": "textvariable"}
NAME_MAP = {"TclError": "ui.TclError"}   # names that exist in tk4k under the same job
ASK = ("messagebox.askyesno", "messagebox.askokcancel", "messagebox.askretrycancel")
MSGBOX = ("messagebox.showinfo", "messagebox.showwarning", "messagebox.showerror")
DIALOG_REFS = set(DIALOG_FUNCS) | set(ASK) | set(MSGBOX)   # these names, used as values, map to ui.<name>


def tkname(qnames) -> str | None:
    """'tkinter.ttk.Button' -> 'ttk.Button', 'tkinter.Button' -> 'Button', 'tkinter.messagebox.showinfo' -> ..."""
    if callable(qnames):  # newer LibCST hands back lazy values
        qnames = qnames()
    for q in qnames or ():
        n = q.name
        if n.startswith("tkinter.ttk."):
            return "ttk." + n[len("tkinter.ttk."):]
        if n.startswith("tkinter.messagebox."):
            return "messagebox." + n[len("tkinter.messagebox."):]
        if n.startswith("tkinter.filedialog.") or n.startswith("tkinter.simpledialog."):
            return n[len("tkinter."):]
        if n.startswith("tkinter."):
            return n[len("tkinter."):]
    return None


@dataclass
class W:
    name: str                 # variable name ("" for anonymous widgets)
    cls: str                  # 'Label', 'ttk.Progressbar', ...
    rule: dict | None
    master: str | None
    args: list                # positional cst.Arg after master
    kw: dict                  # option -> cst expression
    line: int
    geom: str | None = None   # 'pack' | 'grid' | 'place'
    gopts: dict = field(default_factory=dict)
    order: int = 0            # geometry call order (pack order matters)
    children: list = field(default_factory=list)
    colweights: dict = field(default_factory=dict)


class Report:
    def __init__(self):
        self.notes: list[dict] = []
        self.translated = 0

    def add(self, level, line, msg):
        self.notes.append({"level": level, "line": line, "msg": msg})

    @property
    def grade(self):
        levels = {n["level"] for n in self.notes}
        return "unsafe" if "todo" in levels else "review" if "approx" in levels else "safe"


def code_of(node) -> str:
    return cst.Module(body=[]).code_for_node(node)


def const_str(e):
    return e.evaluated_value if isinstance(e, cst.SimpleString) else None


def const_int(e):
    if isinstance(e, cst.Integer):
        return int(e.value)
    s = const_str(e)
    return int(s) if s is not None and s.isdigit() else None


class StarQ:
    """QualifiedNameProvider results, plus names that come from `from tkinter import *` style imports.

    LibCST can't know what a star import brings in, so those names are looked up in a static table
    (generated from tkinter's own __all__). Later star imports win, like in Python (ttk's Label beats tk's).
    """

    def __init__(self, real, module):
        self.real = real
        self.mods = []
        for stmt in module.body:
            for s in getattr(stmt, "body", ()) if isinstance(stmt, cst.SimpleStatementLine) else ():
                if isinstance(s, cst.ImportFrom) and isinstance(s.names, cst.ImportStar) and s.module is not None \
                        and not s.relative:
                    m = code_of(s.module)
                    if m in STAR:
                        self.mods.append(m)

    def get(self, node, default=()):
        got = self.real.get(node, default)
        if callable(got):
            got = got()
        if got or not self.mods or not isinstance(node, cst.Name):
            return got
        for m in reversed(self.mods):
            if node.value in STAR[m]:
                return {QualifiedName(f"{m}.{node.value}", QualifiedNameSource.IMPORT)}
        return got


class Porter:
    def __init__(self, src: str, app: str = ""):
        self.app = app
        self.src = src
        self.mod = cst.parse_module(src)
        self.wrapper = MetadataWrapper(self.mod)
        self.q = StarQ(self.wrapper.resolve(QualifiedNameProvider), self.wrapper.module)
        self.pos = self.wrapper.resolve(PositionProvider)
        self.m = self.wrapper.module
        self.rep = Report()
        self.widgets: dict[str, W] = {}
        self.anon: list[W] = []
        self.window: W | None = None
        self.vars: dict[str, str] = {}
        self.unsupported: set[str] = set()
        self.todo_stmts: set[int] = set()
        self.ui_stmts: set[int] = set()       # indices of top-level statements that become the UI block
        self.title = None
        self.size = None
        self.geo_order = 0
        self.class_ui = False
        self.imperative = False
        self.maxima: dict = {}
        self.own_names = self._own_names(src)

    @staticmethod
    def _own_names(src: str) -> set:
        """Names the program itself assigns or declares global (they win over `from tkinter import *`)."""
        import ast as _ast
        try:
            tree = _ast.parse(src)
        except (SyntaxError, ValueError):
            return set()
        out = set()
        for n in _ast.walk(tree):
            if isinstance(n, _ast.Name) and isinstance(n.ctx, _ast.Store):
                out.add(n.id)
            elif isinstance(n, (_ast.Global, _ast.Nonlocal)):
                out.update(n.names)
            elif isinstance(n, (_ast.FunctionDef, _ast.ClassDef)):
                out.add(n.name)
        return out

    def const_name(self, e):
        """tkinter constant (tk.LEFT, END ...) -> its plain value, else None."""
        if isinstance(e, cst.Name) and e.value in self.own_names:
            return None   # the program's own ROUND/ACTIVE/... (it shadows the star-imported constant)
        if isinstance(e, (cst.Attribute, cst.Name)):
            n = tkname(self.q.get(e, ()))
            if n:
                tail = n.split(".")[-1]
                if tail in CONSTS:
                    return CONSTS[tail]
        return None

    def cs(self, e):
        """A constant string from a literal or a tkinter constant."""
        return const_str(e) if const_str(e) is not None else self.const_name(e)

    def line(self, node):
        try:
            return self.pos[node].start.line
        except KeyError:
            return 0

    def cls_of_call(self, call):
        if isinstance(call, cst.Call):
            n = tkname(self.q.get(call.func, ()))
            return n
        return None

    # ------------------------------------------------------------------ pass 1: understand the UI
    def analyse(self):
        if any(isinstance(s, cst.ClassDef) and "tkinter" in code_of(s) for s in self.m.body):
            pass
        for i, stmt in enumerate(self.m.body):
            if isinstance(stmt, cst.ClassDef):
                for b in stmt.bases:
                    if tkname(self.q.get(b.value, ())):
                        self.class_ui = True
            if not isinstance(stmt, cst.SimpleStatementLine) or len(stmt.body) != 1:
                continue
            s = stmt.body[0]
            if isinstance(s, cst.Assign) and len(s.targets) == 1 and isinstance(s.targets[0].target, cst.Name):
                name = s.targets[0].target.value
                cls = self.cls_of_call(s.value)
                if cls:
                    self._creation(i, name, cls, s.value)
            elif isinstance(s, cst.Expr) and isinstance(s.value, cst.Call):
                call = s.value
                f = call.func
                if isinstance(f, cst.Attribute) and isinstance(f.value, cst.Call) and self.cls_of_call(f.value) \
                        and f.attr.value in ("pack", "grid", "place"):
                    w = self._creation(i, "", self.cls_of_call(f.value), f.value)
                    if w:
                        self._geometry(i, w, f.attr.value, call)
                elif isinstance(f, cst.Attribute) and isinstance(f.value, cst.Name):
                    obj, meth = f.value.value, f.attr.value
                    if obj in self.widgets and meth in ("pack", "grid", "place"):
                        self._geometry(i, self.widgets[obj], meth, call)
                    elif self.window and obj == self.window.name and meth == "title" and call.args:
                        self.title = call.args[0].value
                        self.ui_stmts.add(i)
                    elif self.window and obj == self.window.name and meth == "geometry" and call.args:
                        g = const_str(call.args[0].value) or ""
                        try:
                            wh = g.split("+")[0].split("x")
                            self.size = (int(wh[0]), int(wh[1]))
                        except (ValueError, IndexError):
                            self.rep.add("approx", self.line(stmt), f"geometry {g!r} not understood; default size used")
                        self.ui_stmts.add(i)
                    elif obj in self.widgets and meth in ("columnconfigure", "grid_columnconfigure") and call.args:
                        col = const_int(call.args[0].value)
                        wt = next((const_int(a.value) for a in call.args if a.keyword and a.keyword.value == "weight"), None)
                        if col is not None and wt is not None:
                            self.widgets[obj].colweights[col] = wt
                            self.ui_stmts.add(i)
                    elif obj in self.widgets and meth in ("rowconfigure", "grid_rowconfigure", "pack_propagate",
                                                          "grid_propagate"):
                        self.rep.add("approx", self.line(stmt), f"{obj}.{meth}(...) has no TK 4K equivalent yet; dropped")
                        self.ui_stmts.add(i)

    def _creation(self, i, name, cls, call):
        rule = RULES.get(cls)
        ln = self.line(call)
        if rule and rule["kind"] == "var":
            self.vars[name] = cls
            return None
        if cls.startswith("messagebox.") or "dialog" in cls:
            return None
        if not rule:
            # a widget (or helper object) TK 4K does not have yet: keep its place with a placeholder
            if name:
                self.unsupported.add(name)
            self.rep.add("todo", ln, f"{cls} is not in TK 4K yet: {('`' + name + '`') if name else 'anonymous widget'} "
                         "replaced by a placeholder")
            rule = PLACEHOLDER
        args = list(call.args)
        master = None
        if args and args[0].keyword is None and isinstance(args[0].value, cst.Name):
            master = args[0].value.value
            args = args[1:]
        kw = {}
        for a in list(args):
            if a.keyword:
                kw[OPT_ABBREV.get(a.keyword.value, a.keyword.value)] = a.value
                args.remove(a)
        if "master" in kw and isinstance(kw["master"], cst.Name):
            master = kw.pop("master").value
        w = W(name, cls, rule, master, args, kw, ln)
        if rule is PLACEHOLDER:
            w.kw = {k: v for k, v in kw.items() if k in ("from_", "value", "values")}
            w.args = []
        if rule["kind"] == "window":
            self.window = w
        elif name:
            if name in self.widgets:                 # the same variable name re-used: keep the earlier widget too
                self.anon.append(self.widgets[name])
                self.rep.add("approx", ln, f"{name!r} is assigned more than once; both widgets are kept")
            self.widgets[name] = w
        else:
            self.anon.append(w)
        self.ui_stmts.add(i)
        return w

    def _geometry(self, i, w, how, call):
        w.geom = how
        self.geo_order += 1
        w.order = self.geo_order
        for a in call.args:
            if a.keyword:
                w.gopts[a.keyword.value] = a.value
        self.ui_stmts.add(i)
        if how == "place":
            self.rep.add("approx", w.line, "place() has no TK 4K equivalent yet: widget put in normal flow")

    # ------------------------------------------------------------------ pass 2: build the TK 4K tree
    def tree(self):
        all_w = list(self.widgets.values()) + self.anon
        root_name = self.window.name if self.window else None
        by_master = {}
        valid = {n for n, w in self.widgets.items() if w.rule["kind"] != "placeholder"} | {root_name}
        for w in all_w:
            if w.master not in valid:
                if w.master is not None:
                    self.rep.add("approx", w.line, f"{w.name or w.cls}: parent {w.master!r} is not a TK 4K container; "
                                 "moved to the window")
                w.master = root_name
            by_master.setdefault(w.master, []).append(w)
        for w in all_w:
            w.children = by_master.get(w.name, []) if w.name else []
        top = by_master.get(root_name, [])
        for w in all_w:
            if w.geom is None and w.rule["kind"] not in ("container", "placeholder"):
                self.rep.add("approx", w.line, f"{w.name or w.cls} is never packed or gridded; shown anyway")
        return top

    def emit_widget(self, w, ind, dynamic=False):
        rule = w.rule
        if rule is PLACEHOLDER:
            dflt = PH_DEFAULT.get(w.cls, '""')
            if "from_" in w.kw and w.cls.endswith("Spinbox"):
                dflt = code_of(w.kw["from_"])
            hidden = ", visible=False" if w.geom is None else ""
            self.rep.translated += 0
            return [f"{ind}{w.name + ' = ' if w.name else ''}ui.Placeholder({w.cls!r}, name={w.name!r}, "
                    f"default={dflt}, line={w.line}{hidden})"]
        opts = []
        pos = []
        for k, v in w.kw.items():
            tgt = rule.get("opts", {}).get(k)
            vc = code_of(v)
            if self.window and vc == f"{self.window.name}.destroy":
                vc = f"{self.window.name}.quit"
            if tgt == "text":
                pos.insert(0, vc)
            elif tgt == "on_change0":
                opts.append(f"on_change=lambda _v: {vc}()")
            elif tgt == "on_change1":
                opts.append(f"on_change=lambda _v: {vc}(_v)")
            elif tgt == "password":
                opts.append("password=True")
            elif tgt:
                opts.append(f"{tgt}={vc}")
            elif w.cls == "ttk.Progressbar" and k == "maximum":
                if dynamic:
                    opts.append(f"maximum={vc}")  # run-time: Progress divides by it itself
            elif k == "name":
                opts.append(f"name={vc}")  # Widget.winfo_name() / nametowidget() use it
            elif k == "orient" and self.cs(v) == "horizontal":
                pass  # TK 4K sliders are horizontal
            elif k in COSMETIC:
                self.rep.add("approx", w.line, f"{w.cls} option {k}= dropped (TK 4K theme decides)")
            else:
                self.rep.add("approx", w.line, f"{w.cls} option {k}= has no TK 4K equivalent; dropped")
        if w.cls == "ttk.Progressbar" and dynamic:
            if not any(o.startswith("maximum=") for o in opts):
                opts.append("maximum=100")
        elif w.cls == "ttk.Progressbar":
            mx = w.kw.get("maximum")
            self.maxima[w.name] = code_of(mx) if mx is not None else "100"
            if not any(o.startswith("value=") for o in opts):
                pos.insert(0, "0.0")
        for a in w.args:
            pos.append(code_of(a.value))
        if rule.get("extra"):
            opts.append(rule["extra"])
        if w.cls == "Scale" and "resolution" not in w.kw and not any(o.startswith("resolution=") for o in opts):
            opts.append("resolution=1")   # tkinter's Scale snaps to whole numbers unless told otherwise (ttk.Scale does not)
        call = f"ui.{rule['to']}({', '.join(pos + opts)})"
        self.rep.translated += 1
        return [f"{ind}{w.name + ' = ' if w.name else ''}{call}"]

    def emit_container(self, kids, ind, how, owner=None, box_name=None):
        """kids: widgets managed in one parent. Returns lines building them inside a TK 4K container."""
        out = []
        mode = "grid" if any(k.geom == "grid" for k in kids) else "pack"
        if mode == "grid":
            cells = {}
            hidden = [k for k in kids if k.geom != "grid"]
            for k in hidden:
                out += self.emit_node(k, ind)
            kids = [k for k in kids if k.geom == "grid"]
            for k in kids:
                r = const_int(k.gopts.get("row")) if "row" in k.gopts else 0
                c = const_int(k.gopts.get("column")) if "column" in k.gopts else 0
                if r is None or c is None:
                    self.rep.add("todo", k.line, "grid row/column is not a constant: cannot place it")
                    continue
                if any(x in k.gopts for x in ("columnspan", "rowspan")):
                    self.rep.add("approx", k.line, "columnspan/rowspan not in TK 4K Grid yet: one cell used")
                cells[(r, c)] = k
            ncols = max((c for _, c in cells), default=0) + 1
            nrows = max((r for r, _ in cells), default=-1) + 1
            weights = [owner.colweights.get(i, 0) if owner else 0 for i in range(ncols)]
            if not any(weights):
                weights = [0] * (ncols - 1) + [1]
            head = f"{ind}with ui.Grid(columns={ncols}, weights={weights})" + (f" as {box_name}:" if box_name else ":")
            out.append(head)
            for r in range(nrows):
                for c in range(ncols):
                    k = cells.get((r, c))
                    if k is None:
                        out.append(f"{ind}    ui.Spacer()")
                    else:
                        out += self.emit_node(k, ind + "    ")
            return out
        # pack: the packer cuts strips off the sides of the remaining space, in order -> nested rows/columns
        seq = sorted([k for k in kids if k.geom in ("pack", "place", None)], key=lambda k: (k.order == 0, k.order))
        return self._emit_pack(seq, ind, box_name)

    def _emit_pack(self, seq, ind, box_name=None):
        if not seq:
            return [f"{ind}with ui.Column()" + (f" as {box_name}:" if box_name else ":"), f"{ind}    pass"]

        def side(k):
            s = self.cs(k.gopts.get("side")) if "side" in k.gopts else None
            return (s or "top").lower()

        axis_v = side(seq[0]) in ("top", "bottom")
        start, end, rest = [], [], []
        for idx, k in enumerate(seq):
            sv = side(k) in ("top", "bottom")
            if sv != axis_v:
                rest = seq[idx:]
                break
            (start if side(k) in ("top", "left") else end).append(k)
            for opt in ("fill", "expand", "ipadx", "ipady"):
                if opt in k.gopts:
                    self.rep.add("approx", k.line, f"pack {opt}= approximated (TK 4K rows/columns size children themselves)")
        if end:
            self.rep.add("approx", end[0].line, "bottom/right-packed widgets come after the others; not pinned to the far edge yet")
        out = [f"{ind}with ui.{'Column' if axis_v else 'Row'}()" + (f" as {box_name}:" if box_name else ":")]
        for k in start:
            out += self.emit_node(k, ind + "    ")
        if rest:
            out += self._emit_pack(rest, ind + "    ")
        for k in reversed(end):
            out += self.emit_node(k, ind + "    ")
        return out

    def emit_node(self, w, ind):
        if w.rule["kind"] == "container":
            lines = []
            title = w.kw.get("text")
            if title is not None:
                self.rep.add("approx", w.line, "LabelFrame title shown as a label above its contents")
            body = self.emit_container(w.children, ind, None, owner=w, box_name=w.name or None)
            if title is not None:
                body.insert(1, f"{ind}    ui.Label({code_of(title)}, dim=True)")
            self.rep.translated += 1
            return lines + body
        return self.emit_widget(w, ind)

    def ui_block(self, top):
        self.maxima = {}
        t = code_of(self.title) if self.title is not None else '"TK 4K"'
        size = f", size={self.size}" if self.size else ""
        name = self.window.name if self.window else "root"
        lines = [f"with ui.Window({t}{size}) as {name}:"]
        lines += self.emit_container(top, "    ", None)
        return lines

    # ------------------------------------------------------------------ pass 3: rewrite the rest
    def _count_creations(self) -> int:
        n = [0]
        porter = self

        class V(cst.CSTVisitor):
            def visit_Call(self, c):
                k = tkname(porter.q.get(c.func, ()))
                if k and (RULES.get(k, {}).get("kind") in ("widget", "container") or (k not in RULES and k[:1].isupper()
                          and not k.endswith("Var") and not k.startswith("messagebox") and "dialog" not in k)):
                    n[0] += 1
        self.m.visit(V())
        return n[0]

    # Libraries built on live tkinter objects (they read widget.tk, call tk.call, subclass tk.Frame...). A TK 4K widget
    # cannot be handed to them, so a file that imports them cannot be fully ported: say so, and point to tk4k.classic.
    REAL_TK_LIBS = {
        "turtle": "the turtle module draws on a real tkinter Canvas",
        "turtledemo": "turtledemo uses the turtle module's real tkinter canvas",
        "idlelib": "IDLE's modules (syntax colouring, Percolator, dialogs) operate on real tkinter Text widgets",
        "matplotlib.backends.backend_tkagg": "the Tk backend draws into a real tkinter widget",
        "matplotlib.backends._backend_tk": "the Tk backend draws into a real tkinter widget",
        "tkinterdnd2": "drag-and-drop is patched into real tkinter windows",
        "tkintermapview": "the map is a real tkinter widget",
        "customtkinter": "CustomTkinter widgets are real tkinter widgets",
        "ttkbootstrap": "ttkbootstrap restyles real ttk widgets",
        "ttkthemes": "ttkthemes restyles real ttk widgets",
        "sv_ttk": "sv_ttk restyles real ttk widgets",
        "tkcalendar": "tkcalendar widgets are real tkinter widgets",
        "tksheet": "tksheet is a real tkinter widget",
        "tkinterweb": "tkinterweb is a real tkinter widget",
        "tktooltip": "tktooltip attaches to real tkinter widgets",
        "pygubu": "pygubu builds real tkinter widgets from UI files",
        "PySimpleGUI": "PySimpleGUI builds real tkinter windows itself",
        "tkinter.tix": "Tix widgets (Balloon, ComboBox...) are Tk extensions; Python 3.13 removed tkinter.tix",
        "tix": "Tix widgets are Tk extensions; Python 3.13 removed tkinter.tix",
    }

    def _flag_real_tk_libs(self):
        """One 'todo' note per import of a library that needs real tkinter widgets (grade becomes unsafe)."""
        import ast
        try:
            tree = ast.parse(self.src)
        except (SyntaxError, ValueError):
            return
        seen = set()
        for node in ast.walk(tree):
            mods = []
            if isinstance(node, ast.Import):
                mods = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                mods = [node.module] + [f"{node.module}.{a.name}" for a in node.names]
            for m in mods:
                for lib, why in self.REAL_TK_LIBS.items():
                    if (m == lib or m.startswith(lib + ".")) and lib not in seen:
                        seen.add(lib)
                        self.rep.add("todo", node.lineno,
                                     f"`{lib}` needs real tkinter widgets ({why}); TK 4K widgets cannot be passed to it. "
                                     "Run this app with `python -m tk4k.classic` instead (real Tk, TK 4K look), "
                                     "or port the parts that do not use it")

    def run(self):
        self.analyse()
        self._flag_real_tk_libs()
        static = len(self.widgets) + len(self.anon)
        hard = any(w.rule is PLACEHOLDER and w.cls.split('.')[-1] in Rewriter.HARD for w in list(self.widgets.values()) + self.anon)
        if self.class_ui or hard or self._count_creations() > static or (not self.window and self._count_creations()):
            return self.run_imperative()
        if not self.window:
            self.rep.add("todo", 0, "no tkinter Tk() window found at module level; nothing translated "
                         "(try python -m tk4k.classic for the skin only)")
            return None
        top = self.tree()
        block = self.ui_block(top)
        last = max(self.ui_stmts)
        body = list(self.m.body)
        widget_names = set(self.widgets) | {self.window.name}
        new_body, moved_after = [], []
        for i, stmt in enumerate(body):
            if i in self.ui_stmts:
                if i == last:
                    new_body += [cst.parse_statement(s + "\n") for s in ["\n".join(block)]]
                    new_body += moved_after
                continue
            if self._is_tk_import(stmt):
                if not any(isinstance(n, cst.SimpleStatementLine) and "import tk4k as ui" in code_of(n) for n in new_body):
                    new_body.append(cst.parse_statement("import tk4k as ui\n"))
                    new_body.append(cst.parse_statement(f"ui.install_alerts(app={self.app!r})\n"))
                continue
            if self._var_assign(stmt):
                new_body.append(self._var_assign(stmt))
                continue
            min_ui = min(self.ui_stmts)
            if min_ui < i < last and isinstance(stmt, cst.SimpleStatementLine) and self._touches(stmt, widget_names):
                moved_after.append(stmt)   # e.g. `bill.insert(0, "42")` right after the widget: run it after the UI exists
                continue
            new_body.append(stmt)
        if moved_after and self._moved_feed_earlier(moved_after, block, new_body):
            # e.g. `w = root.winfo_screenwidth()` used to size the window: the program's order matters, keep it
            return self.run_imperative()
        mod = self.m.with_changes(body=new_body)
        mod = mod.visit(Rewriter(self))
        return mod.code

    @staticmethod
    def _moved_feed_earlier(moved, block, new_body) -> bool:
        """Do statements moved after the UI block assign names that the block (or code before it) reads?"""
        import ast as _ast
        assigned = set()
        for st in moved:
            try:
                for n in _ast.walk(_ast.parse(code_of(st))):
                    if isinstance(n, _ast.Name) and isinstance(n.ctx, _ast.Store):
                        assigned.add(n.id)
            except SyntaxError:
                return True
        if not assigned:
            return False
        text = "\n".join(block) + "\n" + "\n".join(code_of(st) for st in new_body)
        try:
            reads = {n.id for n in _ast.walk(_ast.parse(text)) if isinstance(n, _ast.Name) and isinstance(n.ctx, _ast.Load)}
        except SyntaxError:
            return True
        return bool(assigned & reads)

    def run_imperative(self):
        """Keep the program's own structure (classes, functions, loops, pack/grid calls) and swap the names.

        Widgets are created where the program creates them, with parent=...; pack/grid options are
        used at run time by TK 4K (side, fill, row, column, columnspan, sticky).
        """
        self.imperative = True
        # the static pass reported widgets it could not place; this mode creates real widgets or says so itself
        self.rep.notes = [n for n in self.rep.notes if "is not in TK 4K yet" not in n["msg"]]
        self.rep.add("approx", 0, "imperative mode: the program's structure is kept; pack/grid are interpreted at run "
                     "time (side, fill, row, column, columnspan, sticky); other options are ignored")
        body = []
        for stmt in self.m.body:
            if self._is_tk_import(stmt):
                if not any(isinstance(n, cst.SimpleStatementLine) and "import tk4k as ui" in code_of(n) for n in body):
                    body.append(cst.parse_statement("import tk4k as ui\n"))
                    body.append(cst.parse_statement(f"ui.install_alerts(app={self.app!r})\n"))
                continue
            body.append(stmt)
        mod = self.m.with_changes(body=body)
        mod = mod.visit(Rewriter(self, imperative=True))
        return mod.code

    def _is_tk_import(self, stmt):
        if isinstance(stmt, cst.SimpleStatementLine) and len(stmt.body) == 1:
            s = stmt.body[0]
            c = code_of(s)
            if isinstance(s, (cst.Import, cst.ImportFrom)) and ("tkinter" in c or "Tkinter" in c):
                return True
        return False

    def _var_assign(self, stmt):
        if isinstance(stmt, cst.SimpleStatementLine) and len(stmt.body) == 1 and isinstance(stmt.body[0], cst.Assign):
            s = stmt.body[0]
            cls = self.cls_of_call(s.value)
            if cls and RULES.get(cls, {}).get("kind") == "var":
                val = next((code_of(a.value) for a in s.value.args if a.keyword and a.keyword.value == "value"), None)
                if val is None:
                    pos = [a for a in s.value.args if a.keyword is None]
                    val = code_of(pos[1].value) if len(pos) > 1 else RULES[cls]["default"]
                tgt = code_of(s.targets[0].target)
                self.rep.translated += 1
                return stmt.with_changes(body=[cst.parse_statement(f"{tgt} = ui.Var({val})\n").body[0]])
        return None

    def _touches(self, stmt, names):
        found = []

        class V(cst.CSTVisitor):
            def visit_Name(self, n):
                if n.value in names:
                    found.append(n.value)
        stmt.visit(V())
        return bool(found)


class Rewriter(cst.CSTTransformer):
    """Rewrites uses of widgets in the code that remains (callbacks, set-up lines).

    Nothing is deleted: anything TK 4K cannot do becomes a call to ui.unsupported(...), which logs it
    at run time and returns a harmless null object, so the program keeps going and says what it skipped.
    """

    def __init__(self, p: Porter, imperative: bool = False):
        self.p = p
        self.imp = imperative
        self.kinds = {n: w.rule.get("to") for n, w in p.widgets.items()}
        self.win = p.window.name if p.window else "None"
        self.skip: set[int] = set()
        self.dyn: set[str] = set()       # variables holding widgets created inside functions / loops
        self.dyn_noted = False
        # tkinter subclasses that use a name TK 4K keeps its own state in (self.text in a Frame subclass...):
        # renamed inside the class, see _anticipate.class_renames
        try:
            from ._anticipate import class_renames
            self.renames = class_renames(p.src)
        except Exception:  # pragma: no cover
            self.renames = {}
        self.cls_stack: list[str] = []
        for cname, names in self.renames.items():
            p.rep.add("approx", 0, f"class {cname}: renamed {', '.join('self.' + n for n in sorted(names))} to "
                      f"{', '.join('self.' + n + '_' for n in sorted(names))} (TK 4K widgets use those names "
                      "for their own state)")

    # ---- helpers
    def _unsup(self, orig, text):
        ln = self.p.line(orig)
        self.p.rep.add("todo", ln, f"{text} is not supported yet: replaced by ui.unsupported(...)")
        return cst.parse_expression(f"ui.unsupported({text!r}, {ln})")

    def _dyn_note(self, orig):
        if not self.dyn_noted:
            self.dyn_noted = True
            self.p.rep.add("approx", self.p.line(orig), "widgets created inside functions/loops are appended in "
                           "creation order; their pack/grid/place options are ignored")

    def _master_code(self, e):
        return code_of(e) if isinstance(e, (cst.Name, cst.Attribute)) else None

    HARD = {"Menu": "Menu", "Canvas": "Canvas", "Text": "TextArea", "Listbox": "Listbox", "Combobox": "Dropdown",
            "Notebook": "Tabs", "Radiobutton": "Radio", "Spinbox": "Spinbox", "Treeview": "Tree",
            "Scrollbar": "Scrollbar", "Toplevel": "Toplevel", "Style": "Style",
            "OptionMenu": "Dropdown", "Menubutton": "Button", "PanedWindow": "Frame", "PhotoImage": "PhotoImage",
            "Font": "Font"}

    def _hard_widget(self, cls, kw, master, pos, ln):
        """The widgets added in TK 4K 0.4.0, with the options they understand."""
        base = cls.split(".")[-1]
        to = self.HARD[base]
        c = {k: code_of(v) for k, v in kw.items()}
        if base == "PanedWindow" and "vertical" not in c.get("orient", ""):
            to = "Row"   # tkinter's default PanedWindow orientation is horizontal: panes side by side
        a: list[str] = []
        if base == "Canvas":
            a = [c.get("width", "300"), c.get("height", "200")] + ([f"bg={c['bg']}"] if "bg" in c else [])
        elif base == "Text":
            a = [f"height={c['height']} * 20" if "height" in c else "height=120"]
            if "width" in c:  # characters -> points (about 8 per character in the theme font)
                a.append(f"width={c['width']} * 8")
        elif base == "Listbox":
            a = [f"height={c['height']}"] if "height" in c else []
            if "selectmode" in c:
                a.append(f"selectmode={c['selectmode']}")
        elif base == "OptionMenu":
            vals = "[" + ", ".join(pos[1:]) + "]"
            v = pos[0] if pos else "None"
            a = [vals, f"index=({vals}.index({v}.get()) if {v}.get() in {vals} else 0)",
                 f"on_change=lambda _i, _v: {v}.set(_v)"]
        elif base == "Menubutton":
            a = [c.get("text", '""')]
        elif base == "Combobox":
            a = [c.get("values", "[]")] if "values" in c else []
            a = [f"list({x})" for x in a]
            st = c.get("state", "")
            a.append("editable=False" if "readonly" in st else ("editable=True" if not st or "normal" in st
                                                                 else f"editable=({st} == 'normal')"))
            if "textvariable" in c:
                a.append(f"var={c['textvariable']}")
        elif base == "Font":
            return "ui.Font(" + ", ".join(f"{k}={v}" for k, v in c.items() if k in ("family", "size", "weight", "slant")) + ")"
        elif base == "PhotoImage":
            return "ui.PhotoImage(" + ", ".join(f"{k}={v}" for k, v in c.items() if k in ("file", "data", "width", "height")) + ")"
        elif base == "Radiobutton":
            a = [c.get("text", '""'), c.get("value", "1")]
            if "variable" in c:
                a.append(f"var={c['variable']}")
            if "command" in c:
                a.append(f"on_change=lambda _v: {c['command']}()")
        elif base == "Spinbox":
            a = [c.get("from_", "0"), c.get("to", "100"), c.get("increment", "1")]
            if "values" in c:
                a.append(f"values={c['values']}")
            if "wrap" in c:
                a.append(f"wrap={c['wrap']}")
            if "textvariable" in c:
                a.append(f"var={c['textvariable']}")
        elif base == "Treeview":
            if "columns" in c:
                a.append(f"columns={c['columns']}")
            if "show" in c:
                a.append(f"show={c['show']}")
            if "selectmode" in c:
                a.append(f"selectmode={c['selectmode']}")
        for k in kw:
            if k not in ("width", "height", "bg", "values", "selectmode", "text", "value", "variable", "command",
                         "from_", "to", "increment", "columns", "show", "textvariable", "orient", "menu",
                         "state", "file", "data", "master", "wrap"):
                if k not in COSMETIC:
                    self.p.rep.add("approx", ln, f"{cls} option {k}= has no TK 4K equivalent; dropped")
        self.p.rep.translated += 1
        if base in ("Menu", "Style"):
            return f"ui.{to}()"
        if base == "Toplevel":
            return f"ui.Toplevel({master})" if master else "ui.Toplevel()"
        if master:
            a.append(f"parent={master}")
        return f"ui.{to}({', '.join(a)})"

    def _unbound_star(self, orig, node):
        """`from tkinter import *` ... `Grid.columnconfigure(root, ...)`: the class name resolves, the attribute not."""
        f = orig.func
        if isinstance(f, cst.Attribute) and isinstance(f.value, cst.Name) and f.value.value[:1].isupper() \
                and f.value.value not in self.p.own_names:
            base = tkname(self.p.q.get(f.value, ()))
            if base and base[:1].isupper():
                return self._unbound(orig, node, base + "." + f.attr.value)
        return None

    def _unbound(self, orig, node, n):
        """`Grid.columnconfigure(root, 0, weight=1)` / `tk.Frame.config(self, bg=...)`: a tkinter class's method
        called with the widget as first argument -> `root.columnconfigure(0, weight=1)`."""
        parts = n.split(".")
        if len(parts) < 2 or not parts[-2][:1].isupper() or parts[-1].startswith("_") or not node.args \
                or node.args[0].keyword is not None or node.args[0].star:
            return None
        if not isinstance(orig.func, cst.Attribute) or not isinstance(orig.func.value, (cst.Name, cst.Attribute)):
            return None    # tk.PhotoImage(...).zoom(16) is a method of a new object, not an unbound call
        if isinstance(orig.func.value, cst.Name) and not orig.func.value.value[:1].isupper():
            return None
        meth = parts[-1]
        if meth not in TK_ALL:
            return None
        self.p.rep.add("approx", self.p.line(orig), f"{n}(widget, ...) became widget.{meth}(...)")
        return cst.Call(func=cst.Attribute(value=node.args[0].value, attr=cst.Name(meth)), args=list(node.args[1:]))

    def _base_init(self, orig, node, cls):
        """`tk.Frame.__init__(self, master, **kw)` inside a subclass: the same call on the TK 4K base class."""
        to = {"Tk": "Window", "Toplevel": "Toplevel"}.get(cls) or ("Frame" if RULES.get(cls, {}).get("kind") == "container" else None)
        short = cls.split(".")[-1]
        if to is None and short in _ADAPTERS:   # tk.Canvas.__init__(self, master, width=...): same arguments, adapter base
            return node.with_changes(func=cst.parse_expression(f"ui.tkbase.{_ADAPTERS[short]}.__init__"))
        pos = [a for a in node.args if not a.keyword and not a.star]
        if to is None or not pos:
            return self._unsup(orig, f"tkinter.{cls}.__init__(...)")
        own = [code_of(pos[0].value)]
        m = None
        if len(pos) > 1:
            m = code_of(pos[1].value)
        else:
            mk = next((a for a in node.args if a.keyword and a.keyword.value == "master"), None)
            m = code_of(mk.value) if mk else None
        if m and to != "Window":
            own.append(m)
        if any(a.keyword and a.keyword.value not in ("master",) for a in node.args) or any(a.star for a in node.args):
            self.p.rep.add("approx", self.p.line(orig), f"{cls}.__init__ options dropped (TK 4K theme decides)")
        return cst.parse_expression(f"ui.{to}.__init__({', '.join(own)})")

    def _dynamic_widget(self, orig, node, cls):
        """tk.Label(parent, **options): the **options are applied at run time with ui._with_options(widget, options)."""
        stars = [a for a in node.args if a.star == "**"]
        if not stars:
            return self._dynamic_widget_inner(orig, node, cls)
        node2 = node.with_changes(args=[a for a in node.args if a.star not in ("**",)])
        inner = self._dynamic_widget_inner(orig, node2, cls)
        opts = code_of(stars[0].value) if len(stars) == 1 else "{" + ", ".join("**" + code_of(a.value) for a in stars) + "}"
        self.p.rep.add("approx", self.p.line(orig), f"{cls}(..., **options): options are applied at run time through .config(); unknown ones are ignored")
        return cst.parse_expression(f"ui._with_options({code_of(inner)}, {opts})")

    def _dynamic_widget_inner(self, orig, node, cls):
        """tk.Label(parent, text=...) inside a function, loop or class -> ui.Label(..., parent=parent)."""
        if self.imp and cls.split(".")[-1] in self.HARD and cls not in RULES:
            args0 = list(node.args)
            m0 = None
            if args0 and args0[0].keyword is None and self._master_code(args0[0].value):
                m0 = self._master_code(args0[0].value)
                args0 = args0[1:]
            kw0 = {a.keyword.value: a.value for a in args0 if a.keyword}
            if "master" in kw0 and self._master_code(kw0["master"]):
                m0 = self._master_code(kw0.pop("master"))
            pos0 = [("*" if a.star == "*" else "") + code_of(a.value) for a in args0 if not a.keyword]
            return cst.parse_expression(self._hard_widget(cls, kw0, m0, pos0, self.p.line(orig)))
        rule = RULES.get(cls) or PLACEHOLDER
        args = list(node.args)
        master = None
        if args and args[0].keyword is None and self._master_code(args[0].value):
            master = self._master_code(args[0].value)
            args = args[1:]
        kw = {OPT_ABBREV.get(a.keyword.value, a.keyword.value): a.value for a in args if a.keyword}
        if "master" in kw and self._master_code(kw["master"]):
            master = self._master_code(kw.pop("master"))
        pos = [a for a in args if not a.keyword]
        ln = self.p.line(orig)
        if not self.imp:
            self._dyn_note(orig)
        known = master and (self.imp or master in self.p.widgets or master == self.win or master in self.dyn)
        parent = f"parent={master}" if known else (f"parent={self.win}" if self.win != "None" else "")
        if rule is PLACEHOLDER:
            self.p.rep.add("todo", ln, f"{cls} is not in TK 4K yet: replaced by a placeholder")
            dflt = PH_DEFAULT.get(cls, '""')
            ex = ", " + parent if parent else ""
            return cst.parse_expression(f"ui.Placeholder({cls!r}, name='', default={dflt}, line={ln}{ex})")
        if rule["kind"] == "container":
            self.p.rep.translated += 1
            t = ""
            if "text" in kw:
                t = f", text={code_of(kw['text'])}"
            ex = (", " + parent) if parent else ""
            return cst.parse_expression(f"ui.Frame({ex[2:]}{t})" if ex else f"ui.Frame({t[2:]})")
        w = W("", cls, rule, master, pos, kw, ln)
        line = self.p.emit_widget(w, "", dynamic=True)[0]
        assert line.endswith(")")
        extra = parent
        sep = "" if (line.endswith("()") or not extra) else ", "
        return cst.parse_expression(line[:-1] + sep + extra + ")")

    def _imp_call(self, orig, node):
        n = tkname(self.p.q.get(orig.func, ()))
        if not n:
            return self._unbound_star(orig, node)
        if n in DIALOG_FUNCS:
            self.p.rep.add("approx", self.p.line(orig), f"{n} opens an in-app dialog and waits for the answer (no native look)")
            f = node.with_changes(func=cst.parse_expression("ui." + n.split(".")[-1]))
            return f
        if n.split(".")[0] in ("filedialog", "simpledialog", "colorchooser", "dialog", "commondialog"):
            self.p.rep.add("todo", self.p.line(orig), f"{n} cannot block the window; use win.ask_open_file / ask_string with a callback")
            return self._unsup(orig, f"{n}(...)")
        if n.endswith(".__init__"):
            return self._base_init(orig, node, n[:-len(".__init__")])
        last = n.split(".")[-1]
        r = self._unbound(orig, node, n)
        if r is not None:
            return r
        if last[:1].islower() and n not in MSGBOX and n not in ASK and n != "mainloop":
            return None  # a method call such as Button(...).pack() or var.get(): left for the run-time layer
        if n == "Tk":
            return cst.parse_expression("ui.Window()")
        if n in MSGBOX:
            a = [code_of(x.value) for x in node.args if not x.keyword]
            msg = a[1] if len(a) > 1 else (a[0] if a else '""')
            self.p.rep.add("approx", self.p.line(orig), f"{n} became a toast (it no longer waits for OK)")
            return cst.parse_expression(f"ui.toast({msg})")
        if n in ASK:
            a = [code_of(x.value) for x in node.args if not x.keyword]
            msg = a[1] if len(a) > 1 else (a[0] if a else '""')
            self.p.rep.add("approx", self.p.line(orig), f"{n} opens an in-app Yes/No dialog and waits for the answer")
            return cst.parse_expression(f"ui.ask({msg})")
        if n == "mainloop":
            return cst.parse_expression("ui.mainloop()")
        if RULES.get(n, {}).get("kind") == "var":
            return self._var_expr(orig, node, n)
        if RULES.get(n, {}).get("kind") in ("widget", "container") or (
                n not in RULES and n.split(".")[-1][:1].isupper() and "Var" not in n and "dialog" not in n):
            return self._dynamic_widget(orig, node, n)
        return self._unsup(orig, f"tkinter.{n}(...)")

    def leave_Call_isinstance(self, orig, node):
        def one(e, oe):
            k = tkname(self.p.q.get(oe, ()))
            to = {"Tk": "Window", "Toplevel": "Toplevel"}.get(k) or (
                "Frame" if RULES.get(k or "", {}).get("kind") == "container" else
                RULES.get(k or "", {}).get("to") or self.HARD.get((k or "").split(".")[-1]))
            return cst.parse_expression("ui." + to) if to else e
        a1, o1 = node.args[1], orig.args[1]
        if isinstance(a1.value, cst.Tuple):
            els = [el.with_changes(value=one(el.value, oel.value)) for el, oel in zip(a1.value.elements, o1.value.elements)]
            return node.with_changes(args=[node.args[0], a1.with_changes(value=a1.value.with_changes(elements=els))])
        return node.with_changes(args=[node.args[0], a1.with_changes(value=one(a1.value, o1.value))])

    def visit_ClassDef(self, n):
        self.cls_stack.append(n.name.value)
        for b in n.bases:
            self.skip.add(id(b.value))
        return True

    def _renamed(self, name: str) -> bool:
        return bool(self.cls_stack) and name in self.renames.get(self.cls_stack[-1], ())

    def leave_FunctionDef(self, orig, node):
        if self._renamed(node.name.value):
            return node.with_changes(name=cst.Name(node.name.value + "_"))
        return node

    def leave_ClassDef(self, orig, node):
        if self.cls_stack:
            self.cls_stack.pop()
        return self._leave_class(orig, node)

    def _leave_class(self, orig, node):
        if not self.imp:
            return node
        bases = []
        for b, ob in zip(node.bases, orig.bases):
            k = tkname(self.p.q.get(ob.value, ()))
            if k == "Tk":
                bases.append(b.with_changes(value=cst.parse_expression("ui.Window")))
            elif k == "Toplevel":
                bases.append(b.with_changes(value=cst.parse_expression("ui.Toplevel")))
            elif k == "simpledialog.Dialog":
                bases.append(b.with_changes(value=cst.parse_expression("ui.SimpleDialog")))
            elif k and RULES.get(k, {}).get("kind") == "container":
                bases.append(b.with_changes(value=cst.parse_expression("ui.Frame")))
            elif k and k.split(".")[-1] in _ADAPTERS:
                # tkinter's (master, cnf, **options) signature, so the subclass's super().__init__(master, ...) fits
                bases.append(b.with_changes(value=cst.parse_expression("ui.tkbase." + _ADAPTERS[k.split(".")[-1]])))
            elif k and RULES.get(k, {}).get("kind") == "widget":
                bases.append(b.with_changes(value=cst.parse_expression("ui." + RULES[k]["to"])))
            elif k:
                self.p.rep.add("todo", self.p.line(orig), f"class {orig.name.value} subclasses tkinter.{k}, which TK 4K lacks")
                bases.append(b.with_changes(value=cst.parse_expression("ui.Frame")))
            else:
                bases.append(b)
        return node.with_changes(bases=bases)

    def _var_expr(self, orig, node, cls):
        val = next((code_of(a.value) for a in node.args if a.keyword and a.keyword.value == "value"), None)
        if val is None:
            pos = [a for a in node.args if a.keyword is None]
            val = code_of(pos[-1].value) if len(pos) > 1 else RULES[cls]["default"]
        return cst.parse_expression(f"ui.Var({val})")

    # ---- don't look inside imports; remember which nodes are the left side of a call / dotted name
    def visit_Assign(self, n):
        # remember variables that will hold a dynamically created TK 4K widget, so name.pack() on them can be dropped
        if isinstance(n.value, cst.Call) and len(n.targets) == 1 and isinstance(n.targets[0].target, cst.Name):
            c = tkname(self.p.q.get(n.value.func, ()))
            if c and RULES.get(c, {}).get("kind") in ("widget", "container"):
                self.dyn.add(n.targets[0].target.value)
        return True

    def visit_Import(self, n):
        return False

    def visit_ImportFrom(self, n):
        return False

    def visit_Call(self, n):
        self.skip.add(id(n.func))
        # isinstance(w, tk.Toplevel): the class name is a value here, not a widget being built
        if isinstance(n.func, cst.Name) and n.func.value in ("isinstance", "issubclass") and len(n.args) == 2:
            for e in (n.args[1].value.elements if isinstance(n.args[1].value, cst.Tuple) else [n.args[1]]):
                self.skip.add(id(e.value))
        return True

    def visit_Attribute(self, n):
        self.skip.add(id(n.value))
        return True

    def _literal(self, c):
        return cst.parse_expression(c if c.isdigit() else repr(c))

    def leave_Name(self, orig, node):
        if id(orig) in self.skip:
            return node
        c = self.p.const_name(orig)
        if c is None:
            n = tkname(self.p.q.get(orig, ()))
            if n in NAME_MAP:
                return cst.parse_expression(NAME_MAP[n])
            if n in ("colorchooser", "messagebox", "filedialog", "simpledialog", "font", "ttk", "scrolledtext") and \
                    node.value == n:
                return cst.parse_expression("ui")   # the module itself used as a value (help(colorchooser))
        return self._literal(c) if c is not None else node

    def leave_Assign(self, orig, node):
        # `tk.Tk.some_hook = fn` : a tkinter name on the left side became ui.unsupported(...), which cannot be assigned to
        if any(isinstance(t.target, cst.Call) and code_of(t.target).startswith("ui.unsupported(") for t in node.targets):
            kept = [t for t in node.targets if not (isinstance(t.target, cst.Call)
                                                    and code_of(t.target).startswith("ui.unsupported("))]
            return node.with_changes(targets=kept or [cst.AssignTarget(cst.Name("_"))])
        return node

    def leave_Attribute(self, orig, node):
        if isinstance(node.value, cst.Name) and node.value.value == "self" and self._renamed(node.attr.value):
            return node.with_changes(attr=cst.Name(node.attr.value + "_"))
        if isinstance(node.value, cst.Name) and node.value.value == self.win and node.attr.value == "destroy":
            return node.with_changes(attr=cst.Name("quit"))
        if id(orig) in self.skip:
            return node
        c = self.p.const_name(orig)
        if c is not None:
            return self._literal(c)
        n = tkname(self.p.q.get(orig, ()))
        if n in NAME_MAP:
            return cst.parse_expression(NAME_MAP[n])
        if n in ("font.families", "font.nametofont", "font.names"):
            return cst.parse_expression("ui." + n.split(".")[-1])
        if n in DIALOG_REFS and id(orig) not in self.skip:
            return cst.parse_expression("ui." + n.split(".")[-1])
        if n:
            return self._unsup(orig, f"tkinter.{n}")
        return node

    def leave_Call(self, orig, node):
        f = node.func
        if isinstance(f, cst.Name) and f.value in ("isinstance", "issubclass") and len(node.args) == 2:
            return self.leave_Call_isinstance(orig, node)
        fn = tkname(self.p.q.get(orig.func, ()))
        if fn in ("font.families", "font.nametofont", "font.names"):
            return node.with_changes(func=cst.parse_expression("ui." + fn.split(".")[-1]))
        if self.imp:
            r = self._imp_call(orig, node)
            return node if r is None else r
        # layout calls on dynamically created widgets: they are appended in creation order, so the call is dropped
        if isinstance(f, cst.Attribute) and f.attr.value in ("pack", "grid", "place"):
            inner = f.value
            if isinstance(inner, cst.Call) and isinstance(orig.func.value, cst.Call) and \
                    RULES.get(tkname(self.p.q.get(orig.func.value.func, ())) or "", {}).get("kind") in ("widget", "container"):
                self._dyn_note(orig)
                return inner
            if isinstance(inner, cst.Name) and (inner.value in self.dyn or (
                    inner.value in self.kinds and self.kinds[inner.value] not in (None, "Placeholder"))):
                self._dyn_note(orig)
                return cst.parse_expression("None")
        n = tkname(self.p.q.get(orig.func, ()))
        if not n:
            r = self._unbound_star(orig, node)
            if r is not None:
                return r
        if n:
            if n in MSGBOX:
                a = [code_of(x.value) for x in node.args if not x.keyword]
                msg = a[1] if len(a) > 1 else (a[0] if a else '""')
                self.p.rep.add("approx", self.p.line(orig), f"{n} became a toast (it no longer waits for OK)")
                return cst.parse_expression(f"{self.win}.toast({msg})")
            if n == "mainloop":
                return cst.parse_expression(f"{self.win}.run()")
            if RULES.get(n, {}).get("kind") == "var":
                return self._var_expr(orig, node, n)
            if RULES.get(n, {}).get("kind") in ("widget", "container"):
                return self._dynamic_widget(orig, node, n)
            if n.endswith(".__init__"):
                return self._base_init(orig, node, n[:-len(".__init__")])
            if n in ("font.families", "font.nametofont", "font.names"):
                return node
            r = self._unbound(orig, node, n)
            if r is not None:
                return r
            return self._unsup(orig, f"tkinter.{n}(...)")
        if isinstance(f, cst.Attribute) and isinstance(f.value, cst.Name):
            obj, meth = f.value.value, f.attr.value
            if obj == self.win:
                if meth == "mainloop":
                    return cst.parse_expression(f"{obj}.run()")
                if meth in ("destroy", "quit"):
                    return cst.parse_expression(f"{obj}.quit()")
                if meth not in OK_WINDOW and not _real("Window", meth):
                    if meth in TK_ALL:
                        self.p.rep.add("approx", self.p.line(orig), f"{obj}.{meth}() is a tkinter method TK 4K does "
                                       "not have yet: it is skipped at run time")
                        return node
                    return self._unsup(orig, f"{obj}.{meth}(...)")
                return node
            kind = self.kinds.get(obj)
            if kind and kind != "Placeholder":
                if kind == "Entry" and meth == "get" and not node.args:
                    return cst.parse_expression(f"{obj}.text")
                if kind == "Slider" and meth == "get" and not node.args:
                    return cst.parse_expression(f"{obj}.value")
                if meth not in OK_METHODS.get(kind, COMMON_METHODS) and not _real(kind, meth):
                    if meth in TK_ALL:
                        self.p.rep.add("approx", self.p.line(orig), f"{obj}.{meth}() is a tkinter method TK 4K does "
                                       "not have yet: it is skipped at run time")
                        return node
                    return self._unsup(orig, f"{obj}.{meth}(...)")
        return node

    def leave_SimpleStatementLine(self, orig, node):
        if len(node.body) != 1:
            return node
        s = node.body[0]
        if isinstance(s, cst.Expr) and isinstance(s.value, cst.Call) and isinstance(s.value.func, cst.Attribute) \
                and isinstance(s.value.func.value, cst.Name):
            obj, meth, args = s.value.func.value.value, s.value.func.attr.value, s.value.args
            kind = self.kinds.get(obj)
            if kind == "Entry" and meth == "delete":
                return node.with_changes(body=[cst.parse_statement(f'{obj}.text = ""\n').body[0]])
            if kind == "Entry" and meth == "insert" and len(args) == 2:
                self.p.rep.add("approx", 0, f"{obj}.insert(...) became a full text assignment")
                return node.with_changes(body=[cst.parse_statement(f"{obj}.text = {code_of(args[1].value)}\n").body[0]])
            if kind == "Slider" and meth == "set" and args:
                return node.with_changes(body=[cst.parse_statement(f"{obj}.value = {code_of(args[0].value)}\n").body[0]])
            if kind and kind != "Placeholder" and meth in ("config", "configure"):
                outs = []
                for a in args:
                    if not a.keyword:
                        continue
                    k, v = a.keyword.value, code_of(a.value)
                    if k in ("text", "textvariable"):
                        outs.append(f"{obj}.text = {v}")
                    elif k == "state":
                        outs.append(f"{obj}.enabled = ({v}) != 'disabled'")
                    elif k == "command" and kind == "Button":
                        outs.append(f"{obj}.on_click = {v}")
                    elif k == "show" and kind == "Entry":
                        outs.append(f"{obj}.password = bool({v})")
                    elif k in ("onvalue", "offvalue") and kind == "Checkbox":
                        outs.append(f"{obj}.{k} = {v}")
                    elif k in COSMETIC:
                        self.p.rep.add("approx", 0, f"{obj}.config({k}=...) dropped (theme decides)")
                    else:
                        outs.append(f"ui.unsupported({obj + '.' + meth + '(' + k + '=...)'!r}, {self.p.line(orig)})")
                        self.p.rep.add("todo", self.p.line(orig), f"{obj}.{meth}({k}=...) is not supported yet")
                if not outs:
                    return cst.SimpleStatementLine(body=[cst.Pass()])
                if len(outs) == 1:
                    return node.with_changes(body=[cst.parse_statement(outs[0] + "\n").body[0]])
                return cst.FlattenSentinel([cst.parse_statement(o + "\n") for o in outs])
        if isinstance(s, cst.Assign) and len(s.targets) == 1 and isinstance(s.targets[0].target, cst.Subscript):
            sub = s.targets[0].target
            if isinstance(sub.value, cst.Name) and self.kinds.get(sub.value.value) not in (None, "Placeholder"):
                key = const_str(sub.slice[0].slice.value) if isinstance(sub.slice[0].slice, cst.Index) else None
                obj = sub.value.value
                if key == "value" and self.kinds[obj] == "Progress":
                    mx = self.p.maxima.get(obj, "100")
                    return node.with_changes(body=[cst.parse_statement(f"{obj}.value = ({code_of(s.value)}) / {mx}\n").body[0]])
                if key in ("text", "textvariable"):
                    return node.with_changes(body=[cst.parse_statement(f"{obj}.text = {code_of(s.value)}\n").body[0]])
                if key == "state":
                    return node.with_changes(body=[cst.parse_statement(
                        f"{obj}.enabled = ({code_of(s.value)}) != 'disabled'\n").body[0]])
                self.p.rep.add("todo", self.p.line(orig), f"{obj}[{key!r}] = ... is not supported yet")
                return node.with_changes(body=[cst.parse_statement(
                    f"ui.unsupported({obj + '[' + repr(key) + ']'!r}, {self.p.line(orig)})\n").body[0]])
        return node
