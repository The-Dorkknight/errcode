"""tk4k.port: translate tkinter apps into TK 4K apps, and say loudly what could not be done.

    python -m tk4k.port my_app.py            # writes my_app_tk4k.py + report + log (+ QR if something is wrong)
    python -m tk4k.port src/ --check         # grade every tkinter file in a folder, write nothing
    python -m tk4k.port src/ --jobs 2        # a folder, two worker processes (default 1; a bad file never stops the run)

    from tk4k.port import port_file
    result = port_file("my_app.py")
    result.grade, result.notes, result.payload

Nothing is silently dropped: unsupported widgets become placeholders, unsupported calls become
`ui.unsupported(...)`, and every problem goes to the log, the JSON report, stderr and a QR error report.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Optional

from .. import _alerts

__all__ = ["Result", "port_file", "port_source", "main_exit_code"]


def _grade(notes) -> str:
    levels = {n["level"] for n in notes}
    return "unsafe" if "todo" in levels else "review" if "approx" in levels else "safe"


@dataclass
class Result:
    source: str
    out_path: Optional[str] = None           # translated file (None if nothing was written)
    grade: str = "failed"                    # safe | review | unsafe | failed | skipped
    translated: int = 0
    notes: list = field(default_factory=list)  # [{"level": "todo"|"approx", "line": int, "msg": str}]
    error: Optional[str] = None              # set when the translator itself failed
    report_path: Optional[str] = None
    log_path: Optional[str] = None
    qr_path: Optional[str] = None
    payload: str = ""                        # the report as one short string (EC2-... with ErrCode, else TK4K1-...)
    seconds: float = 0.0

    @property
    def todo(self) -> int:
        return sum(n["level"] == "todo" for n in self.notes)

    @property
    def approximations(self) -> int:
        return sum(n["level"] == "approx" for n in self.notes)

    @property
    def predicted(self) -> list:
        """The anticipation pass's findings (see tk4k.port._anticipate)."""
        return [n for n in self.notes if n.get("anticipated")]

    def to_dict(self) -> dict:
        from .. import __version__
        return {"tk4k": __version__, "source": self.source, "grade": self.grade, "translated_items": self.translated,
                "todo": self.todo, "approximations": self.approximations, "error": self.error,
                "predicted": len(self.predicted),
                "notes": self.notes, "report": self.payload}


def main_exit_code(results) -> int:
    """0 = fine, 1 = something to look at (placeholders / unsupported), 2 = the translator failed."""
    grades = {r.grade for r in results}
    return 2 if "failed" in grades else 1 if "unsafe" in grades else 0


def _read_source(path: str) -> str:
    """Read a Python file the way Python does: BOM and `# coding:` cookie honoured, UTF-8 by default."""
    import tokenize
    with open(path, "rb") as f:
        enc, _ = tokenize.detect_encoding(f.readline)
        f.seek(0)
        return f.read().decode(enc)


def _short(msg: str) -> str:
    """'Spinbox is not in TK 4K yet: `people` replaced ...' -> 'Spinbox people' (short enough for a QR code)."""
    m = re.match(r"([\w.]+) is not in TK 4K yet: (?:`(\w+)`|anonymous widget)", msg)
    if m:
        return f"{m.group(1)} {m.group(2) or ''}".strip()
    m = re.match(r"(.*?) is not supported yet", msg)
    return (m.group(1) if m else msg)[:32]


def _payload(app: str, grade: str, extra: dict) -> str:
    ecr = _alerts.errcode_report()
    if ecr is not None and ecr.worst >= 1:
        return ecr.payload
    return _alerts.compact_payload(app, extra=extra)


# Python 2 module names -> Python 3, and Pillow's ImageTk -> TK 4K's stand-in (same line count: line numbers stay true)
_PY2 = [
    (r"^(\s*)import Tkinter as (\w+)\s*$", r"\1import tkinter as \2"),
    (r"^(\s*)import Tkinter\s*$", r"\1import tkinter as Tkinter"),
    (r"^(\s*)from Tkinter import ", r"\1from tkinter import "),
    (r"^(\s*)import ttk\s*$", r"\1from tkinter import ttk"),
    (r"^(\s*)from ttk import ", r"\1from tkinter.ttk import "),
    (r"^(\s*)import (tkMessageBox|tkFileDialog|tkSimpleDialog|tkColorChooser|tkFont|ScrolledText)(?: as (\w+))?\s*$", None),
    (r"^(\s*)from (tkMessageBox|tkFileDialog|tkSimpleDialog|tkColorChooser|tkFont|ScrolledText) import ", None),
]
_PY2_MOD = {"tkMessageBox": "messagebox", "tkFileDialog": "filedialog", "tkSimpleDialog": "simpledialog",
            "tkColorChooser": "colorchooser", "tkFont": "font", "ScrolledText": "scrolledtext"}


def normalize_imports(src: str):
    """-> (source, notes). Rewrites only import lines, one line for one line."""
    notes, out = [], []
    changed_py2 = False
    for i, line in enumerate(src.split("\n"), 1):
        new = line
        for pat, rep in _PY2:
            m = re.match(pat, line)
            if not m:
                continue
            if rep is not None:
                new = re.sub(pat, rep, line)
            elif " import " in pat[-10:] or pat.endswith("import "):
                new = f"{m.group(1)}from tkinter.{_PY2_MOD[m.group(2)]} import " + line[m.end():]
            else:
                new = f"{m.group(1)}from tkinter import {_PY2_MOD[m.group(2)]} as {m.group(3) or m.group(2)}"
            break
        if new != line:
            changed_py2 = True
        m = re.match(r"^(\s*)from PIL import (.*)$", new)
        if m and re.search(r"\bImageTk\b", m.group(2)) and "(" not in m.group(2):
            names = [x.strip() for x in m.group(2).split(",")]
            rest = [x for x in names if x.split(" as ")[0].strip() != "ImageTk"]
            itk = next(x for x in names if x.split(" as ")[0].strip() == "ImageTk")
            new = m.group(1) + (f"from PIL import {', '.join(rest)}; " if rest else "") + f"from tk4k import {itk}"
            notes.append({"level": "approx", "line": i, "code": "IMAGETK",
                          "msg": "PIL.ImageTk became tk4k.ImageTk (PhotoImage from a Pillow image; the rest of "
                                 "Pillow is unchanged)"})
        out.append(new)
    if changed_py2:
        notes.append({"level": "approx", "line": 0, "code": "PY2",
                      "msg": "Python 2 tkinter module names (Tkinter, tkMessageBox...) were updated to Python 3's"})
    return "\n".join(out), notes


def port_source(src: str, app: str = "app"):
    """Translate source text. Returns (code_or_None, Result without file info). Never raises."""
    res = Result(source=app)
    try:
        src, pre_notes = normalize_imports(src)
    except Exception:  # never let a helper stop the port
        pre_notes = []
    from ._prefilter import SKIP_NOTE, nothing_to_translate
    if nothing_to_translate(src):  # fast path: no LibCST at all for files with nothing to translate
        res.grade = "skipped"
        res.notes = [{"level": "todo", "line": 0, "msg": SKIP_NOTE}]
        return None, res
    try:
        from ._anticipate import anticipate, as_notes
        predicted = as_notes(anticipate(src))
    except Exception as e:  # pragma: no cover - the prediction is a bonus, never a reason to fail
        predicted = [{"level": "advice", "line": 0, "msg": f"anticipation skipped ({type(e).__name__}: {e})"}]
    from .engine import Porter
    try:
        p = Porter(src, app)
        out = p.run()
        res.notes = list(p.rep.notes) + pre_notes + predicted
        res.translated = p.rep.translated
        res.grade = _grade(res.notes) if out is not None else "skipped"
        if out is not None:
            try:
                compile(out, app, "exec")
            except SyntaxError as e:  # our own output must be valid, or we do not hand it over
                raise RuntimeError(f"generated code does not compile: {e}") from e
            out = (f"# Translated from {app}.py by tk4k.port. Grade: {res.grade}.\n"
                   "# Placeholders and ui.unsupported(...) calls mark what TK 4K cannot do yet; see the .report.json\n"
                   "# and the log. Running the program prints a summary (and a QR code) of anything skipped.\n") + out
        return out, res
    except Exception as e:  # a source we cannot read (SyntaxError), or a bug in the translator
        import libcst
        res.grade = "failed"
        if isinstance(e, libcst.ParserSyntaxError):
            res.error = f"SyntaxError: {getattr(e, 'message', None) or str(e).splitlines()[0]} (line {getattr(e, 'raw_line', '?')})"
        else:
            res.error = f"{type(e).__name__}: {e}"
        return None, res


def port_file(path: str, out: Optional[str] = None, *, write: bool = True, qr: Optional[bool] = None,
              stream=None) -> Result:
    """Translate one file. Writes `<name>_tk4k.py`, `.report.json`, `.port.log` and (when something is wrong and
    `segno` is installed) `.qr.png` next to it. `write=False` only grades. The original is never modified."""
    t0 = time.time()
    path = os.path.abspath(path)
    stem = os.path.splitext(os.path.basename(path))[0]
    out = os.path.abspath(out) if out else os.path.join(os.path.dirname(path), stem + "_tk4k.py")
    base = os.path.splitext(out)[0]
    log_path = base + ".port.log"
    log = logging.getLogger("tk4k.port")
    log.setLevel(logging.DEBUG)
    fh = None
    _alerts.reset()
    _alerts.use_errcode(stem)
    if write:
        try:
            fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
            fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%H:%M:%S"))
            log.addHandler(fh)
        except OSError:
            log_path = None
    try:
        log.info("porting %s -> %s", path, out)
        try:
            src = _read_source(path)
        except (OSError, UnicodeDecodeError, SyntaxError, LookupError) as e:
            code, res = None, Result(source=path, grade="failed", error=f"{type(e).__name__}: {e}")
        else:
            code, res = port_source(src, stem)
        res.source = path
        for n in res.notes:
            (log.warning if n["level"] == "todo" else log.info)("%s line %s: %s", n["level"], n["line"] or "?", n["msg"])
            if n["level"] == "todo":
                _alerts.note("todo", _short(n["msg"]), n["line"])
        if res.error:
            kind = "parse" if res.error.startswith(("SyntaxError", "UnicodeDecodeError", "OSError", "FileNotFoundError")) else "crash"
            _alerts.note(kind, res.error[:80])
            log.error("%s", res.error)
        res.payload = _payload(stem, res.grade, {"grade": res.grade, "todo": res.todo, "approx": res.approximations})
        if write and code is not None:
            tmp = out + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(code)
            os.replace(tmp, out)
            res.out_path = out
        if write:
            res.report_path = base + ".report.json"
            with open(res.report_path, "w", encoding="utf-8") as f:
                json.dump(res.to_dict(), f, indent=1)
            res.log_path = log_path
            wanted = qr if qr is not None else res.grade in ("unsafe", "failed")
            if wanted and _alerts.qr_available():
                res.qr_path = base + ".qr.png"
                _alerts.qr_save(res.payload, res.qr_path)
        res.seconds = time.time() - t0
        log.info("grade %s, %d translated, %d todo, %d approximations, %.2fs", res.grade, res.translated,
                 res.todo, res.approximations, res.seconds)
        return res
    finally:
        if fh is not None:
            log.removeHandler(fh)
            fh.close()
