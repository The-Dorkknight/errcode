"""A fast "nothing to translate here" check, before the expensive LibCST analysis.

Many files mention tkinter (they import it for a type, a constant, or a helper) but create no window or
widget. Finding that out with LibCST's full name resolution was 41 % of a corpus run. Python's own `ast`
parser (written in C) answers the conservative question much faster:

    Does anything in this file, other than the import lines, refer to a tkinter name?

Only when the answer is a clear "no" is the file skipped here, with the same note the full porter would write.
Any doubt (a reference, a syntax `ast` cannot read, `__import__`/`importlib`) sends the file to the full porter.
"""
from __future__ import annotations

import ast
from typing import Optional

from ._names import STAR

SKIP_NOTE = ("no tkinter Tk() window found at module level; nothing translated "
             "(try python -m tk4k.classic for the skin only)")
_TK_MODULES = ("tkinter", "Tkinter", "tkMessageBox", "tkFileDialog", "tkSimpleDialog", "tkFont", "ttk",
               "ScrolledText", "tkColorChooser", "tkCommonDialog", "Tix", "tix")


_SUBMODULES = {"ttk", "messagebox", "filedialog", "simpledialog", "font", "constants", "scrolledtext", "colorchooser",
               "dnd", "tix", "commondialog", "dialog"}


def _is_tk(mod: Optional[str]) -> bool:
    return bool(mod) and mod.split(".")[0] in _TK_MODULES


def nothing_to_translate(src: str) -> bool:
    """True only when no code outside the import lines refers to tkinter. False whenever unsure."""
    if "__import__" in src or "importlib" in src:
        return False
    try:
        tree = ast.parse(src)
    except (SyntaxError, ValueError, MemoryError, RecursionError):
        return False  # let the full porter read it and report properly
    names: set[str] = set()   # local names bound to tkinter modules or tkinter objects
    modules: set[str] = set()  # the subset that are modules (tk, ttk, messagebox): judged by what follows the dot
    star = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if _is_tk(a.name):
                    n = (a.asname or a.name).split(".")[0]
                    names.add(n)
                    modules.add(n)
        elif isinstance(node, ast.ImportFrom):
            if _is_tk(node.module):
                for a in node.names:
                    if a.name == "*":
                        star = True
                    else:
                        names.add(a.asname or a.name)
                        if f"{node.module}.{a.name}" in STAR or a.name in _SUBMODULES:
                            modules.add(a.asname or a.name)
    if not names and not star:
        return True  # tkinter appears only in strings or comments
    star_names: frozenset = frozenset()
    if star:
        star_names = frozenset().union(*STAR.values())
    def root_and_last(e):
        """tk.ttk.Button -> ('tk', 'Button'); returns (None, None) if not a plain name chain."""
        last = None
        while isinstance(e, ast.Attribute):
            last = last or e.attr
            e = e.value
        if isinstance(e, ast.Name):
            return e.id, last or e.id
        return None, None

    # type hints (e: tk.Event, -> tk.Widget) do not need translating
    hints: set[int] = set()
    for node in ast.walk(tree):
        anns = []
        if isinstance(node, ast.arg) and node.annotation is not None:
            anns.append(node.annotation)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.returns is not None:
            anns.append(node.returns)
        elif isinstance(node, ast.AnnAssign):
            anns.append(node.annotation)
        for a in anns:
            hints.update(id(x) for x in ast.walk(a))

    for node in ast.walk(tree):
        if id(node) in hints or not isinstance(node, (ast.Name, ast.Attribute)):
            continue
        root, last = root_and_last(node)
        if root is None or not (root in names or root in star_names):
            continue
        if isinstance(node, ast.Name) and root in modules:
            continue  # the module name inside tk.END: its attribute chain is judged instead
        if last.isupper() or last.lstrip("_").isupper():
            continue  # a constant: tk.END, W, NSEW
        return False  # Tk, Button, messagebox.showinfo, a class used as a base or stored to call later
    return True  # only constants and type hints: nothing to translate
