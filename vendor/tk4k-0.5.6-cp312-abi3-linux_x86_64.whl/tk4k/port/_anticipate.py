"""Anticipate porting problems before anything runs.

The porter translates; this module *predicts*. It reads the original program with Python's own `ast` parser
(milliseconds, no LibCST), works out which names hold which tkinter widgets (`self.text = tk.Text(...)`,
`class App(tk.Frame)`, `root = Tk()`), and checks every call against what TK 4K really has. Each finding has a
stable code, the original line numbers and a hint:

  todo    will not work in TK 4K (needs the Tcl interpreter: run it with tk4k.classic)
  approx  runs, but differs from tkinter (a method TK 4K lacks is skipped; place() is not used for layout...)
  advice  a common tkinter mistake that misbehaves in tkinter too (`x = Label(...).pack()` makes x None,
          time.sleep() in a button handler freezes the window, widgets touched from a thread)

Findings are grouped (one line per kind and method, with a count), so a 2,000-line program gets a readable list.
The knowledge comes from the same tables the run time uses (tk4k._tkapi and the TK 4K classes), so the prediction
and the program's behaviour cannot drift apart.
"""
from __future__ import annotations

import ast
from typing import Optional

from .._tkapi import COMMON, TK_METHODS

# tkinter class (short name, ttk prefix dropped unless the ttk class differs) -> TK 4K class that stands in for it
CLASS_TO_UI = {
    "Tk": "Window", "Toplevel": "Toplevel", "Frame": "Frame", "LabelFrame": "Frame", "Label": "Label",
    "Message": "Label", "Button": "Button", "Entry": "Entry", "Text": "TextArea", "ScrolledText": "TextArea",
    "Canvas": "Canvas", "Listbox": "Listbox", "Scale": "Slider", "Scrollbar": "Scrollbar", "Menu": "Menu",
    "Spinbox": "Spinbox", "Checkbutton": "Checkbox", "Radiobutton": "Radio", "Treeview": "Tree", "Notebook": "Tabs",
    "Combobox": "Dropdown", "Progressbar": "Progress", "Style": "Style", "PhotoImage": "PhotoImage",
    "PanedWindow": "Row", "Panedwindow": "Row", "OptionMenu": "Dropdown", "Menubutton": "Button",
    "Separator": "Separator", "Sizegrip": "Spacer", "LabeledScale": "Placeholder",
    "StringVar": "Var", "IntVar": "Var", "DoubleVar": "Var", "BooleanVar": "Var", "Variable": "Var",
}
# the key in _tkapi.TK_METHODS for each short name
API_KEY = {"Treeview": "ttk.Treeview", "Notebook": "ttk.Notebook", "Combobox": "ttk.Combobox",
           "Progressbar": "ttk.Progressbar", "Style": "ttk.Style", "Panedwindow": "ttk.Panedwindow",
           "StringVar": "Variable", "IntVar": "Variable", "DoubleVar": "Variable", "BooleanVar": "Variable"}
NOT_WIDGETS = {"Menu", "Style", "PhotoImage", "Var"}   # no pack/grid/winfo: only their own methods
TK_MODULE_NAMES = {"tkinter", "Tkinter"}
TTK_MODULE_NAMES = {"tkinter.ttk", "ttk"}
# Method names that are ordinary Python words: on an object of unknown type they are not evidence of tkinter
GENERIC_WORDS = {"info", "replace", "remove", "write", "find", "count", "debug", "command", "group", "scale", "insert",
                 "delete", "index", "get", "set", "add", "copy", "type", "select", "identify", "size", "keys",
                 "update", "config", "configure", "destroy", "quit", "focus", "state", "move", "forget", "invoke",
                 "post", "frame", "client", "location", "anchor", "bbox", "coords", "lower", "lift", "dump", "edit",
                 "compare", "activate", "delta", "fraction", "deselect", "toggle", "flash", "start", "stop", "step",
                 "clear", "item", "column", "heading", "next", "prev", "parent", "exists", "detach", "see", "tag",
                 "image", "scan", "proxy", "send", "selection", "mainloop", "cget", "bind", "unbind", "after",
                 "transient", "aspect", "positionfrom", "sizefrom", "manage", "iconname", "propagate", "slaves",
                 "unpost", "entrycget", "theme_create", "theme_settings"}
# 'advice' must not hide real trouble: methods a thread may call safely in TK 4K (Var.set wakes the window)
THREAD_SAFE = {"after", "after_idle", "post", "event_generate", "set", "get", "put", "put_nowait", "append"}

_ui_cache: dict = {}


def _ui_has(ui_cls: str, meth: str) -> bool:
    """Does TK 4K's class really define `meth` (not just the run-time safety net)?"""
    key = (ui_cls, meth)
    if key not in _ui_cache:
        try:
            import tk4k
            from tk4k import _widgets, _widgets2
            c = getattr(tk4k, ui_cls, None) or getattr(_widgets, ui_cls, None) or getattr(_widgets2, ui_cls, None)
        except Exception:  # pragma: no cover - the porter always runs with tk4k importable
            c = None
        _ui_cache[key] = c is None or any(meth in k.__dict__ for k in c.__mro__ if k is not object)
    return _ui_cache[key]


def _ui_func(ui_cls: str, meth: str):
    """The function TK 4K runs for ui_cls.meth (None for properties, the safety net, or unknown classes)."""
    try:
        import tk4k
        from tk4k import _widgets, _widgets2
        c = getattr(tk4k, ui_cls, None) or getattr(_widgets, ui_cls, None) or getattr(_widgets2, ui_cls, None)
        for k in (c.__mro__ if isinstance(c, type) else ()):
            if meth in k.__dict__:
                v = k.__dict__[meth]
                return v if callable(v) and not isinstance(v, type) else None
    except Exception:  # pragma: no cover
        return None
    return None


def tk_api(short: str) -> set:
    """The method names real tkinter gives a widget of class `short`."""
    own = set(TK_METHODS.get(API_KEY.get(short, short), ()))
    if CLASS_TO_UI.get(short) in NOT_WIDGETS:
        return own
    base = set(COMMON)
    if short in ("Tk", "Toplevel"):
        base |= set(TK_METHODS["Wm"])
    if short == "ScrolledText":
        own |= set(TK_METHODS["Text"])
    return own | base


def _supported_binding(seq: str, cls: Optional[str]) -> bool:
    from .._widgets import _GENERIC, _is_key_seq
    s = str(seq)
    if not s.startswith("<"):   # not a tkinter event sequence: a program's own bind() method (Thonny has one)
        return True
    if s.startswith("<<") or s in _GENERIC or _is_key_seq(s):
        return True
    if cls in ("Canvas", "Treeview") and s in ("<B1-Motion>", "<Double-1>", "<Double-Button-1>"):
        return True
    return False


class _Finder(ast.NodeVisitor):
    def __init__(self, tree: ast.Module):
        self.tree = tree
        self.tk_mods: set[str] = set()       # local names of the tkinter module
        self.ttk_mods: set[str] = set()      # local names of tkinter.ttk
        self.sub_mods: dict[str, str] = {}   # local name -> 'scrolledtext' / 'messagebox' / 'font' / ...
        self.direct: dict[str, str] = {}     # from tkinter import Text as T  ->  {'T': 'Text'}
        self.star_tk = self.star_ttk = False
        self.user_cls: dict[str, str] = {}   # class App(tk.Frame) -> {'App': 'Frame'}
        self.types: dict[str, str] = {}      # 'root' / '@text' (self.text) -> tkinter short class name
        self.funcs: dict[str, ast.AST] = {}  # def name -> node (for thread targets and callbacks)
        self.out: list[dict] = []
        self.counts = {"Tk": 0, "mainloop": 0, "update": 0}

    # ---------------------------------------------------------------- what is what
    def collect(self) -> None:
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    local = a.asname or a.name.split(".")[0]
                    if a.name in TK_MODULE_NAMES and (a.asname or "." not in a.name):
                        self.tk_mods.add(local)
                    elif a.name in TTK_MODULE_NAMES and a.asname:
                        self.ttk_mods.add(local)
                    elif a.name == "ttk":
                        self.ttk_mods.add("ttk")
                    elif a.name.startswith("tkinter.") and a.asname:
                        self.sub_mods[local] = a.name.split(".", 1)[1]
                    elif a.name.startswith("tkinter."):
                        self.tk_mods.add("tkinter")
            elif isinstance(node, ast.ImportFrom) and node.module:
                m = node.module
                for a in node.names:
                    local = a.asname or a.name
                    if m in TK_MODULE_NAMES:
                        if a.name == "*":
                            self.star_tk = True
                        elif a.name == "ttk":
                            self.ttk_mods.add(local)
                        elif a.name[:1].islower():
                            self.sub_mods[local] = a.name
                        else:
                            self.direct[local] = a.name
                    elif m in TTK_MODULE_NAMES:
                        if a.name == "*":
                            self.star_ttk = True
                        else:
                            self.direct[local] = a.name
                    elif m == "tkinter.scrolledtext":
                        self.direct[local] = a.name
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.funcs.setdefault(node.name, node)
        # user classes, in source order, so class B(A) after class A(tk.Frame) resolves
        for node in ast.walk(self.tree):
            if isinstance(node, ast.ClassDef):
                for b in node.bases:
                    t = self.tk_class(b) or self.user_cls.get(getattr(b, "id", ""))
                    if t:
                        self.user_cls[node.name] = t
                        break

    def tk_class(self, e: ast.AST) -> Optional[str]:
        """tk.Text / ttk.Treeview / Text (star or direct import) / scrolledtext.ScrolledText -> short class name."""
        if isinstance(e, ast.Attribute) and isinstance(e.value, ast.Name):
            mod, name = e.value.id, e.attr
            if mod in self.tk_mods or mod in self.ttk_mods:
                return name if name in CLASS_TO_UI else None
            if self.sub_mods.get(mod) == "scrolledtext" and name == "ScrolledText":
                return "ScrolledText"
            return None
        if isinstance(e, ast.Attribute) and isinstance(e.value, ast.Attribute):   # tkinter.ttk.Button
            if isinstance(e.value.value, ast.Name) and e.value.value.id in self.tk_mods and e.value.attr == "ttk":
                return e.attr if e.attr in CLASS_TO_UI else None
        if isinstance(e, ast.Name):
            if e.id in self.direct:
                return self.direct[e.id] if self.direct[e.id] in CLASS_TO_UI else None
            if (self.star_tk or self.star_ttk) and e.id in CLASS_TO_UI:
                return e.id
        return None

    def ctor_type(self, call: ast.AST) -> Optional[str]:
        if not isinstance(call, ast.Call):
            return None
        t = self.tk_class(call.func)
        if t:
            return t
        if isinstance(call.func, ast.Name) and call.func.id in self.user_cls:
            return self.user_cls[call.func.id]
        return None

    @staticmethod
    def key_of(e: ast.AST) -> Optional[str]:
        if isinstance(e, ast.Name):
            return e.id
        if isinstance(e, ast.Attribute) and isinstance(e.value, ast.Name) and e.value.id == "self":
            return "@" + e.attr
        return None

    def assign_types(self) -> None:
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                t = self.ctor_type(node.value)
                for tgt in node.targets:
                    k = self.key_of(tgt)
                    if k and t:
                        self.types.setdefault(k, t)
                # x = Label(...).pack()  -> x is None (in tkinter too)
                v = node.value
                if isinstance(v, ast.Call) and isinstance(v.func, ast.Attribute) and \
                        v.func.attr in ("pack", "grid", "place") and self.ctor_type(v.func.value):
                    k = self.key_of(node.targets[0]) if len(node.targets) == 1 else None
                    if k and self._used_later(k, node.lineno):
                        self.add("advice", "NONE-CHAIN", node.lineno,
                                 f"`{k.lstrip('@')} = {self.ctor_type(v.func.value)}(...).{v.func.attr}(...)` stores None "
                                 f"(.{v.func.attr}() returns None, in tkinter too)",
                                 f"create the widget on one line and call .{v.func.attr}() on the next")

    def _used_later(self, key: str, line: int) -> bool:
        """Is `key` (a name, or '@attr' for self.attr) read as an object later on? Only then is the None a problem."""
        if not hasattr(self, "_reads"):
            self._reads = {}
            for n in ast.walk(self.tree):
                if isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Load):
                    k = self.key_of(n.value)
                    if k:
                        self._reads.setdefault(k, []).append(n.lineno)
                elif isinstance(n, ast.Subscript):
                    k = self.key_of(n.value)
                    if k:
                        self._reads.setdefault(k, []).append(n.lineno)
        return any(ln >= line for ln in self._reads.get(key, ()))

    def type_in(self, e: ast.AST, cls_ctx: Optional[str]) -> Optional[str]:
        if isinstance(e, ast.Name) and e.id == "self" and cls_ctx:
            return self.user_cls.get(cls_ctx)
        if isinstance(e, ast.Call):
            return self.ctor_type(e)
        k = self.key_of(e)
        return self.types.get(k) if k else None

    # ---------------------------------------------------------------- findings
    def add(self, level: str, code: str, line: int, msg: str, hint: str, key: Optional[str] = None) -> None:
        self.out.append({"level": level, "code": code, "line": int(line or 0), "msg": msg, "hint": hint,
                         "key": key or f"{code}:{msg}"})

    def scan(self) -> None:
        self._walk(self.tree, None, None)
        self._whole_program()

    def _walk(self, node: ast.AST, cls_ctx: Optional[str], fn_ctx: Optional[str]) -> None:
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.ClassDef):
                self._walk(child, child.name, fn_ctx)
                continue
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._walk(child, cls_ctx, child.name)
                continue
            if isinstance(child, ast.Call):
                self._call(child, cls_ctx, fn_ctx)
            self._walk(child, cls_ctx, fn_ctx)

    def _parent_is_expr(self, call: ast.Call) -> bool:
        return id(call) in self._expr_calls

    def _call(self, call: ast.Call, cls_ctx: Optional[str], fn_ctx: Optional[str]) -> None:
        f = call.func
        ln = call.lineno
        t = self.ctor_type(call)
        if t:
            self._ctor(call, t)
        if isinstance(f, ast.Name) and f.id == "mainloop":
            self.counts["mainloop"] += 1      # from tkinter import *  ...  mainloop()
        if isinstance(f, ast.Name) and f.id == "Tcl" and (self.star_tk or "Tcl" in self.direct):
            self.add("todo", "TCL", ln, "Tcl() starts a bare Tcl interpreter", "run with python -m tk4k.classic")
        if not isinstance(f, ast.Attribute):
            return
        meth = f.attr
        # widget.tk.call(...) / root.tk.eval(...)
        if isinstance(f.value, ast.Attribute) and f.value.attr == "tk" and meth in (
                "call", "eval", "createcommand", "splitlist", "globalsetvar", "globalgetvar", "setvar", "getvar",
                "deletecommand", "createfilehandler", "dooneevent", "willdispatch", "split", "exprstring"):
            self.add("todo", "TCL", ln, f".tk.{meth}(...) talks to Tcl directly; TK 4K has no Tcl interpreter",
                     "run this program with python -m tk4k.classic, or replace the Tcl command with Python",
                     key=f"TCL:{meth}")
            return
        if meth == "mainloop":
            self.counts["mainloop"] += 1
        elif meth in ("update", "wait_window", "wait_variable"):
            self.counts["update"] += 1
        recv_t = self.type_in(f.value, cls_ctx)
        if meth == "place" and (recv_t or call.keywords):
            if any(k.arg in ("x", "y", "relx", "rely") for k in call.keywords):
                self.add("approx", "PLACE", ln, "place() positions are not used: the widget joins the layout in order",
                         "use pack() or grid() for this widget if its position matters", key="PLACE")
        if meth in ("bind", "bind_all", "bind_class", "tag_bind") and call.args:
            seq_arg = call.args[1] if meth in ("bind_class", "tag_bind") and len(call.args) > 1 else call.args[0]
            if isinstance(seq_arg, ast.Constant) and isinstance(seq_arg.value, str):
                if not _supported_binding(seq_arg.value, recv_t):
                    self.add("approx", "BIND", ln, f"the binding {seq_arg.value} never fires in TK 4K",
                             "keys, <<virtual>> events, <Button-1/2/3>, <Double-1>, <Enter>, <Leave>, <Motion>, "
                             "<MouseWheel> and <Configure> work", key=f"BIND:{seq_arg.value}")
        if meth == "event_generate" and call.args and isinstance(call.args[0], ast.Constant) and \
                isinstance(call.args[0].value, str) and not call.args[0].value.startswith("<<"):
            self.add("approx", "EVENT-GEN", ln, f"event_generate({call.args[0].value!r}) is not delivered "
                     "(only <<virtual>> events are)", "call the handler function directly", key="EVENT-GEN")
        if meth == "overrideredirect":
            self.add("approx", "OVERRIDE", ln, "overrideredirect(): the window keeps its title bar",
                     "fine for most programs; a splash screen will show a normal window", key="OVERRIDE")
        if meth == "window_create" and recv_t in (None, "Text", "ScrolledText"):
            self.add("approx", "TEXT-WINDOW", ln, "Text.window_create: the embedded widget is not drawn inside the text",
                     "put the widget next to the Text instead", key="TEXT-WINDOW")
        if meth in ("create_line", "create_polygon") and any(k.arg == "smooth" for k in call.keywords):
            self.add("approx", "SMOOTH", ln, "smooth= curves are drawn as straight segments", "", key="SMOOTH")
        if meth in ("configure", "map", "theme_use", "theme_create", "layout", "element_create") and \
                (recv_t == "Style" or (isinstance(f.value, ast.Call) and self.ctor_type(f.value) == "Style")):
            self.add("approx", "STYLE", ln, "ttk.Style settings are ignored: the TK 4K theme decides the look",
                     "use win.set_theme('dark'|'light'), or tk4k.classic to keep ttk styles", key="STYLE")
        if meth in ("Thread",) or (isinstance(f.value, ast.Name) and f.value.id == "threading" and meth == "Thread"):
            self._thread(call, cls_ctx)
        # a tkinter method TK 4K does not have
        self._api(call, meth, recv_t, ln)

    def _signature(self, call: ast.Call, meth: str, recv_t: str, ln: int) -> None:
        """TK 4K has the method: would these arguments fit its signature? (resizable(width=False) did not.)"""
        if any(isinstance(a, ast.Starred) for a in call.args) or any(k.arg is None for k in call.keywords):
            return
        fn = _ui_func(CLASS_TO_UI.get(recv_t, ""), meth)
        if fn is None:
            return
        import inspect
        try:
            sig = inspect.signature(fn)
        except (TypeError, ValueError):
            return
        try:
            sig.bind(None, *([0] * len(call.args)), **{k.arg: 0 for k in call.keywords})
        except TypeError as e:
            self.add("todo", "SIGNATURE", ln, f"{recv_t}.{meth}() is called in a way TK 4K's version does not accept "
                     f"({e})", "please report this: TK 4K should accept every call tkinter accepts",
                     key=f"SIG:{recv_t}.{meth}")

    def _api(self, call: ast.Call, meth: str, recv_t: Optional[str], ln: int) -> None:
        if meth.startswith("_"):
            return
        used = not self._parent_is_expr(call)
        if recv_t:
            ui = CLASS_TO_UI.get(recv_t)
            if ui and ui != "Placeholder" and meth in tk_api(recv_t) and _ui_has(ui, meth):
                self._signature(call, meth, recv_t, ln)
                return
            if not ui or ui == "Placeholder" or meth not in tk_api(recv_t) or _ui_has(ui, meth):
                return
            what = f"{recv_t}.{meth}()"
            sure = True
        else:
            # unknown receiver: only names no ordinary Python object has, and that no TK 4K class implements
            if meth in GENERIC_WORDS or not any(meth in v for v in TK_METHODS.values()) or self._any_ui_has(meth):
                return
            what = f".{meth}()"
            sure = False
        self.add("approx", "API-VALUE" if used else "API-MISSING", ln,
                 f"{what} is a tkinter method TK 4K does not have yet: the call is skipped"
                 + (" and returns a stand-in value" if used else "") + ("" if sure else " (if this is a tkinter widget)"),
                 "the program keeps running; check that part of the window, or run with tk4k.classic",
                 key=f"API:{what}")

    @staticmethod
    def _any_ui_has(meth: str) -> bool:
        return any(_ui_has(u, meth) for u in set(CLASS_TO_UI.values()) if u != "Placeholder")

    def _ctor(self, call: ast.Call, t: str) -> None:
        kw = {k.arg: k.value for k in call.keywords if k.arg}
        ln = call.lineno
        if t == "Tk":
            self.counts["Tk"] += 1
        if "font" in kw and t not in ("Style",):
            self.add("approx", "FONT", ln, "font= is recorded but the theme font is drawn",
                     "TK 4K draws every widget in one theme font", key="FONT")
        if t in ("Label", "Frame", "LabelFrame", "Button", "Checkbutton", "Radiobutton", "Message") and \
                ({"bg", "background", "activebackground"} & set(kw)):
            self.add("approx", "COLOUR", ln, "background colours of labels, frames and buttons are not drawn",
                     "the theme decides; Canvas and Text tag colours are drawn", key="COLOUR")
        if t in ("Radiobutton", "Checkbutton") and "indicatoron" in kw:
            self.add("approx", "INDICATOR", ln, "indicatoron=0 (push-button look) is drawn as a normal box/circle", "",
                     key="INDICATOR")
        if t == "Scale" and ({"tickinterval", "label", "showvalue"} & set(kw) or (
                "orient" in kw and "vert" in ast.unparse(kw["orient"]).lower())):
            self.add("approx", "SCALE", ln, "Scale: vertical orientation, ticks and labels are drawn as a plain slider", "",
                     key="SCALE")
        if t == "Canvas" and "scrollregion" in kw:
            self.add("approx", "SCROLLREGION", ln, "a Canvas scrollregion only scrolls widgets placed with "
                     "create_window; drawn items stay in place", "", key="SCROLLREGION")

    def _thread(self, call: ast.Call, cls_ctx: Optional[str]) -> None:
        tgt = next((k.value for k in call.keywords if k.arg == "target"), None)
        name = tgt.attr if isinstance(tgt, ast.Attribute) else tgt.id if isinstance(tgt, ast.Name) else None
        fn = self.funcs.get(name or "")
        if fn is None:
            return
        for sub in ast.walk(fn):
            if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Attribute):
                rt = self.type_in(sub.func.value, cls_ctx)
                if rt and CLASS_TO_UI.get(rt) not in ("Var",) and sub.func.attr not in THREAD_SAFE:
                    self.add("advice", "THREAD", sub.lineno,
                             f"`{name}` runs in a thread and calls {rt}.{sub.func.attr}(): widgets must only be "
                             "touched from the main thread (in tkinter too)",
                             "have the thread set a Var or call root.after(0, fn) / win.post(fn)", key=f"THREAD:{name}")
                    return

    def _callbacks(self) -> set:
        """Names of functions used as command= or bind(...) callbacks."""
        names = set()
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                vals = [k.value for k in node.keywords if k.arg == "command"]
                if isinstance(node.func, ast.Attribute) and node.func.attr in ("bind", "bind_all") and len(node.args) > 1:
                    vals.append(node.args[1])
                for v in vals:
                    n = v.attr if isinstance(v, ast.Attribute) else v.id if isinstance(v, ast.Name) else None
                    if n:
                        names.add(n)
        return names

    def _whole_program(self) -> None:
        for name in self._callbacks():
            fn = self.funcs.get(name)
            if fn is None:
                continue
            for sub in ast.walk(fn):
                if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Attribute) and sub.func.attr == "sleep" and \
                        isinstance(sub.func.value, ast.Name) and sub.func.value.id == "time":
                    self.add("advice", "SLEEP", sub.lineno, f"time.sleep() in the callback `{name}` freezes the window "
                             "while it sleeps (in tkinter too)", "schedule the next step with root.after(ms, fn)",
                             key=f"SLEEP:{name}")
                    break
        if self.counts["Tk"] > 1:
            self.add("advice", "MULTI-TK", 0, f"{self.counts['Tk']} Tk() windows are created; tkinter itself "
                     "recommends one Tk() and Toplevel() for the others", "use Toplevel for extra windows",
                     key="MULTI-TK")
        if self.counts["Tk"] and not self.counts["mainloop"] and not self.counts["update"]:
            self.add("advice", "NO-MAINLOOP", 0, "Tk() is created but mainloop() is never called: the window closes "
                     "at once (it only stays open inside IDLE)", "end the program with root.mainloop()",
                     key="NO-MAINLOOP")


def anticipate(src: str) -> list[dict]:
    """Predicted problems for one program, grouped: [{level, code, line, lines, count, msg, hint}]."""
    try:
        tree = ast.parse(src)
    except (SyntaxError, ValueError, MemoryError, RecursionError):
        return []
    f = _Finder(tree)
    f._expr_calls = {id(n.value) for n in ast.walk(tree) if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)}
    f.collect()
    if not (f.tk_mods or f.ttk_mods or f.direct or f.star_tk or f.star_ttk or f.sub_mods):
        return []
    f.assign_types()
    f.scan()
    grouped: dict[str, dict] = {}
    for n in f.out:
        g = grouped.get(n["key"])
        if g is None:
            grouped[n["key"]] = dict(n, lines=[n["line"]] if n["line"] else [], count=1)
        else:
            g["count"] += 1
            if n["line"] and n["line"] not in g["lines"]:
                g["lines"].append(n["line"])
    out = []
    for g in grouped.values():
        g.pop("key", None)
        g["lines"] = sorted(g["lines"])
        g["line"] = g["lines"][0] if g["lines"] else 0
        out.append(g)
    order = {"todo": 0, "approx": 1, "advice": 2}
    out.sort(key=lambda g: (order[g["level"]], g["line"]))
    return out


def as_notes(found: list[dict]) -> list[dict]:
    """Report notes (level, line, msg) for the porter's report; counts and extra lines go into the message."""
    notes = []
    for g in found:
        more = f" ({g['count']} places, lines {', '.join(map(str, g['lines'][:6]))}{'...' if len(g['lines']) > 6 else ''})" \
            if g["count"] > 1 else ""
        notes.append({"level": g["level"], "line": g["line"], "code": g["code"], "anticipated": True,
                      "msg": f"anticipated: {g['msg']}{more}" + (f". Hint: {g['hint']}" if g["hint"] else "")})
    return notes


# ------------------------------------------------------------------------------------------- name clashes
_TK_INSTANCE = {"master", "tk", "children", "widgetName"}   # attributes tkinter widgets have besides methods
_reserved_cache: dict = {}


def reserved_names(short: str) -> frozenset:
    """Public names a TK 4K stand-in for tkinter class `short` uses that the tkinter class does not have.

    A tkinter subclass that assigns or defines one of these (`self.text = tk.Text(self)` in a Frame subclass,
    `self.error = ...` in a Tk subclass, `def show(self)` in a Treeview subclass) would change TK 4K's own state,
    so the porter renames them inside that class (`self.text` -> `self.text_`)."""
    if short in _reserved_cache:
        return _reserved_cache[short]
    ui_name = CLASS_TO_UI.get(short)
    names: set = set()
    try:
        import tk4k
        from tk4k import _widgets, _widgets2
        c = getattr(tk4k, ui_name or "", None) or getattr(_widgets, ui_name or "", None) or \
            getattr(_widgets2, ui_name or "", None)
        if isinstance(c, type) and ui_name not in NOT_WIDGETS:
            used = _internal_self_names()
            for k in c.__mro__:
                if k is not object:
                    names |= {n for n, v in vars(k).items() if not n.startswith("_")
                              and (isinstance(v, property) or n in used)}
            names |= _INSTANCE_ATTRS.get(ui_name, set()) | _INSTANCE_ATTRS["*"]
    except Exception:  # pragma: no cover
        pass
    out = frozenset(names - tk_api(short) - _TK_INSTANCE)
    _reserved_cache[short] = out
    return out


_self_names: set = set()


def _internal_self_names() -> set:
    """Public names TK 4K's own code reads, writes or calls on `self` (only these can be hijacked by a subclass)."""
    if not _self_names:
        import inspect
        from tk4k import _dialogs, _image, _widgets, _widgets2, _window
        for m in (_widgets, _widgets2, _window, _dialogs, _image):
            for n in ast.walk(ast.parse(inspect.getsource(m))):
                if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in ("self", "s") \
                        and not n.attr.startswith("_"):
                    _self_names.add(n.attr)
    return _self_names


# set in __init__ by TK 4K (not visible on the class); kept by hand, checked by tests/test_anticipate.py
_INSTANCE_ATTRS = {
    "*": {"hovered", "width"},
    "Window": {"error", "gap", "indent", "menubar", "min_size", "pad", "strict", "theme"},
    "Frame": {"gap", "indent", "text"}, "Toplevel": {"gap", "indent", "on_close", "title_text"},
    "Canvas": {"bg", "ch", "cw"}, "Label": {"color", "dim", "image", "text", "wrap"},
    "Button": {"clicks", "height", "image", "on_click", "primary", "text"},
    "Entry": {"hint", "on_change", "on_submit", "password", "readonly", "var"},
    "TextArea": {"height", "on_change", "readonly", "var", "wrap"},
    "Listbox": {"items", "on_select", "rows", "sel", "selectmode"},
    "Tree": {"cols", "heads", "height", "on_select", "sel", "selectmode", "show"},
}


def class_renames(src: str) -> dict:
    """{class name: {attr names to rename}} for tkinter subclasses that assign/define TK 4K-reserved names."""
    try:
        tree = ast.parse(src)
    except (SyntaxError, ValueError, MemoryError, RecursionError):
        return {}
    f = _Finder(tree)
    f.collect()
    out: dict = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef) or node.name not in f.user_cls:
            continue
        res = reserved_names(f.user_cls[node.name])
        hit = set()
        for sub in ast.walk(node):
            if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)) and sub.name in res:
                hit.add(sub.name)
            targets = sub.targets if isinstance(sub, ast.Assign) else [sub.target] if isinstance(
                sub, (ast.AnnAssign, ast.AugAssign)) else []
            for t in targets:
                for e in [t] + list(getattr(t, "elts", [])):
                    if isinstance(e, ast.Attribute) and isinstance(e.value, ast.Name) and e.value.id == "self" \
                            and e.attr in res:
                        hit.add(e.attr)
        if hit:
            out[node.name] = hit
    # a subclass of a renamed class uses the same names
    changed = True
    while changed:
        changed = False
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for b in node.bases:
                    if isinstance(b, ast.Name) and b.id in out and not out[b.id] <= out.get(node.name, set()):
                        out[node.name] = out.get(node.name, set()) | out[b.id]
                        changed = True
    return out
