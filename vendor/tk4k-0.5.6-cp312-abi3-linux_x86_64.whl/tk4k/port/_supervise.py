"""Port many files without ever taking the whole run down.

The parent never parses anything. Each file goes to a worker process (one by default; --jobs N for more),
so a file that crashes the interpreter, runs out of memory or never finishes costs that file only:
the worker is killed, the file is reported as failed with the reason, a fresh worker starts, the run goes on.

The parent prints a progress line per file, an estimate of the time left, and while a big file is quiet a
"still working" heartbeat every few seconds (with the worker's memory), so a slow machine never looks dead.

Test hooks (to prove the above): TK4K_PORT_TEST="crash:NAME,hang:NAME,oom:NAME" makes the worker die, freeze
or allocate without limit when it reaches a file whose name contains NAME.
"""
from __future__ import annotations

import multiprocessing as mp
import os
import sys
import time
from typing import Callable, Optional

from . import Result, port_file

HEARTBEAT_S = 5.0
MS_PER_LINE = 1.5  # first guess for the estimate; replaced by this machine's own speed after the first files


# ----------------------------------------------------------------------------------- worker side
def _die_with_parent() -> None:
    """Linux: get SIGTERM if the parent dies, so a cancelled run leaves nothing behind."""
    if sys.platform.startswith("linux"):
        try:
            import ctypes
            import signal
            ctypes.CDLL("libc.so.6", use_errno=True).prctl(1, signal.SIGTERM)  # PR_SET_PDEATHSIG
        except Exception:
            pass


def _limit_memory(mb: int) -> None:
    if mb <= 0:
        return
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_AS, (mb * 2**20, mb * 2**20))
    except Exception:  # not on Windows; the parent's watchdog still applies
        pass


def _test_hook(path: str) -> None:
    spec = os.environ.get("TK4K_PORT_TEST", "")
    name = os.path.basename(path)
    for item in filter(None, spec.split(",")):
        kind, _, key = item.partition(":")
        if key and key in name:
            if kind == "crash":
                os._exit(70)
            if kind == "hang":
                time.sleep(10**6)
            if kind == "oom":
                hog = []
                while True:
                    hog.append(bytearray(50 * 2**20))


def _worker(conn, write: bool, qr: Optional[bool], mem_mb: int) -> None:
    _die_with_parent()
    _limit_memory(mem_mb)
    try:
        import libcst  # noqa: F401  (load once per worker, not per file)
    except ImportError:
        pass
    while True:
        try:
            path = conn.recv()
        except (EOFError, OSError):
            return
        if path is None:
            return
        try:
            _test_hook(path)
            r = port_file(path, write=write, qr=qr)
        except MemoryError:
            r = Result(source=path, grade="failed", error="MemoryError: the file needs more memory than this run allows")
        except BaseException as e:  # port_file should never raise; if it does, report it, keep the worker
            r = Result(source=path, grade="failed", error=f"{type(e).__name__}: {e}")
        try:
            conn.send(r)
        except Exception:
            return


# ----------------------------------------------------------------------------------- parent side
def _rss_mb(pid: int) -> Optional[float]:
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024
    except OSError:
        return None
    return None


def _lines(path: str) -> int:
    try:
        with open(path, "rb") as f:
            return f.read().count(b"\n") + 1
    except OSError:
        return 1


def memory_budget_mb(jobs: int) -> int:
    """Per worker: 60 % of the memory available now, shared between workers, at most 2 GB, at least 256 MB."""
    avail = None
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    avail = int(line.split()[1]) / 1024
    except OSError:
        pass
    if avail is None:
        return 0  # unknown (not Linux): no hard cap, the timeout still applies
    return int(max(256, min(2048, avail * 0.6 / max(1, jobs))))


class _Slot:
    def __init__(self, ctx, write, qr, mem_mb):
        self.args = (write, qr, mem_mb)
        self.ctx = ctx
        self.start()

    def start(self):
        self.conn, child = self.ctx.Pipe()
        self.proc = self.ctx.Process(target=_worker, args=(child, *self.args), daemon=True)
        self.proc.start()
        child.close()
        self.path: Optional[str] = None
        self.t0 = 0.0
        self.beat = 0.0

    def give(self, path):
        self.path, self.t0 = path, time.monotonic()
        self.beat = self.t0
        self.conn.send(path)

    def kill(self):
        try:
            self.proc.kill()
            self.proc.join(5)
        except Exception:
            pass

    def stop(self):
        try:
            self.conn.send(None)
            self.proc.join(2)
        except Exception:
            pass
        if self.proc.is_alive():
            self.kill()


def run_many(files: list[str], *, write: bool = True, qr: Optional[bool] = None, jobs: int = 1,
             timeout_s: float = 600.0, out=sys.stderr, on_result: Optional[Callable[[Result], None]] = None,
             mem_mb: Optional[int] = None) -> list[Result]:
    """Port every file in worker processes. Never raises because of one file; returns results in input order."""
    jobs = max(1, min(jobs, len(files) or 1))
    mem_mb = memory_budget_mb(jobs) if mem_mb is None else mem_mb
    ctx = mp.get_context("fork" if sys.platform.startswith("linux") else "spawn")
    sizes = {f: _lines(f) for f in files}
    total_lines = sum(sizes.values())
    say = lambda s: print(f"[tk4k.port] {s}", file=out, flush=True)  # noqa: E731
    est = total_lines * MS_PER_LINE / 1000 / jobs
    say(f"{len(files)} files, {total_lines} lines, {jobs} worker(s), memory cap "
        f"{str(mem_mb) + ' MB' if mem_mb else 'none'} per worker, about {est:.0f}s (first guess)")
    slots = [_Slot(ctx, write, qr, mem_mb) for _ in range(jobs)]
    todo = list(files)
    results: dict[str, Result] = {}
    t_start = time.monotonic()
    done_lines = 0
    busy_s = 0.0
    total_left_fix = [0]  # lines of files that failed: no longer to do

    def finish(slot, r: Result):
        nonlocal done_lines, busy_s
        dt = time.monotonic() - slot.t0
        r.seconds = r.seconds or dt
        results[slot.path] = r
        if r.grade != "failed":  # crashes and timeouts say nothing about this machine's speed
            done_lines += sizes[slot.path]
            busy_s += dt
        else:
            total_left_fix[0] += sizes[slot.path]
        rate = busy_s / max(1, done_lines)  # seconds per line on this machine
        left = (total_lines - done_lines - total_left_fix[0]) * rate / jobs
        say(f"{len(results)}/{len(files)} {r.grade:7} {dt:5.1f}s  {slot.path}   (about {left:.0f}s left)")
        if on_result:
            on_result(r)
        slot.path = None

    try:
        while todo or any(s.path for s in slots):
            for s in slots:
                if s.path is None and todo:
                    s.give(todo.pop(0))
            busy = [s for s in slots if s.path]
            ready = mp.connection.wait([s.conn for s in busy] + [s.proc.sentinel for s in busy], timeout=1.0)
            now = time.monotonic()
            for s in busy:
                if s.conn in ready:
                    try:
                        finish(s, s.conn.recv())
                        continue
                    except (EOFError, OSError):
                        pass  # the worker died while answering: handled below
                if s.conn in ready or s.proc.sentinel in ready or not s.proc.is_alive():
                    s.proc.join(2)  # let the exit code arrive
                    code = s.proc.exitcode
                    why = ("killed by the system (out of memory?)" if code in (-9, 137) else
                           f"the worker process died (exit code {code})")
                    finish(s, Result(source=s.path, grade="failed", error=f"WorkerDied: {why}"))
                    s.kill()
                    s.start()
                elif now - s.t0 > timeout_s:
                    finish(s, Result(source=s.path, grade="failed",
                                     error=f"Timeout: no result after {timeout_s:.0f}s; stopped (raise with --timeout)"))
                    s.kill()
                    s.start()
                elif now - s.beat >= HEARTBEAT_S:
                    s.beat = now
                    rss = _rss_mb(s.proc.pid)
                    say(f"  still working on {os.path.basename(s.path)} ({sizes[s.path]} lines): "
                        f"{now - s.t0:.0f}s so far" + (f", {rss:.0f} MB" if rss else "") +
                        f"; {len(results)}/{len(files)} done, {now - t_start:.0f}s in total")
    finally:
        for s in slots:
            s.stop()
    return [results[f] for f in files if f in results]
