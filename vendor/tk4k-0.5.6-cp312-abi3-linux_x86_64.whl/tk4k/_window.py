"""The window and its event loop."""
from __future__ import annotations

import collections
import heapq
import itertools
import time
import traceback
from importlib import resources
from typing import Any, Callable, Optional, Union

from . import _core, _widgets
from ._theme import THEMES, Theme
from ._widgets import Column, _SizeAttr, _take_callbacks


class _TitleStr(str):
    def __new__(cls, text, win):
        o = super().__new__(cls, text)
        o._win = win
        return o

    def __call__(self, text=None):
        if text is None:
            return str(self)
        self._win.title = text


_current: list = []


class Window(_SizeAttr, Column):
    """The top-level window. Use it like a Column:

        with Window("Hello", size=(400, 200)) as win:
            Label("Hi")
        win.run()

    The loop sleeps inside the OS until something happens, so an idle window uses ~0% CPU.
    """

    def __init__(self, title: str = "TK 4K", size: tuple[int, int] = (480, 320), *,
                 theme: Union[str, Theme] = "auto", min_size: Optional[tuple[int, int]] = None,
                 resizable: bool = True, pad: float = 16.0, gap: Optional[float] = None):
        super().__init__(None, gap=gap)
        self._title, self._size, self.min_size = title, tuple(size), min_size
        self._resizable, self.pad = resizable, pad
        self._theme_spec = theme
        self.theme: Optional[Theme] = None
        self.strict = False  # True: errors in callbacks stop the app (tests); False: print and go on
        self.error: Optional[BaseException] = None
        self._started = False
        self._timers: list[tuple[float, int, Callable, tuple]] = []
        self._cancelled: set[int] = set()
        self._timer_ids = itertools.count(1)
        self._posted: collections.deque = collections.deque()
        self._toasts: list[tuple[str, float]] = []
        self._font_bytes: Optional[bytes] = None
        self._anim_due: Optional[float] = None
        self._on_close = None
        self._quitting = False
        self._binds: dict = {}
        self._dialogs: list = []
        self.menubar = None
        _current.append(self)

    # ------------------------------------------------------------ properties
    @property
    def title(self) -> "_TitleStr":
        """The window title. Also callable, like tkinter's: win.title("New title")."""
        return _TitleStr(self._title, self)

    @title.setter
    def title(self, value: str) -> None:
        self._title = str(value)
        if self._started:
            _core.set_title(value)

    def set_theme(self, theme: Union[str, Theme]) -> None:
        """'dark', 'light', 'auto' (follow the OS) or a Theme. Before the window opens it is just remembered."""
        if not self._started:  # the native core is not initialised yet; calling it then crashed the process
            self._theme_spec = theme
            return
        if isinstance(theme, str):
            if theme == "auto":
                theme = THEMES["dark" if _core.system_dark() else "light"]
            else:
                theme = THEMES[theme]
        self.theme = theme
        _core.set_theme(theme.colours(), theme.rounding, theme.pad_x, theme.pad_y, theme.gap, theme.dark)

    # ------------------------------------------------------------ timers and threads
    def after(self, ms: float, fn: Callable, *args: Any) -> int:
        """Run fn(*args) once, ms milliseconds from now (like Tk's after). Returns an id."""
        tid = next(self._timer_ids)
        heapq.heappush(self._timers, (time.monotonic() + ms / 1000.0, tid, fn, args))
        _core.wake()
        return tid

    def after_idle(self, fn: Callable, *args: Any) -> int:
        return self.after(0, fn, *args)

    def after_cancel(self, tid: int) -> None:
        self._cancelled.add(tid)

    def post(self, fn: Callable, *args: Any) -> None:
        """Run fn(*args) on the UI thread. The one call that is safe from worker threads."""
        self._posted.append((fn, args))
        _core.wake()

    def toast(self, text: str, seconds: float = 2.5) -> None:
        """A short message at the bottom of the window that fades away by itself."""
        self._toasts.append((text, time.monotonic() + seconds))
        self.after(seconds * 1000 + 30, lambda: None)

    def quit(self) -> None:
        self._quitting = True
        if self._started:   # before the window exists the request waits for _start(): the native flag is global
            _core.request_quit()

    destroy = quit

    # ---- tkinter compatibility for translated apps
    def geometry(self, spec: str = "") -> None:
        import re as _re
        m = _re.match(r"(\d+)x(\d+)", str(spec))
        if m:
            self._size = (int(m.group(1)), int(m.group(2)))

    def minsize(self, w=0, h=0) -> None:
        self.min_size = (int(w), int(h))

    def resizable(self, w=None, h=None, *, width=None, height=None):
        """resizable(False, False) / resizable(width=False, height=False); with no arguments, the current setting."""
        w = width if w is None else w
        h = height if h is None else h
        if w is None and h is None:
            return (int(self._resizable), int(self._resizable))
        self._resizable = bool((True if w is None else w) or (True if h is None else h))

    def protocol(self, name: str, fn=None) -> None:
        if name == "WM_DELETE_WINDOW":
            self._on_close = fn

    def bind(self, seq, fn=None, add=None) -> None:
        """Key bindings such as "<space>", "<Return>", "<Escape>", "<Control-s>"; mouse bindings are noted and ignored."""
        s = str(seq) if str(seq).startswith("<<") else str(seq).strip("<>")  # "<<Virtual>>" kept whole
        if fn is None:
            return
        self._binds[s] = fn

    bind_all = bind

    # --- the long wm_* names (tkinter has both), and the window-state calls programs make around start-up
    def wm_title(self, text=None):
        return self.title(text)

    wm_geometry = lambda self, spec="": self.geometry(spec)  # noqa: E731
    wm_minsize = lambda self, w=0, h=0: self.minsize(w, h)  # noqa: E731
    wm_resizable = lambda self, *a, **k: self.resizable(*a, **k)  # noqa: E731

    def wm_protocol(self, name=None, fn=None):
        return self.protocol(name, fn)

    def wm_maxsize(self, *a):
        _widgets._compat_note("maxsize() is not supported")

    maxsize = wm_maxsize

    def wm_state(self, s=None):
        return "normal"

    state = wm_state

    def withdraw(self):
        _widgets._compat_note("withdraw()/iconify() do not hide the window")

    deiconify = iconify = wm_withdraw = wm_deiconify = wm_iconify = withdraw

    def wm_iconbitmap(self, *a, **k):
        pass

    iconbitmap = iconphoto = wm_iconphoto = wm_iconbitmap

    def winfo_screenwidth(self):
        return 1920

    def winfo_screenheight(self):
        return 1080

    def winfo_width(self):
        return int(_core.window_size()[0]) if self._started else int(self._size[0])

    def winfo_height(self):
        return int(_core.window_size()[1]) if self._started else int(self._size[1])

    winfo_reqwidth = winfo_width
    winfo_reqheight = winfo_height

    def winfo_exists(self):
        return int(self._started or True)

    # --- wm_attributes ("-topmost", True, "-alpha", 0.9, "-fullscreen", True)
    def wm_attributes(self, *args, **kw):
        pairs = list(zip(args[0::2], args[1::2])) + [("-" + k, v) for k, v in kw.items()]
        if len(args) == 1:  # query
            return self.__dict__.get("_attrs", {}).get(str(args[0]).lstrip("-"))
        for k, v in pairs:
            name = str(k).lstrip("-")
            val = float(v) if not isinstance(v, str) else float(v not in ("0", "false", "False", "")) if name != "alpha" else float(v)
            self.__dict__.setdefault("_attrs", {})[name] = val
            if name not in ("topmost", "alpha", "fullscreen"):
                _widgets._compat_note(f"wm_attributes(-{name}) is not supported")
            elif self._started:
                _core.window_attr(name, val)

    attributes = wm_attributes

    # --- virtual events: bind("<<Name>>") + event_generate("<<Name>>")
    def event_generate(self, seq, *_a, **kw):
        s = str(seq)
        fn = self._binds.get(s) if s.startswith("<<") else None
        if fn is not None:
            _widgets._queue(lambda f=fn: f(_widgets._Event(self)))
        elif not s.startswith("<<"):
            _widgets._compat_note(f"event_generate({s}): only <<virtual>> events are delivered")

    # a tkinter app often has its own `def run(self): self.mainloop()`: mainloop must not call the overridable run()
    mainloop = lambda self, n=0: Window.run(self)  # noqa: E731

    def _poll_keys(self) -> None:
        for seq, fn in self._binds.items():
            if seq.startswith("<"):  # "<<Name>>" stored as "<Name>": a virtual event, not a key
                continue
            parts = seq.split("-")
            key = {"KeyPress": parts[-1], "Key": parts[-1]}.get(parts[0], parts[-1])
            if key.startswith("KeyPress") or key == "Key":
                key = parts[-1]
            if _core.key_pressed(key):
                _widgets._queue(lambda f=fn: f(_widgets._Event(self)))

    def config(self, cnf=None, **kw):
        kw = dict(cnf or {}, **kw)
        if "menu" in kw:
            self.menubar = kw.pop("menu")
        if kw:
            super().config(**kw)

    configure = config

    # modal dialogs (callbacks instead of blocking: TK 4K never freezes the window)
    def message(self, title, text, on_close=None):
        from ._widgets2 import message
        return message(self, title, text, on_close)

    def ask_yes_no(self, title, text, on_answer, yes="Yes", no="No"):
        from ._widgets2 import ask_yes_no
        return ask_yes_no(self, title, text, on_answer, yes, no)

    def ask_string(self, title, prompt, on_answer, initial=""):
        from ._widgets2 import ask_string
        return ask_string(self, title, prompt, on_answer, initial)

    def ask_open_file(self, on_answer, start=None, title="Open file"):
        from ._widgets2 import ask_open_file
        return ask_open_file(self, on_answer, start, title)

    def update(self, *a, **k) -> None:
        """Draw one frame and run due callbacks, like tkinter's update().

        Real programs use it two ways: `root.update()` before mainloop (to measure sizes) and
        `while True: ...; root.update()` as a game loop. After the window is closed it raises TclError, as tkinter
        does, so `try: while True: root.update() except TclError: pass` ends cleanly."""
        if self.__dict__.get("_closed") or (self._quitting and self._started):
            self.__dict__["_closed"] = True
            self._stop()   # destroy() in a game loop: the window goes now, like tkinter's
            from ._dialogs import TclError
            raise TclError('can\'t invoke "update" command: application has been destroyed')
        if self.__dict__.get("_in_draw") or self._quitting:
            return
        self._start()
        alive = _core.pump(self._draw_frame, 0)
        self._after_frame()
        if not alive:
            if self._on_close is not None and not self._quitting:
                try:
                    self._on_close()
                except Exception as e:
                    self._fail(e)
                if not self._quitting:
                    return
            self.__dict__["_closed"] = True
            self._stop()

    def _noop(self, *a, **k) -> None:
        pass

    update_idletasks = lift = focus_force = option_add = _noop

    # --- window-manager calls with no TK 4K meaning: remembered (so a query returns what was set), otherwise ignored
    def _wm_store(name):
        def f(self, *a, **k):
            store = self.__dict__.setdefault("_wm", {})
            if a or k:
                store[name] = a[0] if len(a) == 1 else (a or tuple(k.values()))
                return None
            return store.get(name, "")
        f.__name__ = name
        return f

    transient = wm_transient = _wm_store("transient")
    group = wm_group = _wm_store("group")
    iconname = wm_iconname = _wm_store("iconname")
    command = wm_command = _wm_store("command")
    aspect = wm_aspect = _wm_store("aspect")
    positionfrom = wm_positionfrom = _wm_store("positionfrom")
    sizefrom = wm_sizefrom = _wm_store("sizefrom")
    focusmodel = wm_focusmodel = _wm_store("focusmodel")
    iconposition = wm_iconposition = _wm_store("iconposition")
    iconwindow = wm_iconwindow = _wm_store("iconwindow")
    iconmask = wm_iconmask = _wm_store("iconmask")
    client = wm_client = _wm_store("client")
    colormapwindows = wm_colormapwindows = _wm_store("colormapwindows")
    del _wm_store

    def overrideredirect(self, flag=None):
        """A borderless window (splash screens). Remembered; the native window keeps its border for now."""
        if flag is None:
            return self.__dict__.get("_wm", {}).get("overrideredirect", False)
        self.__dict__.setdefault("_wm", {})["overrideredirect"] = bool(flag)
        if flag:
            _widgets._compat_note("overrideredirect(): the window keeps its title bar in TK 4K")

    wm_overrideredirect = overrideredirect
    frame = wm_frame = lambda self: hex(self._id)  # noqa: E731
    manage = wm_manage = wm_forget = lambda self, *a: None  # noqa: E731
    readprofile = loadtk = lambda self, *a: None  # noqa: E731

    def report_callback_exception(self, exc, val, tb):
        """tkinter's hook for errors in callbacks; programs replace it (root.report_callback_exception = fn)."""
        traceback.print_exception(exc, val, tb)

    def toast_or_none(self):
        return self

    # ------------------------------------------------------------ loop
    def _start(self) -> None:
        if self._started:
            return
        try:  # translated apps: say up front that parts are placeholders
            from . import _alerts
            n = sum(1 for e in _alerts.events() if e["kind"] == "placeholder")
            if n:
                self._toasts.append((f"{n} widget(s) in this app are placeholders (see the log)", time.monotonic() + 6))
        except Exception:
            pass
        _core.init(self._title, int(self._size[0]), int(self._size[1]), self._resizable)
        self._started = True
        if self._quitting:
            _core.request_quit()
        try:
            self._font_bytes = resources.files("tk4k").joinpath("fonts/Inter-Regular-latin.otf").read_bytes()
        except Exception:  # missing font file is not fatal; the built-in font is used
            self._font_bytes = None
        self.set_theme(self._theme_spec)
        if self._font_bytes:
            _core.set_font_memory(self._font_bytes, self.theme.font_size)
        if self.min_size:
            _core.set_min_size(*self.min_size)
        for k, v in self.__dict__.get("_attrs", {}).items():
            _core.window_attr(k, v)

    def _stop(self) -> None:
        if self._started:
            _core.shutdown()
            self._started = False

    def _timeout_ms(self) -> int:
        if self._posted or _widgets._callbacks:
            return 0
        due = [self._timers[0][0]] if self._timers else []
        if self._anim_due is not None:
            due.append(self._anim_due)
        if not due:
            return -1  # nothing scheduled: sleep until the user does something
        return max(0, int((min(due) - time.monotonic()) * 1000) + 1)

    def _draw_frame(self) -> None:
        self.__dict__["_in_draw"] = True
        try:
            _widgets._anim_ms = 0
            if self.gap is not None:
                _core.push_spacing(self.gap, self.gap)
            try:
                if self.menubar is not None:
                    self.menubar._draw_bar()
                if _core.begin_root(self.pad, self.pad):
                    if self._binds:
                        self._poll_keys()
                    self._draw_children()
            finally:
                _core.end_root()
                if self.gap is not None:
                    _core.pop_spacing()
            for d in list(self._dialogs):
                d._render_dialog()
            pm = self.__dict__.get("_popmenus")
            if pm:
                self.__dict__["_popmenus"] = [m for m in pm if m._render_popup() or m.__dict__.get("_want_open")]
            self._draw_toasts()
            self._anim_due = (time.monotonic() + _widgets._anim_ms / 1000.0) if _widgets._anim_ms else None
        except Exception as e:  # keep ImGui's frame balanced; report after the frame
            self.error = e
        finally:
            self.__dict__["_in_draw"] = False

    def _draw_toasts(self) -> None:
        now = time.monotonic()
        self._toasts = [t for t in self._toasts if t[1] > now]
        if self._toasts and _core.begin_overlay("##toast", 0.5, 1.0, 18.0):
            for text, _ in self._toasts:
                _core.text(text, False)
        if self._toasts:
            _core.end_overlay()

    def _fail(self, exc: BaseException) -> None:
        if self.strict:
            raise exc
        try:
            from . import _alerts
            _alerts.note("callback", f"{type(exc).__name__}: {exc}"[:80], once_key=f"cb:{type(exc).__name__}:{exc}"[:120])
        except Exception:
            pass
        hook = self.__dict__.get("report_callback_exception")
        if hook is None and type(self).report_callback_exception is not Window.report_callback_exception:
            hook = self.report_callback_exception
        if hook is not None:
            try:
                hook(type(exc), exc, exc.__traceback__)
                return
            except Exception:
                pass
        traceback.print_exception(type(exc), exc, exc.__traceback__)

    def _after_frame(self) -> None:
        """Everything that must not happen mid-frame: posted calls, timers, widget callbacks."""
        if self.error is not None:
            err, self.error = self.error, None
            raise err
        while self._posted:
            fn, args = self._posted.popleft()
            try:
                fn(*args)
            except Exception as e:
                self._fail(e)
        now = time.monotonic()
        ran = False
        while self._timers and self._timers[0][0] <= now:
            _, tid, fn, args = heapq.heappop(self._timers)
            if tid in self._cancelled:
                self._cancelled.discard(tid)
                continue
            ran = True
            try:
                fn(*args)
            except Exception as e:
                self._fail(e)
        animating = self._anim_due is not None and self._anim_due <= now
        for fn, args in _take_callbacks():
            try:
                fn(*args)
            except Exception as e:
                self._fail(e)
        if ran:
            _core.wake()
        elif animating:
            _core.wake(1)  # a moving bar needs one frame per step, not two

    def _wait_until(self, cond, timeout_ms: int = 100) -> bool:
        """A nested event loop for blocking dialogs: keep drawing and running callbacks until cond() is true.
        Returns False if the window was closed first. Called from a callback, i.e. outside a frame draw."""
        self._start()
        while not cond():
            alive = _core.pump(self._draw_frame, min(timeout_ms, self._timeout_ms()))
            self._after_frame()
            if not alive:
                return cond()
        return True

    def run(self) -> None:
        """Open the window and run until it is closed."""
        self._start()
        try:
            while True:
                alive = _core.pump(self._draw_frame, self._timeout_ms())
                self._after_frame()
                if not alive:
                    if self._on_close is not None and not self._quitting:
                        try:  # WM_DELETE_WINDOW: the handler decides (it calls destroy() to really close)
                            self._on_close()
                        except Exception as e:
                            self._fail(e)
                        if not self._quitting:
                            continue
                    break
        finally:
            self._stop()
