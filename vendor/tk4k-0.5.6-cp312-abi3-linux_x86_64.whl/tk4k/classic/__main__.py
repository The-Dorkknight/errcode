"""python -m tk4k.classic app.py [args]   |   python -m tk4k.classic -m package.module [args]"""
import os
import runpy
import sys

from . import install


def main() -> None:
    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        print("Settings: TK4K_THEME=auto|dark|light  TK4K_ACCENT=#RRGGBB  TK4K_CLASSIC=0 (off)")
        sys.exit(0 if argv else 2)
    install()
    if argv[0] == "-m":
        sys.argv = argv[1:]
        runpy.run_module(argv[1], run_name="__main__", alter_sys=True)
    else:
        path = os.path.abspath(argv[0])
        sys.argv = [path] + argv[1:]
        sys.path.insert(0, os.path.dirname(path))
        runpy.run_path(path, run_name="__main__")


main()
