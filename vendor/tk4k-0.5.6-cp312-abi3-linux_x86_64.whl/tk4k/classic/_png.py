"""Tiny PNG writer + rounded-rectangle painter, so the ttk theme needs no image files or Pillow."""
from __future__ import annotations

import base64
import struct
import zlib


def png_bytes(w: int, h: int, rgba: bytearray) -> bytes:
    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    raw = b"".join(b"\x00" + bytes(rgba[y * w * 4:(y + 1) * w * 4]) for y in range(h))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def _rgb(c: int) -> tuple[int, int, int]:
    return (c >> 16) & 255, (c >> 8) & 255, c & 255


def rounded_rect(w: int, h: int, radius: float, fill: int, border: int | None = None,
                 border_w: float = 1.0) -> str:
    """Anti-aliased rounded rectangle from its exact signed distance (one evaluation per pixel, so it is
    cheap even on slow CPUs). Returns base64 PNG for tk PhotoImage(data=...)."""
    fr, fg, fb = _rgb(fill)
    br, bg_, bb = _rgb(border if border is not None else fill)
    out = bytearray(w * h * 4)
    hx, hy, r = w / 2.0, h / 2.0, float(radius)
    for y in range(h):
        py = abs(y + 0.5 - hy) - (hy - r)
        for x in range(w):
            px = abs(x + 0.5 - hx) - (hx - r)
            qx, qy = max(px, 0.0), max(py, 0.0)
            d = (qx * qx + qy * qy) ** 0.5 + min(max(px, py), 0.0) - r   # <0 inside
            alpha = min(max(0.5 - d, 0.0), 1.0)
            if alpha <= 0.0:
                continue
            t = min(max(-d - border_w + 0.5, 0.0), 1.0) if border is not None else 1.0  # 1 = fill, 0 = border
            i = (y * w + x) * 4
            out[i] = round(br + (fr - br) * t)
            out[i + 1] = round(bg_ + (fg - bg_) * t)
            out[i + 2] = round(bb + (fb - bb) * t)
            out[i + 3] = round(255 * alpha)
    return base64.b64encode(png_bytes(w, h, out)).decode("ascii")
