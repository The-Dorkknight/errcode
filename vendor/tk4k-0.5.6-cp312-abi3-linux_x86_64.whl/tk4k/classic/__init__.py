"""tk4k.classic: run an existing tkinter app, unchanged, on real Tk with TK 4K's look.

    python -m tk4k.classic myapp.py [args]        # no code change
    python -m tk4k.classic -m idlelib              # a module
    import tk4k.classic; tk4k.classic.install()    # one line, before the app creates its window

What it changes, using only Tk's own mechanisms (so nothing about the app's behaviour changes):
  * ttk widgets: a "tk4k" ttk theme built at start-up (TK 4K colours, rounded buttons and fields
    drawn as small generated PNGs, flat scrollbars, accent progress bars and selections).
  * classic tk widgets (tk.Button, tk.Label, ...): Tk's *option database*, i.e. new default colours,
    flat reliefs and padding. Anything the app sets explicitly (bg="red") still wins.
  * fonts: Tk's named default fonts point at a modern family that is installed (Inter, Ubuntu, Noto Sans...).
What it deliberately leaves alone:
  * Canvas backgrounds: apps draw black-by-default items on them; darkening would hide drawings.
  * Anything an app or add-on themes itself (ttkbootstrap, sv-ttk, CustomTkinter pick their own look).

Settings (environment): TK4K_THEME=auto|dark|light (auto reads the desktop's dark-mode setting where it can),
TK4K_CLASSIC=0 turns the skin off, TK4K_ACCENT=#RRGGBB.
"""
from __future__ import annotations

import os
import subprocess
import sys

from .._theme import Theme
from ._png import rounded_rect

__all__ = ["install", "apply", "uninstall", "chosen_theme"]

_installed = False
_orig_tk_init = None

UI_FONTS = ["Inter", "Ubuntu", "Noto Sans", "Cantarell", "Segoe UI", "SF Pro Text", "Helvetica Neue",
            "DejaVu Sans", "Liberation Sans", "Arial"]
MONO_FONTS = ["JetBrains Mono", "Ubuntu Mono", "Noto Sans Mono", "DejaVu Sans Mono", "Consolas", "Menlo",
              "Liberation Mono", "Courier New"]


def _hex(c: int) -> str:
    return f"#{c:06x}"


def _desktop_prefers_dark() -> bool | None:
    """Best effort, no new dependencies. Linux Mint (Cinnamon) and GNOME expose the choice via gsettings."""
    if sys.platform.startswith("linux"):
        for schema, key in (("org.gnome.desktop.interface", "color-scheme"),
                            ("org.cinnamon.desktop.interface", "gtk-theme"),
                            ("org.gnome.desktop.interface", "gtk-theme")):
            try:
                out = subprocess.run(["gsettings", "get", schema, key], capture_output=True, text=True,
                                     timeout=1).stdout.strip().strip("'").lower()
            except (OSError, subprocess.SubprocessError):
                return None
            if out:
                if "dark" in out:
                    return True
                if key == "color-scheme" and out in ("prefer-light", "default"):
                    continue  # GNOME 'default' says little on Cinnamon; try the theme name next
                if key == "gtk-theme":
                    return False
    if sys.platform == "darwin":
        try:
            out = subprocess.run(["defaults", "read", "-g", "AppleInterfaceStyle"], capture_output=True,
                                 text=True, timeout=1).stdout
            return "Dark" in out
        except (OSError, subprocess.SubprocessError):
            return None
    if sys.platform == "win32":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                               r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
            return winreg.QueryValueEx(k, "AppsUseLightTheme")[0] == 0
        except OSError:
            return None
    return None


def chosen_theme() -> Theme:
    mode = os.environ.get("TK4K_THEME", "auto").lower()
    dark = {"dark": True, "light": False}.get(mode)
    if dark is None:
        dark = bool(_desktop_prefers_dark())
    accent = os.environ.get("TK4K_ACCENT")
    return Theme.make(dark=dark, accent=int(accent.lstrip("#"), 16) if accent else None)


def _pick(root, wanted: list[str]) -> str:
    have = {f.lower(): f for f in root.tk.splitlist(root.tk.call("font", "families"))}
    for f in wanted:
        if f.lower() in have:
            return have[f.lower()]
    return wanted[-1]


def _fonts(root, t: Theme) -> None:
    import tkinter.font as tkfont
    ui, mono = _pick(root, UI_FONTS), _pick(root, MONO_FONTS)
    size = 10  # points; Tk scales by the display's DPI
    for name, fam, sz, weight in (("TkDefaultFont", ui, size, "normal"), ("TkTextFont", ui, size, "normal"),
                                  ("TkMenuFont", ui, size, "normal"), ("TkHeadingFont", ui, size, "bold"),
                                  ("TkCaptionFont", ui, size + 1, "bold"), ("TkSmallCaptionFont", ui, size - 1, "normal"),
                                  ("TkIconFont", ui, size, "normal"), ("TkTooltipFont", ui, size - 1, "normal"),
                                  ("TkFixedFont", mono, size, "normal")):
        try:
            tkfont.nametofont(name, root=root).configure(family=fam, size=sz, weight=weight)
        except Exception:  # noqa: BLE001  (a missing named font must never stop the app)
            pass


def _option_db(root, t: Theme) -> None:
    """Defaults for classic tk widgets. Priority 'widgetDefault' (20): any explicit option the app sets wins."""
    P = "widgetDefault"
    o = root.option_add
    import tkinter
    probe = tkinter.Canvas(root)  # Tk's own default canvas colour, read before any of our options exist
    canvas_bg = probe.cget("background")
    probe.destroy()
    bg, fg, wbg, hov, act = _hex(t.bg), _hex(t.text), _hex(t.widget), _hex(t.hover), _hex(t.active)
    acc, dim, border, on_acc = _hex(t.accent), _hex(t.text_dim), _hex(t.border), _hex(t.on_accent)
    for pat, val in (("*Background", bg), ("*Foreground", fg), ("*activeBackground", hov),
                     ("*activeForeground", fg), ("*disabledForeground", dim), ("*highlightBackground", bg),
                     ("*highlightColor", acc), ("*selectBackground", acc), ("*selectForeground", on_acc),
                     ("*insertBackground", fg), ("*troughColor", wbg), ("*selectColor", wbg),
                     ("*Button.relief", "flat"), ("*Button.borderWidth", "0"), ("*Button.background", wbg),
                     ("*Button.highlightThickness", "1"), ("*Button.highlightBackground", border),
                     ("*Button.padX", "10"), ("*Button.padY", "4"), ("*Button.cursor", "hand2"),
                     ("*Entry.relief", "flat"), ("*Entry.background", wbg), ("*Entry.highlightThickness", "1"),
                     ("*Entry.highlightBackground", border), ("*Spinbox.relief", "flat"),
                     ("*Spinbox.background", wbg), ("*Spinbox.buttonBackground", wbg),
                     ("*Listbox.relief", "flat"), ("*Listbox.background", wbg), ("*Listbox.highlightThickness", "1"),
                     ("*Listbox.highlightBackground", border), ("*Text.relief", "flat"), ("*Text.background", wbg),
                     ("*Text.highlightThickness", "1"), ("*Text.highlightBackground", border),
                     ("*Text.padX", "6"), ("*Text.padY", "4"),
                     ("*Checkbutton.relief", "flat"), ("*Checkbutton.activeBackground", bg), ("*Scale.troughColor", border),
                     ("*Radiobutton.activeBackground", bg), ("*Scale.relief", "flat"),
                     ("*Scale.highlightThickness", "0"), ("*Scale.sliderRelief", "flat"),
                     ("*Scrollbar.relief", "flat"), ("*Scrollbar.borderWidth", "0"), ("*Scrollbar.width", "12"),
                     ("*Scrollbar.background", hov), ("*Scrollbar.elementBorderWidth", "0"),
                     ("*Menu.relief", "flat"), ("*Menu.borderWidth", "1"), ("*Menu.activeBorderWidth", "0"),
                     ("*Menu.background", _hex(t.surface)), ("*Menu.activeBackground", acc),
                     ("*Menu.activeForeground", on_acc), ("*Menubutton.relief", "flat"),
                     ("*Menubutton.background", wbg), ("*LabelFrame.relief", "groove"),
                     ("*Labelframe.relief", "groove"), ("*Frame.highlightThickness", "0"),
                     ("*Toplevel.background", bg)):
        o(pat, val, P)
    # Canvas: pinned to Tk's default on purpose (see module docstring); only its focus ring is calmed.
    o("*Canvas.background", canvas_bg, P)
    o("*Canvas.highlightThickness", "0", P)
    root.configure(background=bg)


def _ttk_theme(root, t: Theme) -> None:
    from tkinter import ttk
    style = ttk.Style(root)
    if "tk4k" in style.theme_names():
        style.theme_use("tk4k")
        return
    bg, fg, wbg, hov, act = _hex(t.bg), _hex(t.text), _hex(t.widget), _hex(t.hover), _hex(t.active)
    acc, dim, border, on_acc, surf = _hex(t.accent), _hex(t.text_dim), _hex(t.border), _hex(t.on_accent), _hex(t.surface)
    r = 6
    imgs = {}

    def img(name, fill, border_c=None, w=24, h=24):
        import tkinter as tk
        imgs[name] = tk.PhotoImage(master=root, name=f"tk4k_{name}", data=rounded_rect(w, h, r, fill, border_c))
        return imgs[name]

    img("btn", t.widget, t.border); img("btn_hover", t.hover, t.border); img("btn_press", t.active, t.border)
    img("btn_dis", t.surface, t.border)
    img("acc", t.accent); img("acc_hover", t.accent_hover); img("acc_press", t.accent_active)
    img("field", t.widget, t.border); img("field_focus", t.widget, t.accent); img("field_dis", t.surface, t.border)
    style.theme_create("tk4k", parent="clam")
    style.theme_use("tk4k")
    style.element_create("tk4k.Button.border", "image", "tk4k_btn",
                         ("pressed", "tk4k_btn_press"), ("active", "tk4k_btn_hover"), ("disabled", "tk4k_btn_dis"),
                         border=r + 2, padding=(10, 5), sticky="nsew")
    style.element_create("tk4k.Accent.border", "image", "tk4k_acc",
                         ("pressed", "tk4k_acc_press"), ("active", "tk4k_acc_hover"),
                         border=r + 2, padding=(10, 5), sticky="nsew")
    style.element_create("tk4k.Field.border", "image", "tk4k_field",
                         ("focus", "tk4k_field_focus"), ("disabled", "tk4k_field_dis"),
                         border=r + 2, padding=(6, 4), sticky="nsew")
    style.layout("TButton", [("tk4k.Button.border", {"sticky": "nsew", "children": [
        ("Button.padding", {"sticky": "nsew", "children": [("Button.label", {"sticky": "nsew"})]})]})])
    style.layout("Accent.TButton", [("tk4k.Accent.border", {"sticky": "nsew", "children": [
        ("Button.padding", {"sticky": "nsew", "children": [("Button.label", {"sticky": "nsew"})]})]})])
    style.layout("TEntry", [("tk4k.Field.border", {"sticky": "nsew", "children": [
        ("Entry.padding", {"sticky": "nsew", "children": [("Entry.textarea", {"sticky": "nsew"})]})]})])
    style.configure(".", background=bg, foreground=fg, fieldbackground=wbg, bordercolor=border,
                    lightcolor=wbg, darkcolor=wbg, troughcolor=wbg, selectbackground=acc,
                    selectforeground=on_acc, insertcolor=fg, focuscolor=acc, font="TkDefaultFont")
    style.map(".", foreground=[("disabled", dim)], background=[("disabled", bg)])
    style.configure("TButton", anchor="center", foreground=fg)
    style.configure("Accent.TButton", foreground=on_acc)
    style.configure("TEntry", foreground=fg, insertcolor=fg)
    for w in ("TCheckbutton", "TRadiobutton"):
        style.configure(w, background=bg, indicatorbackground=wbg, indicatorforeground=acc,
                        indicatormargin=(0, 0, 6, 0), upperbordercolor=dim, lowerbordercolor=dim,
                        bordercolor=dim, padding=(0, 2))
        style.map(w, background=[("active", bg)], indicatorbackground=[("selected", wbg), ("pressed", hov)])
    style.configure("TCombobox", fieldbackground=wbg, background=wbg, arrowcolor=fg, padding=4)
    style.map("TCombobox", fieldbackground=[("readonly", wbg)], foreground=[("readonly", fg)],
              selectbackground=[("readonly", wbg)], selectforeground=[("readonly", fg)])
    style.configure("TSpinbox", fieldbackground=wbg, background=wbg, arrowcolor=fg, padding=4)
    style.configure("TNotebook", background=bg, borderwidth=0, tabmargins=(0, 0, 0, 0))
    style.configure("TNotebook.Tab", background=bg, foreground=dim, padding=(12, 5), borderwidth=0)
    style.map("TNotebook.Tab", background=[("selected", wbg)], foreground=[("selected", fg)],
              lightcolor=[("selected", acc)])
    style.configure("Treeview", background=wbg, fieldbackground=wbg, foreground=fg, rowheight=24, borderwidth=0)
    style.configure("Treeview.Heading", background=surf, foreground=dim, relief="flat", padding=4)
    style.map("Treeview", background=[("selected", acc)], foreground=[("selected", on_acc)])
    style.configure("Horizontal.TProgressbar", background=acc, troughcolor=wbg, bordercolor=wbg,
                    lightcolor=acc, darkcolor=acc, thickness=8)
    style.configure("Vertical.TProgressbar", background=acc, troughcolor=wbg, bordercolor=wbg,
                    lightcolor=acc, darkcolor=acc, thickness=8)
    for o in ("Horizontal", "Vertical"):
        style.configure(f"{o}.TScrollbar", background=hov, troughcolor=bg, bordercolor=bg, arrowcolor=dim,
                        lightcolor=hov, darkcolor=hov, gripcount=0, arrowsize=12)
        style.map(f"{o}.TScrollbar", background=[("active", act)])
        style.configure(f"{o}.TScale", background=acc, troughcolor=wbg, bordercolor=border, lightcolor=acc,
                        darkcolor=acc)
    style.configure("TLabelframe", background=bg, bordercolor=border)
    style.configure("TLabelframe.Label", background=bg, foreground=dim)
    style.configure("TSeparator", background=border)
    style.configure("Sash", background=border)
    root._tk4k_images = imgs  # keep the PhotoImages alive with the root window


def _has_tk(root) -> bool:
    try:
        return bool(root.tk.call("info", "commands", "winfo"))
    except Exception:  # noqa: BLE001
        return False


def apply(root) -> None:
    """Skin one Tk interpreter (call right after tk.Tk()). Safe to call twice."""
    if getattr(root, "_tk4k_skinned", False) or os.environ.get("TK4K_CLASSIC", "1") == "0":
        return
    if not _has_tk(root):  # tkinter.Tcl() makes a Tcl-only interpreter (no windows): nothing to skin yet
        return
    root._tk4k_skinned = True  # per window object: ids of destroyed interpreters get reused
    t = chosen_theme()
    for step in (_fonts, _option_db, _ttk_theme):
        try:
            step(root, t)
        except Exception as e:  # noqa: BLE001  (a skin must never break the app it is decorating)
            print(f"tk4k.classic: skipped {step.__name__}: {e}", file=sys.stderr)


def install() -> None:
    """Skin every Tk() the program creates from now on. Call before the app makes its first window."""
    global _installed, _orig_tk_init
    if _installed:
        return
    import tkinter
    _orig_tk_init = tkinter.Tk.__init__

    def __init__(self, *a, **k):
        _orig_tk_init(self, *a, **k)
        apply(self)

    tkinter.Tk.__init__ = __init__
    _installed = True


def uninstall() -> None:
    global _installed
    if _installed:
        import tkinter
        tkinter.Tk.__init__ = _orig_tk_init
        _installed = False
