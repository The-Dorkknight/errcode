# Third-party notices

TK 4K itself is Apache-2.0 (see `LICENSE` and `NOTICE`). It contains or links the following.
Full licence texts are in `third_party/licenses/`.

| Component | Used for | Licence | Copyright |
|---|---|---|---|
| Dear ImGui 1.93.0 (trimmed copy in `third_party/imgui`) | drawing widgets | MIT | 2014-2026 Omar Cornut |
| stb_truetype, stb_rectpack, stb_textedit (inside Dear ImGui) | font rasteriser, packing, text editing | MIT or public domain | Sean Barrett |
| SDL 3.4.8 (downloaded at build time, linked statically) | window, input, renderer | zlib | 1997-2026 Sam Lantinga |
| nanobind (build time; its small runtime is linked in) | Python <-> C++ glue | BSD-3-Clause | Wenzel Jakob |
| Inter Regular, Latin subset (`src/tk4k/fonts`) | the default UI font | SIL Open Font License 1.1 | 2016-2023 The Inter Project Authors |

The separate **`tk4k_tk` wheels** in `dist/` (not part of the `tk4k` wheel) redistribute **Tcl/Tk 9.0** (Tcl/Tk licence,
BSD-style; `tk4k_tk/tcl-license.terms`, `tk-license.terms`) and CPython's **tkinter and turtle** (PSF licence,
`tk4k_tk/PYTHON-LICENSE.txt`; one marked 6-line change, described in `tk4k_tk/PATCHED.txt`), taken from python-build-standalone.

The `tk4k` wheel itself does not include Tcl/Tk or tkinter. They are credited because TK 4K borrows their ideas
(a widget tree, geometry managers, variables, `after()`), not their code.

Open item: `src/tk4k/fonts/OFL.txt` was taken from the Debian `fonts-inter` copyright file and still has
Debian's formatting. Replace it with the upstream `OFL.txt` before a public 1.0.

## Optional, not bundled (`tk4k.port`)

| Component | Used for | Licence |
|---|---|---|
| LibCST (`pip install libcst`) | reading and rewriting tkinter source for `python -m tk4k.port` | MIT (some files PSF) |
| segno (`pip install segno`) | QR pictures for the error reports | BSD-3-Clause |
| ErrCode (Matthew Armstrong's own plug-in; not on PyPI yet) | if installed, error reports become ErrCode `EC2-` strings | PolyForm Noncommercial 1.0.0, so it is only ever an optional, separately installed add-on |

Prior art studied, no code copied: tk2ctk (GPL-3.0) and tkupgrade (MIT); see `docs/research/porting-tool/`.
