"""tk4k.port engine: translate a tkinter app into a TK 4K app, with a report.

Research prototype grown into a package (see docs/PORT_TOOL_DESIGN.md). Scope:
  * apps whose UI is built in straight-line module-level code (most tutorial and hobby tools);
  * widgets TK 4K has: Tk, Frame/LabelFrame, Label, Button, Entry, Checkbutton, Scale,
    ttk.Progressbar, ttk.Separator, and StringVar/IntVar/DoubleVar/BooleanVar;
  * pack (any sides, as nested rows/columns) and grid (static row/column numbers).

NOTHING IS DELETED. A widget TK 4K does not have becomes a `ui.Placeholder(...)` (a greyed box that
answers .get() and swallows other calls); any other tkinter call becomes `ui.unsupported(...)`.
Both are recorded in the log, in the exit footer and in the QR error report, so the translated app
always runs and always says what is missing.

  safe   = translated with no loss
  review = translated, but something was approximated (fonts/colours dropped, layout approximated, dialogs -> toasts)
  unsafe = placeholders or unsupported calls are in the output (TK 4K has to grow the widget)
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ._names import STAR

import libcst as cst
from libcst.metadata import MetadataWrapper, PositionProvider, QualifiedName, QualifiedNameProvider, QualifiedNameSource

# ----------------------------------------------------------------------------------- rules (data)
# kind: window | container | widget | var | dialog
RULES = {
    "Tk": {"kind": "window"},
    "Frame": {"kind": "container"}, "ttk.Frame": {"kind": "container"},
    "LabelFrame": {"kind": "container", "title": "text"}, "ttk.LabelFrame": {"kind": "container", "title": "text"},
    "Label": {"kind": "widget", "to": "Label", "opts": {"text": "text", "textvariable": "text"}},
    "ttk.Label": {"kind": "widget", "to": "Label", "opts": {"text": "text", "textvariable": "text"}},
    "Button": {"kind": "widget", "to": "Button", "opts": {"text": "text", "command": "on_click"}},
    "ttk.Button": {"kind": "widget", "to": "Button", "opts": {"text": "text", "command": "on_click"}},
    "Entry": {"kind": "widget", "to": "Entry", "opts": {"textvariable": "var", "show": "password"}},
    "ttk.Entry": {"kind": "widget", "to": "Entry", "opts": {"textvariable": "var", "show": "password"}},
    "Checkbutton": {"kind": "widget", "to": "Checkbox", "opts": {"text": "text", "variable": "var", "command": "on_change0"}},
    "ttk.Checkbutton": {"kind": "widget", "to": "Checkbox", "opts": {"text": "text", "variable": "var", "command": "on_change0"}},
    "Scale": {"kind": "widget", "to": "Slider", "opts": {"from_": "lo", "to": "hi", "variable": "var", "command": "on_change1"}},
    "ttk.Scale": {"kind": "widget", "to": "Slider", "opts": {"from_": "lo", "to": "hi", "variable": "var", "command": "on_change1"}},
    "ttk.Progressbar": {"kind": "widget", "to": "Progress", "opts": {"value": "value", "variable": "value"}},
    "ttk.Separator": {"kind": "widget", "to": "Separator", "opts": {}},
    "StringVar": {"kind": "var", "default": '""'}, "IntVar": {"kind": "var", "default": "0"},
    "DoubleVar": {"kind": "var", "default": "0.0"}, "BooleanVar": {"kind": "var", "default": "False"},
}
COSMETIC = {"font", "fg", "bg", "foreground", "background", "relief", "bd", "borderwidth", "padx", "pady",
            "anchor", "justify", "width", "height", "cursor", "style", "orient", "length", "wraplength",
            "highlightthickness", "activebackground", "activeforeground", "takefocus", "image", "compound",
            "mode", "maximum", "underline", "selectcolor", "indicatoron", "tickinterval", "resolution", "showvalue",
            "bootstyle"}
LAYOUT_KEEP = {"side", "row", "column"}  # used to build the tree; other geometry options are approximated
PLACEHOLDER = {"kind": "placeholder", "to": "Placeholder"}
PH_DEFAULT = {"Spinbox": '"0"', "ttk.Spinbox": '"0"', "Combobox": '""', "ttk.Combobox": '""', "Listbox": "()"}
# tkinter constants -> the plain values they stand for
CONSTS = {n: n.lower() for n in (
    "END LEFT RIGHT TOP BOTTOM BOTH X Y N S E W NW NE SW SE NSEW NS EW CENTER NORMAL DISABLED ACTIVE HORIZONTAL "
    "VERTICAL INSERT SEL WORD CHAR NONE SUNKEN RAISED FLAT GROOVE RIDGE SOLID ANCHOR SINGLE BROWSE MULTIPLE "
    "EXTENDED READONLY").split()}
CONSTS.update({"YES": "1", "NO": "0", "TRUE": "1", "FALSE": "0"})
# methods the translated widgets understand; any other method call becomes ui.unsupported(...)
OK_METHODS = {"Entry": {"get", "delete", "insert", "config", "configure", "destroy"},
              "Slider": {"get", "set", "config", "configure", "destroy"}}
OK_WINDOW = {"after", "after_idle", "after_cancel", "toast", "quit", "run", "post", "set_theme"}
ASK = ("messagebox.askyesno", "messagebox.askokcancel", "messagebox.askretrycancel", "messagebox.askquestion",
       "messagebox.askyesnocancel")
MSGBOX = ("messagebox.showinfo", "messagebox.showwarning", "messagebox.showerror")


def tkname(qnames) -> str | None:
    """'tkinter.ttk.Button' -> 'ttk.Button', 'tkinter.Button' -> 'Button', 'tkinter.messagebox.showinfo' -> ..."""
    if callable(qnames):  # newer LibCST hands back lazy values
        qnames = qnames()
    for q in qnames or ():
        n = q.name
        if n.startswith("tkinter.ttk."):
            return "ttk." + n[len("tkinter.ttk."):]
        if n.startswith("tkinter.messagebox."):
            return "messagebox." + n[len("tkinter.messagebox."):]
        if n.startswith("tkinter.filedialog.") or n.startswith("tkinter.simpledialog."):
            return n[len("tkinter."):]
        if n.startswith("tkinter."):
            return n[len("tkinter."):]
    return None


@dataclass
class W:
    name: str                 # variable name ("" for anonymous widgets)
    cls: str                  # 'Label', 'ttk.Progressbar', ...
    rule: dict | None
    master: str | None
    args: list                # positional cst.Arg after master
    kw: dict                  # option -> cst expression
    line: int
    geom: str | None = None   # 'pack' | 'grid' | 'place'
    gopts: dict = field(default_factory=dict)
    order: int = 0            # geometry call order (pack order matters)
    children: list = field(default_factory=list)
    colweights: dict = field(default_factory=dict)


class Report:
    def __init__(self):
        self.notes: list[dict] = []
        self.translated = 0

    def add(self, level, line, msg):
        self.notes.append({"level": level, "line": line, "msg": msg})

    @property
    def grade(self):
        levels = {n["level"] for n in self.notes}
        return "unsafe" if "todo" in levels else "review" if "approx" in levels else "safe"


def code_of(node) -> str:
    return cst.Module(body=[]).code_for_node(node)


def const_str(e):
    return e.evaluated_value if isinstance(e, cst.SimpleString) else None


def const_int(e):
    if isinstance(e, cst.Integer):
        return int(e.value)
    s = const_str(e)
    return int(s) if s is not None and s.isdigit() else None


class StarQ:
    """QualifiedNameProvider results, plus names that come from `from tkinter import *` style imports.

    LibCST can't know what a star import brings in, so those names are looked up in a static table
    (generated from tkinter's own __all__). Later star imports win, like in Python (ttk's Label beats tk's).
    """

    def __init__(self, real, module):
        self.real = real
        self.mods = []
        for stmt in module.body:
            for s in getattr(stmt, "body", ()) if isinstance(stmt, cst.SimpleStatementLine) else ():
                if isinstance(s, cst.ImportFrom) and isinstance(s.names, cst.ImportStar) and s.module is not None \
                        and not s.relative:
                    m = code_of(s.module)
                    if m in STAR:
                        self.mods.append(m)

    def get(self, node, default=()):
        got = self.real.get(node, default)
        if callable(got):
            got = got()
        if got or not self.mods or not isinstance(node, cst.Name):
            return got
        for m in reversed(self.mods):
            if node.value in STAR[m]:
                return {QualifiedName(f"{m}.{node.value}", QualifiedNameSource.IMPORT)}
        return got


class Porter:
    def __init__(self, src: str, app: str = ""):
        self.app = app
        self.src = src
        self.mod = cst.parse_module(src)
        self.wrapper = MetadataWrapper(self.mod)
        self.q = StarQ(self.wrapper.resolve(QualifiedNameProvider), self.wrapper.module)
        self.pos = self.wrapper.resolve(PositionProvider)
        self.m = self.wrapper.module
        self.rep = Report()
        self.widgets: dict[str, W] = {}
        self.anon: list[W] = []
        self.window: W | None = None
        self.vars: dict[str, str] = {}
        self.unsupported: set[str] = set()
        self.todo_stmts: set[int] = set()
        self.ui_stmts: set[int] = set()       # indices of top-level statements that become the UI block
        self.title = None
        self.size = None
        self.geo_order = 0
        self.class_ui = False
        self.imperative = False

    def const_name(self, e):
        """tkinter constant (tk.LEFT, END ...) -> its plain value, else None."""
        if isinstance(e, (cst.Attribute, cst.Name)):
            n = tkname(self.q.get(e, ()))
            if n:
                tail = n.split(".")[-1]
                if tail in CONSTS:
                    return CONSTS[tail]
        return None

    def cs(self, e):
        """A constant string from a literal or a tkinter constant."""
        return const_str(e) if const_str(e) is not None else self.const_name(e)

    def line(self, node):
        try:
            return self.pos[node].start.line
        except KeyError:
            return 0

    def cls_of_call(self, call):
        if isinstance(call, cst.Call):
            n = tkname(self.q.get(call.func, ()))
            return n
        return None

    # ------------------------------------------------------------------ pass 1: understand the UI
    def analyse(self):
        if any(isinstance(s, cst.ClassDef) and "tkinter" in code_of(s) for s in self.m.body):
            pass
        for i, stmt in enumerate(self.m.body):
            if isinstance(stmt, cst.ClassDef):
                for b in stmt.bases:
                    if tkname(self.q.get(b.value, ())):
                        self.class_ui = True
            if not isinstance(stmt, cst.SimpleStatementLine) or len(stmt.body) != 1:
                continue
            s = stmt.body[0]
            if isinstance(s, cst.Assign) and len(s.targets) == 1 and isinstance(s.targets[0].target, cst.Name):
                name = s.targets[0].target.value
                cls = self.cls_of_call(s.value)
                if cls:
                    self._creation(i, name, cls, s.value)
            elif isinstance(s, cst.Expr) and isinstance(s.value, cst.Call):
                call = s.value
                f = call.func
                if isinstance(f, cst.Attribute) and isinstance(f.value, cst.Call) and self.cls_of_call(f.value) \
                        and f.attr.value in ("pack", "grid", "place"):
                    w = self._creation(i, "", self.cls_of_call(f.value), f.value)
                    if w:
                        self._geometry(i, w, f.attr.value, call)
                elif isinstance(f, cst.Attribute) and isinstance(f.value, cst.Name):
                    obj, meth = f.value.value, f.attr.value
                    if obj in self.widgets and meth in ("pack", "grid", "place"):
                        self._geometry(i, self.widgets[obj], meth, call)
                    elif self.window and obj == self.window.name and meth == "title" and call.args:
                        self.title = call.args[0].value
                        self.ui_stmts.add(i)
                    elif self.window and obj == self.window.name and meth == "geometry" and call.args:
                        g = const_str(call.args[0].value) or ""
                        try:
                            wh = g.split("+")[0].split("x")
                            self.size = (int(wh[0]), int(wh[1]))
                        except (ValueError, IndexError):
                            self.rep.add("approx", self.line(stmt), f"geometry {g!r} not understood; default size used")
                        self.ui_stmts.add(i)
                    elif obj in self.widgets and meth in ("columnconfigure", "grid_columnconfigure") and call.args:
                        col = const_int(call.args[0].value)
                        wt = next((const_int(a.value) for a in call.args if a.keyword and a.keyword.value == "weight"), None)
                        if col is not None and wt is not None:
                            self.widgets[obj].colweights[col] = wt
                            self.ui_stmts.add(i)
                    elif obj in self.widgets and meth in ("rowconfigure", "grid_rowconfigure", "pack_propagate",
                                                          "grid_propagate"):
                        self.rep.add("approx", self.line(stmt), f"{obj}.{meth}(...) has no TK 4K equivalent yet; dropped")
                        self.ui_stmts.add(i)

    def _creation(self, i, name, cls, call):
        rule = RULES.get(cls)
        ln = self.line(call)
        if rule and rule["kind"] == "var":
            self.vars[name] = cls
            return None
        if cls.startswith("messagebox.") or "dialog" in cls:
            return None
        if not rule:
            # a widget (or helper object) TK 4K does not have yet: keep its place with a placeholder
            if name:
                self.unsupported.add(name)
            self.rep.add("todo", ln, f"{cls} is not in TK 4K yet: {('`' + name + '`') if name else 'anonymous widget'} "
                         "replaced by a placeholder")
            rule = PLACEHOLDER
        args = list(call.args)
        master = None
        if args and args[0].keyword is None and isinstance(args[0].value, cst.Name):
            master = args[0].value.value
            args = args[1:]
        kw = {}
        for a in list(args):
            if a.keyword:
                kw[a.keyword.value] = a.value
                args.remove(a)
        if "master" in kw and isinstance(kw["master"], cst.Name):
            master = kw.pop("master").value
        w = W(name, cls, rule, master, args, kw, ln)
        if rule is PLACEHOLDER:
            w.kw = {k: v for k, v in kw.items() if k in ("from_", "value", "values")}
            w.args = []
        if rule["kind"] == "window":
            self.window = w
        elif name:
            if name in self.widgets:                 # the same variable name re-used: keep the earlier widget too
                self.anon.append(self.widgets[name])
                self.rep.add("approx", ln, f"{name!r} is assigned more than once; both widgets are kept")
            self.widgets[name] = w
        else:
            self.anon.append(w)
        self.ui_stmts.add(i)
        return w

    def _geometry(self, i, w, how, call):
        w.geom = how
        self.geo_order += 1
        w.order = self.geo_order
        for a in call.args:
            if a.keyword:
                w.gopts[a.keyword.value] = a.value
        self.ui_stmts.add(i)
        if how == "place":
            self.rep.add("approx", w.line, "place() has no TK 4K equivalent yet: widget put in normal flow")

    # ------------------------------------------------------------------ pass 2: build the TK 4K tree
    def tree(self):
        all_w = list(self.widgets.values()) + self.anon
        root_name = self.window.name if self.window else None
        by_master = {}
        valid = {n for n, w in self.widgets.items() if w.rule["kind"] != "placeholder"} | {root_name}
        for w in all_w:
            if w.master not in valid:
                if w.master is not None:
                    self.rep.add("approx", w.line, f"{w.name or w.cls}: parent {w.master!r} is not a TK 4K container; "
                                 "moved to the window")
                w.master = root_name
            by_master.setdefault(w.master, []).append(w)
        for w in all_w:
            w.children = by_master.get(w.name, []) if w.name else []
        top = by_master.get(root_name, [])
        for w in all_w:
            if w.geom is None and w.rule["kind"] not in ("container", "placeholder"):
                self.rep.add("approx", w.line, f"{w.name or w.cls} is never packed or gridded; shown anyway")
        return top

    def emit_widget(self, w, ind, dynamic=False):
        rule = w.rule
        if rule is PLACEHOLDER:
            dflt = PH_DEFAULT.get(w.cls, '""')
            if "from_" in w.kw and w.cls.endswith("Spinbox"):
                dflt = code_of(w.kw["from_"])
            hidden = ", visible=False" if w.geom is None else ""
            self.rep.translated += 0
            return [f"{ind}{w.name + ' = ' if w.name else ''}ui.Placeholder({w.cls!r}, name={w.name!r}, "
                    f"default={dflt}, line={w.line}{hidden})"]
        opts = []
        pos = []
        for k, v in w.kw.items():
            tgt = rule.get("opts", {}).get(k)
            vc = code_of(v)
            if self.window and vc == f"{self.window.name}.destroy":
                vc = f"{self.window.name}.quit"
            if tgt == "text":
                pos.insert(0, vc)
            elif tgt == "on_change0":
                opts.append(f"on_change=lambda _v: {vc}()")
            elif tgt == "on_change1":
                opts.append(f"on_change=lambda _v: {vc}(_v)")
            elif tgt == "password":
                opts.append("password=True")
            elif tgt:
                opts.append(f"{tgt}={vc}")
            elif w.cls == "ttk.Progressbar" and k == "maximum":
                if dynamic:
                    opts.append(f"maximum={vc}")  # run-time: Progress divides by it itself
            elif k == "orient" and self.cs(v) == "horizontal":
                pass  # TK 4K sliders are horizontal
            elif k in COSMETIC:
                self.rep.add("approx", w.line, f"{w.cls} option {k}= dropped (TK 4K theme decides)")
            else:
                self.rep.add("approx", w.line, f"{w.cls} option {k}= has no TK 4K equivalent; dropped")
        if w.cls == "ttk.Progressbar" and dynamic:
            if not any(o.startswith("maximum=") for o in opts):
                opts.append("maximum=100")
        elif w.cls == "ttk.Progressbar":
            mx = w.kw.get("maximum")
            self.maxima[w.name] = code_of(mx) if mx is not None else "100"
            if not any(o.startswith("value=") for o in opts):
                pos.insert(0, "0.0")
        for a in w.args:
            pos.append(code_of(a.value))
        call = f"ui.{rule['to']}({', '.join(pos + opts)})"
        self.rep.translated += 1
        return [f"{ind}{w.name + ' = ' if w.name else ''}{call}"]

    def emit_container(self, kids, ind, how, owner=None, box_name=None):
        """kids: widgets managed in one parent. Returns lines building them inside a TK 4K container."""
        out = []
        mode = "grid" if any(k.geom == "grid" for k in kids) else "pack"
        if mode == "grid":
            cells = {}
            hidden = [k for k in kids if k.geom != "grid"]
            for k in hidden:
                out += self.emit_node(k, ind)
            kids = [k for k in kids if k.geom == "grid"]
            for k in kids:
                r = const_int(k.gopts.get("row")) if "row" in k.gopts else 0
                c = const_int(k.gopts.get("column")) if "column" in k.gopts else 0
                if r is None or c is None:
                    self.rep.add("todo", k.line, "grid row/column is not a constant: cannot place it")
                    continue
                if any(x in k.gopts for x in ("columnspan", "rowspan")):
                    self.rep.add("approx", k.line, "columnspan/rowspan not in TK 4K Grid yet: one cell used")
                cells[(r, c)] = k
            ncols = max((c for _, c in cells), default=0) + 1
            nrows = max((r for r, _ in cells), default=-1) + 1
            weights = [owner.colweights.get(i, 0) if owner else 0 for i in range(ncols)]
            if not any(weights):
                weights = [0] * (ncols - 1) + [1]
            head = f"{ind}with ui.Grid(columns={ncols}, weights={weights})" + (f" as {box_name}:" if box_name else ":")
            out.append(head)
            for r in range(nrows):
                for c in range(ncols):
                    k = cells.get((r, c))
                    if k is None:
                        out.append(f"{ind}    ui.Spacer()")
                    else:
                        out += self.emit_node(k, ind + "    ")
            return out
        # pack: the packer cuts strips off the sides of the remaining space, in order -> nested rows/columns
        seq = sorted([k for k in kids if k.geom in ("pack", "place", None)], key=lambda k: (k.order == 0, k.order))
        return self._emit_pack(seq, ind, box_name)

    def _emit_pack(self, seq, ind, box_name=None):
        if not seq:
            return [f"{ind}with ui.Column()" + (f" as {box_name}:" if box_name else ":"), f"{ind}    pass"]

        def side(k):
            s = self.cs(k.gopts.get("side")) if "side" in k.gopts else None
            return (s or "top").lower()

        axis_v = side(seq[0]) in ("top", "bottom")
        start, end, rest = [], [], []
        for idx, k in enumerate(seq):
            sv = side(k) in ("top", "bottom")
            if sv != axis_v:
                rest = seq[idx:]
                break
            (start if side(k) in ("top", "left") else end).append(k)
            for opt in ("fill", "expand", "ipadx", "ipady"):
                if opt in k.gopts:
                    self.rep.add("approx", k.line, f"pack {opt}= approximated (TK 4K rows/columns size children themselves)")
        if end:
            self.rep.add("approx", end[0].line, "bottom/right-packed widgets come after the others; not pinned to the far edge yet")
        out = [f"{ind}with ui.{'Column' if axis_v else 'Row'}()" + (f" as {box_name}:" if box_name else ":")]
        for k in start:
            out += self.emit_node(k, ind + "    ")
        if rest:
            out += self._emit_pack(rest, ind + "    ")
        for k in reversed(end):
            out += self.emit_node(k, ind + "    ")
        return out

    def emit_node(self, w, ind):
        if w.rule["kind"] == "container":
            lines = []
            title = w.kw.get("text")
            if title is not None:
                self.rep.add("approx", w.line, "LabelFrame title shown as a label above its contents")
            body = self.emit_container(w.children, ind, None, owner=w, box_name=w.name or None)
            if title is not None:
                body.insert(1, f"{ind}    ui.Label({code_of(title)}, dim=True)")
            self.rep.translated += 1
            return lines + body
        return self.emit_widget(w, ind)

    def ui_block(self, top):
        self.maxima = {}
        t = code_of(self.title) if self.title is not None else '"TK 4K"'
        size = f", size={self.size}" if self.size else ""
        name = self.window.name if self.window else "root"
        lines = [f"with ui.Window({t}{size}) as {name}:"]
        lines += self.emit_container(top, "    ", None)
        return lines

    # ------------------------------------------------------------------ pass 3: rewrite the rest
    def _count_creations(self) -> int:
        n = [0]
        porter = self

        class V(cst.CSTVisitor):
            def visit_Call(self, c):
                k = tkname(porter.q.get(c.func, ()))
                if k and (RULES.get(k, {}).get("kind") in ("widget", "container") or (k not in RULES and k[:1].isupper()
                          and not k.endswith("Var") and not k.startswith("messagebox") and "dialog" not in k)):
                    n[0] += 1
        self.m.visit(V())
        return n[0]

    def run(self):
        self.analyse()
        static = len(self.widgets) + len(self.anon)
        if self.class_ui or self._count_creations() > static or (not self.window and self._count_creations()):
            return self.run_imperative()
        if not self.window:
            self.rep.add("todo", 0, "no tkinter Tk() window found at module level; nothing translated "
                         "(try python -m tk4k.classic for the skin only)")
            return None
        top = self.tree()
        block = self.ui_block(top)
        last = max(self.ui_stmts)
        body = list(self.m.body)
        widget_names = set(self.widgets) | {self.window.name}
        new_body, moved_after = [], []
        for i, stmt in enumerate(body):
            if i in self.ui_stmts:
                if i == last:
                    new_body += [cst.parse_statement(s + "\n") for s in ["\n".join(block)]]
                    new_body += moved_after
                continue
            if self._is_tk_import(stmt):
                if not any(isinstance(n, cst.SimpleStatementLine) and "import tk4k as ui" in code_of(n) for n in new_body):
                    new_body.append(cst.parse_statement("import tk4k as ui\n"))
                    new_body.append(cst.parse_statement(f"ui.install_alerts(app={self.app!r})\n"))
                continue
            if self._var_assign(stmt):
                new_body.append(self._var_assign(stmt))
                continue
            min_ui = min(self.ui_stmts)
            if min_ui < i < last and isinstance(stmt, cst.SimpleStatementLine) and self._touches(stmt, widget_names):
                moved_after.append(stmt)   # e.g. `bill.insert(0, "42")` right after the widget: run it after the UI exists
                continue
            new_body.append(stmt)
        mod = self.m.with_changes(body=new_body)
        mod = mod.visit(Rewriter(self))
        return mod.code

    def run_imperative(self):
        """Keep the program's own structure (classes, functions, loops, pack/grid calls) and swap the names.

        Widgets are created where the program creates them, with parent=...; pack/grid options are
        used at run time by TK 4K (side, fill, row, column, columnspan, sticky).
        """
        self.imperative = True
        self.rep.add("approx", 0, "imperative mode: the program's structure is kept; pack/grid are interpreted at run "
                     "time (side, fill, row, column, columnspan, sticky); other options are ignored")
        body = []
        for stmt in self.m.body:
            if self._is_tk_import(stmt):
                if not any(isinstance(n, cst.SimpleStatementLine) and "import tk4k as ui" in code_of(n) for n in body):
                    body.append(cst.parse_statement("import tk4k as ui\n"))
                    body.append(cst.parse_statement(f"ui.install_alerts(app={self.app!r})\n"))
                continue
            body.append(stmt)
        mod = self.m.with_changes(body=body)
        mod = mod.visit(Rewriter(self, imperative=True))
        return mod.code

    def _is_tk_import(self, stmt):
        if isinstance(stmt, cst.SimpleStatementLine) and len(stmt.body) == 1:
            s = stmt.body[0]
            c = code_of(s)
            if isinstance(s, (cst.Import, cst.ImportFrom)) and ("tkinter" in c or "Tkinter" in c):
                return True
        return False

    def _var_assign(self, stmt):
        if isinstance(stmt, cst.SimpleStatementLine) and len(stmt.body) == 1 and isinstance(stmt.body[0], cst.Assign):
            s = stmt.body[0]
            cls = self.cls_of_call(s.value)
            if cls and RULES.get(cls, {}).get("kind") == "var":
                val = next((code_of(a.value) for a in s.value.args if a.keyword and a.keyword.value == "value"), None)
                if val is None:
                    pos = [a for a in s.value.args if a.keyword is None]
                    val = code_of(pos[1].value) if len(pos) > 1 else RULES[cls]["default"]
                tgt = code_of(s.targets[0].target)
                self.rep.translated += 1
                return stmt.with_changes(body=[cst.parse_statement(f"{tgt} = ui.Var({val})\n").body[0]])
        return None

    def _touches(self, stmt, names):
        found = []

        class V(cst.CSTVisitor):
            def visit_Name(self, n):
                if n.value in names:
                    found.append(n.value)
        stmt.visit(V())
        return bool(found)


class Rewriter(cst.CSTTransformer):
    """Rewrites uses of widgets in the code that remains (callbacks, set-up lines).

    Nothing is deleted: anything TK 4K cannot do becomes a call to ui.unsupported(...), which logs it
    at run time and returns a harmless null object, so the program keeps going and says what it skipped.
    """

    def __init__(self, p: Porter, imperative: bool = False):
        self.p = p
        self.imp = imperative
        self.kinds = {n: w.rule.get("to") for n, w in p.widgets.items()}
        self.win = p.window.name if p.window else "None"
        self.skip: set[int] = set()
        self.dyn: set[str] = set()       # variables holding widgets created inside functions / loops
        self.dyn_noted = False

    # ---- helpers
    def _unsup(self, orig, text):
        ln = self.p.line(orig)
        self.p.rep.add("todo", ln, f"{text} is not supported yet: replaced by ui.unsupported(...)")
        return cst.parse_expression(f"ui.unsupported({text!r}, {ln})")

    def _dyn_note(self, orig):
        if not self.dyn_noted:
            self.dyn_noted = True
            self.p.rep.add("approx", self.p.line(orig), "widgets created inside functions/loops are appended in "
                           "creation order; their pack/grid/place options are ignored")

    def _master_code(self, e):
        return code_of(e) if isinstance(e, (cst.Name, cst.Attribute)) else None

    def _dynamic_widget(self, orig, node, cls):
        """tk.Label(parent, text=...) inside a function, loop or class -> ui.Label(..., parent=parent)."""
        rule = RULES.get(cls) or PLACEHOLDER
        args = list(node.args)
        master = None
        if args and args[0].keyword is None and self._master_code(args[0].value):
            master = self._master_code(args[0].value)
            args = args[1:]
        kw = {a.keyword.value: a.value for a in args if a.keyword}
        if "master" in kw and self._master_code(kw["master"]):
            master = self._master_code(kw.pop("master"))
        pos = [a for a in args if not a.keyword]
        ln = self.p.line(orig)
        if not self.imp:
            self._dyn_note(orig)
        known = master and (self.imp or master in self.p.widgets or master == self.win or master in self.dyn)
        parent = f"parent={master}" if known else (f"parent={self.win}" if self.win != "None" else "")
        if rule is PLACEHOLDER:
            self.p.rep.add("todo", ln, f"{cls} is not in TK 4K yet: replaced by a placeholder")
            dflt = PH_DEFAULT.get(cls, '""')
            ex = ", " + parent if parent else ""
            return cst.parse_expression(f"ui.Placeholder({cls!r}, name='', default={dflt}, line={ln}{ex})")
        if rule["kind"] == "container":
            self.p.rep.translated += 1
            t = ""
            if "text" in kw:
                t = f", text={code_of(kw['text'])}"
            ex = (", " + parent) if parent else ""
            return cst.parse_expression(f"ui.Frame({ex[2:]}{t})" if ex else f"ui.Frame({t[2:]})")
        w = W("", cls, rule, master, pos, kw, ln)
        line = self.p.emit_widget(w, "", dynamic=True)[0]
        assert line.endswith(")")
        extra = parent
        sep = "" if (line.endswith("()") or not extra) else ", "
        return cst.parse_expression(line[:-1] + sep + extra + ")")

    def _imp_call(self, orig, node):
        n = tkname(self.p.q.get(orig.func, ()))
        if not n:
            return None
        last = n.split(".")[-1]
        if last[:1].islower() and n not in MSGBOX and n not in ASK and n != "mainloop":
            return None  # a method call such as Button(...).pack() or var.get(): left for the run-time layer
        if n == "Tk":
            return cst.parse_expression("ui.Window()")
        if n in MSGBOX:
            a = [code_of(x.value) for x in node.args if not x.keyword]
            msg = a[1] if len(a) > 1 else (a[0] if a else '""')
            self.p.rep.add("approx", self.p.line(orig), f"{n} became a toast (it no longer waits for OK)")
            return cst.parse_expression(f"ui.toast({msg})")
        if n in ASK:
            a = [code_of(x.value) for x in node.args if not x.keyword]
            msg = a[1] if len(a) > 1 else (a[0] if a else '""')
            self.p.rep.add("approx", self.p.line(orig), f"{n} cannot wait for an answer yet: returns True")
            return cst.parse_expression(f"ui.ask({msg})")
        if n == "mainloop":
            return cst.parse_expression("ui.mainloop()")
        if RULES.get(n, {}).get("kind") == "var":
            return self._var_expr(orig, node, n)
        if RULES.get(n, {}).get("kind") in ("widget", "container") or (
                n not in RULES and n[:1].isupper() and "Var" not in n and "dialog" not in n):
            return self._dynamic_widget(orig, node, n)
        return self._unsup(orig, f"tkinter.{n}(...)")

    def visit_ClassDef(self, n):
        for b in n.bases:
            self.skip.add(id(b.value))
        return True

    def leave_ClassDef(self, orig, node):
        if not self.imp:
            return node
        bases = []
        for b, ob in zip(node.bases, orig.bases):
            k = tkname(self.p.q.get(ob.value, ()))
            if k == "Tk":
                bases.append(b.with_changes(value=cst.parse_expression("ui.Window")))
            elif k and RULES.get(k, {}).get("kind") == "container":
                bases.append(b.with_changes(value=cst.parse_expression("ui.Frame")))
            elif k and RULES.get(k, {}).get("kind") == "widget":
                bases.append(b.with_changes(value=cst.parse_expression("ui." + RULES[k]["to"])))
            elif k:
                self.p.rep.add("todo", self.p.line(orig), f"class {orig.name.value} subclasses tkinter.{k}, which TK 4K lacks")
                bases.append(b.with_changes(value=cst.parse_expression("ui.Frame")))
            else:
                bases.append(b)
        return node.with_changes(bases=bases)

    def _var_expr(self, orig, node, cls):
        val = next((code_of(a.value) for a in node.args if a.keyword and a.keyword.value == "value"), None)
        if val is None:
            pos = [a for a in node.args if a.keyword is None]
            val = code_of(pos[-1].value) if len(pos) > 1 else RULES[cls]["default"]
        return cst.parse_expression(f"ui.Var({val})")

    # ---- don't look inside imports; remember which nodes are the left side of a call / dotted name
    def visit_Assign(self, n):
        # remember variables that will hold a dynamically created TK 4K widget, so name.pack() on them can be dropped
        if isinstance(n.value, cst.Call) and len(n.targets) == 1 and isinstance(n.targets[0].target, cst.Name):
            c = tkname(self.p.q.get(n.value.func, ()))
            if c and RULES.get(c, {}).get("kind") in ("widget", "container"):
                self.dyn.add(n.targets[0].target.value)
        return True

    def visit_Import(self, n):
        return False

    def visit_ImportFrom(self, n):
        return False

    def visit_Call(self, n):
        self.skip.add(id(n.func))
        return True

    def visit_Attribute(self, n):
        self.skip.add(id(n.value))
        return True

    def _literal(self, c):
        return cst.parse_expression(c if c.isdigit() else repr(c))

    def leave_Name(self, orig, node):
        if id(orig) in self.skip:
            return node
        c = self.p.const_name(orig)
        return self._literal(c) if c is not None else node

    def leave_Attribute(self, orig, node):
        if isinstance(node.value, cst.Name) and node.value.value == self.win and node.attr.value == "destroy":
            return node.with_changes(attr=cst.Name("quit"))
        if id(orig) in self.skip:
            return node
        c = self.p.const_name(orig)
        if c is not None:
            return self._literal(c)
        n = tkname(self.p.q.get(orig, ()))
        if n:
            return self._unsup(orig, f"tkinter.{n}")
        return node

    def leave_Call(self, orig, node):
        f = node.func
        if self.imp:
            r = self._imp_call(orig, node)
            return node if r is None else r
        # layout calls on dynamically created widgets: they are appended in creation order, so the call is dropped
        if isinstance(f, cst.Attribute) and f.attr.value in ("pack", "grid", "place"):
            inner = f.value
            if isinstance(inner, cst.Call) and isinstance(orig.func.value, cst.Call) and \
                    RULES.get(tkname(self.p.q.get(orig.func.value.func, ())) or "", {}).get("kind") in ("widget", "container"):
                self._dyn_note(orig)
                return inner
            if isinstance(inner, cst.Name) and (inner.value in self.dyn or (
                    inner.value in self.kinds and self.kinds[inner.value] not in (None, "Placeholder"))):
                self._dyn_note(orig)
                return cst.parse_expression("None")
        n = tkname(self.p.q.get(orig.func, ()))
        if n:
            if n in MSGBOX:
                a = [code_of(x.value) for x in node.args if not x.keyword]
                msg = a[1] if len(a) > 1 else (a[0] if a else '""')
                self.p.rep.add("approx", self.p.line(orig), f"{n} became a toast (it no longer waits for OK)")
                return cst.parse_expression(f"{self.win}.toast({msg})")
            if n == "mainloop":
                return cst.parse_expression(f"{self.win}.run()")
            if RULES.get(n, {}).get("kind") == "var":
                return self._var_expr(orig, node, n)
            if RULES.get(n, {}).get("kind") in ("widget", "container"):
                return self._dynamic_widget(orig, node, n)
            return self._unsup(orig, f"tkinter.{n}(...)")
        if isinstance(f, cst.Attribute) and isinstance(f.value, cst.Name):
            obj, meth = f.value.value, f.attr.value
            if obj == self.win:
                if meth == "mainloop":
                    return cst.parse_expression(f"{obj}.run()")
                if meth in ("destroy", "quit"):
                    return cst.parse_expression(f"{obj}.quit()")
                if meth not in OK_WINDOW:
                    return self._unsup(orig, f"{obj}.{meth}(...)")
                return node
            kind = self.kinds.get(obj)
            if kind and kind != "Placeholder":
                if kind == "Entry" and meth == "get" and not node.args:
                    return cst.parse_expression(f"{obj}.text")
                if kind == "Slider" and meth == "get" and not node.args:
                    return cst.parse_expression(f"{obj}.value")
                if meth not in OK_METHODS.get(kind, {"config", "configure", "destroy"}):
                    return self._unsup(orig, f"{obj}.{meth}(...)")
        return node

    def leave_SimpleStatementLine(self, orig, node):
        if len(node.body) != 1:
            return node
        s = node.body[0]
        if isinstance(s, cst.Expr) and isinstance(s.value, cst.Call) and isinstance(s.value.func, cst.Attribute) \
                and isinstance(s.value.func.value, cst.Name):
            obj, meth, args = s.value.func.value.value, s.value.func.attr.value, s.value.args
            kind = self.kinds.get(obj)
            if kind == "Entry" and meth == "delete":
                return node.with_changes(body=[cst.parse_statement(f'{obj}.text = ""\n').body[0]])
            if kind == "Entry" and meth == "insert" and len(args) == 2:
                self.p.rep.add("approx", 0, f"{obj}.insert(...) became a full text assignment")
                return node.with_changes(body=[cst.parse_statement(f"{obj}.text = {code_of(args[1].value)}\n").body[0]])
            if kind == "Slider" and meth == "set" and args:
                return node.with_changes(body=[cst.parse_statement(f"{obj}.value = {code_of(args[0].value)}\n").body[0]])
            if kind and kind != "Placeholder" and meth in ("config", "configure"):
                outs = []
                for a in args:
                    if not a.keyword:
                        continue
                    k, v = a.keyword.value, code_of(a.value)
                    if k in ("text", "textvariable"):
                        outs.append(f"{obj}.text = {v}")
                    elif k == "state":
                        outs.append(f"{obj}.enabled = ({v}) != 'disabled'")
                    elif k in COSMETIC:
                        self.p.rep.add("approx", 0, f"{obj}.config({k}=...) dropped (theme decides)")
                    else:
                        outs.append(f"ui.unsupported({obj + '.' + meth + '(' + k + '=...)'!r}, {self.p.line(orig)})")
                        self.p.rep.add("todo", self.p.line(orig), f"{obj}.{meth}({k}=...) is not supported yet")
                if not outs:
                    return cst.SimpleStatementLine(body=[cst.Pass()])
                if len(outs) == 1:
                    return node.with_changes(body=[cst.parse_statement(outs[0] + "\n").body[0]])
                return cst.FlattenSentinel([cst.parse_statement(o + "\n") for o in outs])
        if isinstance(s, cst.Assign) and len(s.targets) == 1 and isinstance(s.targets[0].target, cst.Subscript):
            sub = s.targets[0].target
            if isinstance(sub.value, cst.Name) and self.kinds.get(sub.value.value) not in (None, "Placeholder"):
                key = const_str(sub.slice[0].slice.value) if isinstance(sub.slice[0].slice, cst.Index) else None
                obj = sub.value.value
                if key == "value" and self.kinds[obj] == "Progress":
                    mx = self.p.maxima.get(obj, "100")
                    return node.with_changes(body=[cst.parse_statement(f"{obj}.value = ({code_of(s.value)}) / {mx}\n").body[0]])
                if key in ("text", "textvariable"):
                    return node.with_changes(body=[cst.parse_statement(f"{obj}.text = {code_of(s.value)}\n").body[0]])
                if key == "state":
                    return node.with_changes(body=[cst.parse_statement(
                        f"{obj}.enabled = ({code_of(s.value)}) != 'disabled'\n").body[0]])
                self.p.rep.add("todo", self.p.line(orig), f"{obj}[{key!r}] = ... is not supported yet")
                return node.with_changes(body=[cst.parse_statement(
                    f"ui.unsupported({obj + '[' + repr(key) + ']'!r}, {self.p.line(orig)})\n").body[0]])
        return node
