"""tk4k.port: translate tkinter apps into TK 4K apps, and say loudly what could not be done.

    python -m tk4k.port my_app.py            # writes my_app_tk4k.py + report + log (+ QR if something is wrong)
    python -m tk4k.port src/ --check         # grade every tkinter file in a folder, write nothing

    from tk4k.port import port_file
    result = port_file("my_app.py")
    result.grade, result.notes, result.payload

Nothing is silently dropped: unsupported widgets become placeholders, unsupported calls become
`ui.unsupported(...)`, and every problem goes to the log, the JSON report, stderr and a QR error report.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Optional

from .. import _alerts

__all__ = ["Result", "port_file", "port_source", "main_exit_code"]


@dataclass
class Result:
    source: str
    out_path: Optional[str] = None           # translated file (None if nothing was written)
    grade: str = "failed"                    # safe | review | unsafe | failed | skipped
    translated: int = 0
    notes: list = field(default_factory=list)  # [{"level": "todo"|"approx", "line": int, "msg": str}]
    error: Optional[str] = None              # set when the translator itself failed
    report_path: Optional[str] = None
    log_path: Optional[str] = None
    qr_path: Optional[str] = None
    payload: str = ""                        # the report as one short string (EC2-... with ErrCode, else TK4K1-...)
    seconds: float = 0.0

    @property
    def todo(self) -> int:
        return sum(n["level"] == "todo" for n in self.notes)

    @property
    def approximations(self) -> int:
        return sum(n["level"] == "approx" for n in self.notes)

    def to_dict(self) -> dict:
        from .. import __version__
        return {"tk4k": __version__, "source": self.source, "grade": self.grade, "translated_items": self.translated,
                "todo": self.todo, "approximations": self.approximations, "error": self.error,
                "notes": self.notes, "report": self.payload}


def main_exit_code(results) -> int:
    """0 = fine, 1 = something to look at (placeholders / unsupported), 2 = the translator failed."""
    grades = {r.grade for r in results}
    return 2 if "failed" in grades else 1 if "unsafe" in grades else 0


def _read_source(path: str) -> str:
    """Read a Python file the way Python does: BOM and `# coding:` cookie honoured, UTF-8 by default."""
    import tokenize
    with open(path, "rb") as f:
        enc, _ = tokenize.detect_encoding(f.readline)
        f.seek(0)
        return f.read().decode(enc)


def _short(msg: str) -> str:
    """'Spinbox is not in TK 4K yet: `people` replaced ...' -> 'Spinbox people' (short enough for a QR code)."""
    m = re.match(r"([\w.]+) is not in TK 4K yet: (?:`(\w+)`|anonymous widget)", msg)
    if m:
        return f"{m.group(1)} {m.group(2) or ''}".strip()
    m = re.match(r"(.*?) is not supported yet", msg)
    return (m.group(1) if m else msg)[:32]


def _payload(app: str, grade: str, extra: dict) -> str:
    ecr = _alerts.errcode_report()
    if ecr is not None and ecr.worst >= 1:
        return ecr.payload
    return _alerts.compact_payload(app, extra=extra)


def port_source(src: str, app: str = "app"):
    """Translate source text. Returns (code_or_None, Result without file info). Never raises."""
    from .engine import Porter
    res = Result(source=app)
    try:
        p = Porter(src, app)
        out = p.run()
        res.notes = list(p.rep.notes)
        res.translated = p.rep.translated
        res.grade = p.rep.grade if out is not None else "skipped"
        if out is not None:
            try:
                compile(out, app, "exec")
            except SyntaxError as e:  # our own output must be valid, or we do not hand it over
                raise RuntimeError(f"generated code does not compile: {e}") from e
            out = (f"# Translated from {app}.py by tk4k.port. Grade: {res.grade}.\n"
                   "# Placeholders and ui.unsupported(...) calls mark what TK 4K cannot do yet; see the .report.json\n"
                   "# and the log. Running the program prints a summary (and a QR code) of anything skipped.\n") + out
        return out, res
    except Exception as e:  # a source we cannot read (SyntaxError), or a bug in the translator
        import libcst
        res.grade = "failed"
        if isinstance(e, libcst.ParserSyntaxError):
            res.error = f"SyntaxError: {getattr(e, 'message', None) or str(e).splitlines()[0]} (line {getattr(e, 'raw_line', '?')})"
        else:
            res.error = f"{type(e).__name__}: {e}"
        return None, res


def port_file(path: str, out: Optional[str] = None, *, write: bool = True, qr: Optional[bool] = None,
              stream=None) -> Result:
    """Translate one file. Writes `<name>_tk4k.py`, `.report.json`, `.port.log` and (when something is wrong and
    `segno` is installed) `.qr.png` next to it. `write=False` only grades. The original is never modified."""
    t0 = time.time()
    path = os.path.abspath(path)
    stem = os.path.splitext(os.path.basename(path))[0]
    out = os.path.abspath(out) if out else os.path.join(os.path.dirname(path), stem + "_tk4k.py")
    base = os.path.splitext(out)[0]
    log_path = base + ".port.log"
    log = logging.getLogger("tk4k.port")
    log.setLevel(logging.DEBUG)
    fh = None
    _alerts.reset()
    _alerts.use_errcode(stem)
    if write:
        try:
            fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
            fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%H:%M:%S"))
            log.addHandler(fh)
        except OSError:
            log_path = None
    try:
        log.info("porting %s -> %s", path, out)
        try:
            src = _read_source(path)
        except (OSError, UnicodeDecodeError, SyntaxError, LookupError) as e:
            code, res = None, Result(source=path, grade="failed", error=f"{type(e).__name__}: {e}")
        else:
            code, res = port_source(src, stem)
        res.source = path
        for n in res.notes:
            (log.warning if n["level"] == "todo" else log.info)("%s line %s: %s", n["level"], n["line"] or "?", n["msg"])
            if n["level"] == "todo":
                _alerts.note("todo", _short(n["msg"]), n["line"])
        if res.error:
            kind = "parse" if res.error.startswith(("SyntaxError", "UnicodeDecodeError", "OSError", "FileNotFoundError")) else "crash"
            _alerts.note(kind, res.error[:80])
            log.error("%s", res.error)
        res.payload = _payload(stem, res.grade, {"grade": res.grade, "todo": res.todo, "approx": res.approximations})
        if write and code is not None:
            tmp = out + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(code)
            os.replace(tmp, out)
            res.out_path = out
        if write:
            res.report_path = base + ".report.json"
            with open(res.report_path, "w", encoding="utf-8") as f:
                json.dump(res.to_dict(), f, indent=1)
            res.log_path = log_path
            wanted = qr if qr is not None else res.grade in ("unsafe", "failed")
            if wanted and _alerts.qr_available():
                res.qr_path = base + ".qr.png"
                _alerts.qr_save(res.payload, res.qr_path)
        res.seconds = time.time() - t0
        log.info("grade %s, %d translated, %d todo, %d approximations, %.2fs", res.grade, res.translated,
                 res.todo, res.approximations, res.seconds)
        return res
    finally:
        if fh is not None:
            log.removeHandler(fh)
            fh.close()
