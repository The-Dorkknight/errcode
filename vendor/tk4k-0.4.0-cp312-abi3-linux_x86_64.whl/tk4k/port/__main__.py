"""Command line for tk4k.port. See `python -m tk4k.port --help`."""
from __future__ import annotations

import argparse
import os
import sys
import time

from .. import _alerts, __version__
from . import main_exit_code, port_file

GRADE_TEXT = {"safe": "SAFE: translated with no loss",
              "review": "REVIEW: translated, some things approximated",
              "unsafe": "UNSAFE: placeholders / unsupported calls in the result (it runs, but check the report)",
              "failed": "FAILED: the translator could not process this file",
              "skipped": "SKIPPED: nothing to translate in this file"}


def _uses_tkinter(path: str) -> bool:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            t = f.read(200000)
    except OSError:
        return False
    return "tkinter" in t or "Tkinter" in t


def _files(target: str):
    if os.path.isdir(target):
        for root, dirs, names in os.walk(target):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "venv", ".venv", "build")]
            for n in sorted(names):
                if n.endswith(".py") and not n.endswith("_tk4k.py"):
                    p = os.path.join(root, n)
                    if _uses_tkinter(p):
                        yield p
    else:
        yield target


def _alert(r, out, qr_to_terminal: bool) -> None:
    bar = "=" * 72
    big = r.grade in ("unsafe", "failed")
    if big:
        print(bar, file=out)
    print(f"[tk4k.port] {os.path.basename(r.source)}  {GRADE_TEXT.get(r.grade, r.grade)}", file=out)
    print(f"[tk4k.port]   {r.translated} translated, {r.approximations} approximations, {r.todo} placeholders/unsupported", file=out)
    shown = 0
    for n in r.notes:
        if n["level"] == "todo" and shown < 8:
            shown += 1
            print(f"[tk4k.port]   ! line {n['line'] or '?'}: {n['msg']}", file=out)
    if r.todo > shown:
        print(f"[tk4k.port]   ... and {r.todo - shown} more (see the report)", file=out)
    if r.error:
        print(f"[tk4k.port]   ERROR: {r.error}", file=out)
    for label, p in (("translated", r.out_path), ("report", r.report_path), ("log", r.log_path), ("QR", r.qr_path)):
        if p:
            print(f"[tk4k.port]   {label}: {p}", file=out)
    if big and r.payload:
        print(f"[tk4k.port]   error report: {r.payload}", file=out)
        if qr_to_terminal and _alerts.qr_available() and len(r.payload) <= 400:
            print(_alerts.qr_terminal(r.payload), file=out)
        elif big and not _alerts.qr_available():
            print("[tk4k.port]   (pip install segno to get this as a QR code)", file=out)
    if big:
        print(bar, file=out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m tk4k.port",
                                 description="Translate tkinter apps into TK 4K apps. Nothing is dropped silently.")
    ap.add_argument("target", nargs="?", help="a .py file, or a folder to grade/translate")
    ap.add_argument("-o", "--out", help="output file (single file only; default NAME_tk4k.py next to the source)")
    ap.add_argument("--check", action="store_true", help="grade only: write no files")
    ap.add_argument("--qr", action="store_true", help="always write a QR error report (default: only if unsafe/failed)")
    ap.add_argument("--no-qr", action="store_true", help="never print a QR code in the terminal")
    ap.add_argument("--decode", metavar="REPORT", help="read a TK4K1-... (or ErrCode EC2-...) report string")
    ap.add_argument("--version", action="version", version=f"tk4k.port {__version__}")
    a = ap.parse_args(argv)

    if a.decode:
        s = a.decode
        if s.strip().upper().startswith("EC"):
            try:
                import errcode
                print("\n".join(errcode.decode(s).lines()))
                return 0
            except ImportError:
                print("This is an ErrCode report; pip install errcode (or use its decoder page) to read it.", file=sys.stderr)
                return 2
        try:
            print(_alerts.describe(_alerts.decode_payload(s)))
            return 0
        except Exception as e:
            print(f"could not decode: {e}", file=sys.stderr)
            return 2
    if not a.target and sys.stdin.isatty():          # launched by double-click: ask for the file
        try:
            a.target = input("Drag a tkinter .py file (or a folder) onto this window, then press Enter: ").strip().strip("\"'")
        except EOFError:
            a.target = None
    if not a.target:
        ap.error("give a .py file or a folder (or --decode REPORT)")

    try:
        import libcst  # noqa: F401
    except ImportError:
        print("[tk4k.port] LibCST is needed to read your code:  pip install libcst   (or pip install \"tk4k[port]\")", file=sys.stderr)
        return 2
    files = list(_files(a.target))
    if not files:
        print("[tk4k.port] no tkinter files found", file=sys.stderr)
        return 0
    results = []
    t0 = time.time()
    many = len(files) > 1
    for i, f in enumerate(files, 1):
        if many:  # a heartbeat on slow machines: one line per file with elapsed time
            print(f"[tk4k.port] {i}/{len(files)} {f}  ({time.time() - t0:.0f}s so far)", file=sys.stderr, flush=True)
        r = port_file(f, a.out if not many else None, write=not a.check, qr=True if a.qr else None)
        results.append(r)
        if not many or r.grade in ("unsafe", "failed"):
            _alert(r, sys.stderr, qr_to_terminal=not a.no_qr and not many)
    if many:
        from collections import Counter
        c = Counter(r.grade for r in results)
        print(f"[tk4k.port] {len(results)} files in {time.time() - t0:.0f}s: " + ", ".join(f"{k} {v}" for k, v in sorted(c.items())),
              file=sys.stderr)
    return main_exit_code(results)


if __name__ == "__main__":
    sys.exit(main())
