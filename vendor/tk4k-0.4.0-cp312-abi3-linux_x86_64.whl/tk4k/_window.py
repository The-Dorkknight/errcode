"""The window and its event loop."""
from __future__ import annotations

import collections
import heapq
import itertools
import time
import traceback
from importlib import resources
from typing import Any, Callable, Optional, Union

from . import _core, _widgets
from ._theme import THEMES, Theme
from ._widgets import Column, _take_callbacks


class _TitleStr(str):
    def __new__(cls, text, win):
        o = super().__new__(cls, text)
        o._win = win
        return o

    def __call__(self, text=None):
        if text is None:
            return str(self)
        self._win.title = text


_current: list = []


class Window(Column):
    """The top-level window. Use it like a Column:

        with Window("Hello", size=(400, 200)) as win:
            Label("Hi")
        win.run()

    The loop sleeps inside the OS until something happens, so an idle window uses ~0% CPU.
    """

    def __init__(self, title: str = "TK 4K", size: tuple[int, int] = (480, 320), *,
                 theme: Union[str, Theme] = "auto", min_size: Optional[tuple[int, int]] = None,
                 resizable: bool = True, pad: float = 16.0, gap: Optional[float] = None):
        super().__init__(None, gap=gap)
        self._title, self.size, self.min_size = title, size, min_size
        self._resizable, self.pad = resizable, pad
        self._theme_spec = theme
        self.theme: Optional[Theme] = None
        self.strict = False  # True: errors in callbacks stop the app (tests); False: print and go on
        self.error: Optional[BaseException] = None
        self._started = False
        self._timers: list[tuple[float, int, Callable, tuple]] = []
        self._cancelled: set[int] = set()
        self._timer_ids = itertools.count(1)
        self._posted: collections.deque = collections.deque()
        self._toasts: list[tuple[str, float]] = []
        self._font_bytes: Optional[bytes] = None
        self._anim_due: Optional[float] = None
        self._on_close = None
        self._quitting = False
        self._binds: dict = {}
        self._dialogs: list = []
        self.menubar = None
        _current.append(self)

    # ------------------------------------------------------------ properties
    @property
    def title(self) -> "_TitleStr":
        """The window title. Also callable, like tkinter's: win.title("New title")."""
        return _TitleStr(self._title, self)

    @title.setter
    def title(self, value: str) -> None:
        self._title = str(value)
        if self._started:
            _core.set_title(value)

    def set_theme(self, theme: Union[str, Theme]) -> None:
        """'dark', 'light', 'auto' (follow the OS) or a Theme. Before the window opens it is just remembered."""
        if not self._started:  # the native core is not initialised yet; calling it then crashed the process
            self._theme_spec = theme
            return
        if isinstance(theme, str):
            if theme == "auto":
                theme = THEMES["dark" if _core.system_dark() else "light"]
            else:
                theme = THEMES[theme]
        self.theme = theme
        _core.set_theme(theme.colours(), theme.rounding, theme.pad_x, theme.pad_y, theme.gap, theme.dark)

    # ------------------------------------------------------------ timers and threads
    def after(self, ms: float, fn: Callable, *args: Any) -> int:
        """Run fn(*args) once, ms milliseconds from now (like Tk's after). Returns an id."""
        tid = next(self._timer_ids)
        heapq.heappush(self._timers, (time.monotonic() + ms / 1000.0, tid, fn, args))
        _core.wake()
        return tid

    def after_idle(self, fn: Callable, *args: Any) -> int:
        return self.after(0, fn, *args)

    def after_cancel(self, tid: int) -> None:
        self._cancelled.add(tid)

    def post(self, fn: Callable, *args: Any) -> None:
        """Run fn(*args) on the UI thread. The one call that is safe from worker threads."""
        self._posted.append((fn, args))
        _core.wake()

    def toast(self, text: str, seconds: float = 2.5) -> None:
        """A short message at the bottom of the window that fades away by itself."""
        self._toasts.append((text, time.monotonic() + seconds))
        self.after(seconds * 1000 + 30, lambda: None)

    def quit(self) -> None:
        self._quitting = True
        _core.request_quit()

    destroy = quit

    # ---- tkinter compatibility for translated apps
    def geometry(self, spec: str = "") -> None:
        import re as _re
        m = _re.match(r"(\d+)x(\d+)", str(spec))
        if m:
            self.size = (int(m.group(1)), int(m.group(2)))

    def minsize(self, w=0, h=0) -> None:
        self.min_size = (int(w), int(h))

    def resizable(self, w=True, h=True) -> None:
        self._resizable = bool(w or h)

    def protocol(self, name: str, fn=None) -> None:
        if name == "WM_DELETE_WINDOW":
            self._on_close = fn

    def bind(self, seq, fn=None, add=None) -> None:
        """Key bindings such as "<space>", "<Return>", "<Escape>", "<Control-s>"; mouse bindings are noted and ignored."""
        s = str(seq).strip("<>")
        if fn is None:
            return
        self._binds[s] = fn

    bind_all = bind

    mainloop = lambda self, n=0: self.run()  # noqa: E731

    def _poll_keys(self) -> None:
        for seq, fn in self._binds.items():
            parts = seq.split("-")
            key = {"KeyPress": parts[-1], "Key": parts[-1]}.get(parts[0], parts[-1])
            if key.startswith("KeyPress") or key == "Key":
                key = parts[-1]
            if _core.key_pressed(key):
                _widgets._queue(lambda f=fn: f(_widgets._Event(self)))

    def config(self, cnf=None, **kw):
        kw = dict(cnf or {}, **kw)
        if "menu" in kw:
            self.menubar = kw.pop("menu")
        if kw:
            super().config(**kw)

    configure = config

    # modal dialogs (callbacks instead of blocking: TK 4K never freezes the window)
    def message(self, title, text, on_close=None):
        from ._widgets2 import message
        return message(self, title, text, on_close)

    def ask_yes_no(self, title, text, on_answer, yes="Yes", no="No"):
        from ._widgets2 import ask_yes_no
        return ask_yes_no(self, title, text, on_answer, yes, no)

    def ask_string(self, title, prompt, on_answer, initial=""):
        from ._widgets2 import ask_string
        return ask_string(self, title, prompt, on_answer, initial)

    def ask_open_file(self, on_answer, start=None, title="Open file"):
        from ._widgets2 import ask_open_file
        return ask_open_file(self, on_answer, start, title)

    def update(self) -> None:
        pass

    update_idletasks = lift = focus_force = attributes = iconbitmap = option_add = update

    def toast_or_none(self):
        return self

    # ------------------------------------------------------------ loop
    def _start(self) -> None:
        if self._started:
            return
        try:  # translated apps: say up front that parts are placeholders
            from . import _alerts
            n = sum(1 for e in _alerts.events() if e["kind"] == "placeholder")
            if n:
                self._toasts.append((f"{n} widget(s) in this app are placeholders (see the log)", time.monotonic() + 6))
        except Exception:
            pass
        _core.init(self._title, int(self.size[0]), int(self.size[1]), self._resizable)
        self._started = True
        try:
            self._font_bytes = resources.files("tk4k").joinpath("fonts/Inter-Regular-latin.otf").read_bytes()
        except Exception:  # missing font file is not fatal; the built-in font is used
            self._font_bytes = None
        self.set_theme(self._theme_spec)
        if self._font_bytes:
            _core.set_font_memory(self._font_bytes, self.theme.font_size)
        if self.min_size:
            _core.set_min_size(*self.min_size)

    def _stop(self) -> None:
        if self._started:
            _core.shutdown()
            self._started = False

    def _timeout_ms(self) -> int:
        if self._posted or _widgets._callbacks:
            return 0
        due = [self._timers[0][0]] if self._timers else []
        if self._anim_due is not None:
            due.append(self._anim_due)
        if not due:
            return -1  # nothing scheduled: sleep until the user does something
        return max(0, int((min(due) - time.monotonic()) * 1000) + 1)

    def _draw_frame(self) -> None:
        try:
            _widgets._anim_ms = 0
            if self.gap is not None:
                _core.push_spacing(self.gap, self.gap)
            try:
                if self.menubar is not None:
                    self.menubar._draw_bar()
                if _core.begin_root(self.pad, self.pad):
                    if self._binds:
                        self._poll_keys()
                    self._draw_children()
            finally:
                _core.end_root()
                if self.gap is not None:
                    _core.pop_spacing()
            for d in list(self._dialogs):
                d._render_dialog()
            self._draw_toasts()
            self._anim_due = (time.monotonic() + _widgets._anim_ms / 1000.0) if _widgets._anim_ms else None
        except Exception as e:  # keep ImGui's frame balanced; report after the frame
            self.error = e

    def _draw_toasts(self) -> None:
        now = time.monotonic()
        self._toasts = [t for t in self._toasts if t[1] > now]
        if self._toasts and _core.begin_overlay("##toast", 0.5, 1.0, 18.0):
            for text, _ in self._toasts:
                _core.text(text, False)
        if self._toasts:
            _core.end_overlay()

    def _fail(self, exc: BaseException) -> None:
        if self.strict:
            raise exc
        try:
            from . import _alerts
            _alerts.note("callback", f"{type(exc).__name__}: {exc}"[:80], once_key=f"cb:{type(exc).__name__}:{exc}"[:120])
        except Exception:
            pass
        traceback.print_exception(type(exc), exc, exc.__traceback__)

    def _after_frame(self) -> None:
        """Everything that must not happen mid-frame: posted calls, timers, widget callbacks."""
        if self.error is not None:
            err, self.error = self.error, None
            raise err
        while self._posted:
            fn, args = self._posted.popleft()
            try:
                fn(*args)
            except Exception as e:
                self._fail(e)
        now = time.monotonic()
        ran = False
        while self._timers and self._timers[0][0] <= now:
            _, tid, fn, args = heapq.heappop(self._timers)
            if tid in self._cancelled:
                self._cancelled.discard(tid)
                continue
            ran = True
            try:
                fn(*args)
            except Exception as e:
                self._fail(e)
        animating = self._anim_due is not None and self._anim_due <= now
        for fn, args in _take_callbacks():
            try:
                fn(*args)
            except Exception as e:
                self._fail(e)
        if ran:
            _core.wake()
        elif animating:
            _core.wake(1)  # a moving bar needs one frame per step, not two

    def run(self) -> None:
        """Open the window and run until it is closed."""
        self._start()
        try:
            while True:
                alive = _core.pump(self._draw_frame, self._timeout_ms())
                self._after_frame()
                if not alive:
                    if self._on_close is not None and not self._quitting:
                        try:  # WM_DELETE_WINDOW: the handler decides (it calls destroy() to really close)
                            self._on_close()
                        except Exception as e:
                            self._fail(e)
                        if not self._quitting:
                            continue
                    break
        finally:
            self._stop()
