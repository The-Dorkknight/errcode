"""Drive a Window without a screen: fake clicks and typing, take screenshots.

    h = Harness(win)          # uses SDL's 'dummy' video driver and the software renderer
    h.click(button); h.type("hello"); h.screenshot("shot.png")
"""
from __future__ import annotations

import os
from typing import Optional


class Harness:
    def __init__(self, win, *, headless: bool = True):
        if headless:
            os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
            os.environ.setdefault("TK4K_RENDERER", "software")
        from . import _core
        self._core = _core
        self.win = win
        win.strict = True
        win._start()
        self.step(3)

    def step(self, n: int = 2, capture: bool = False) -> None:
        self._core.step(self.win._draw_frame, n, capture)
        self.win._after_frame()

    def _pos(self, x: float, y: float) -> None:
        self._core.test_mouse_pos(x, y)
        self.step(2)

    def click(self, widget) -> None:
        x, y, w, h = widget.rect
        if w <= 0 or h <= 0:
            raise AssertionError(f"{type(widget).__name__} has not been drawn (rect {widget.rect})")
        self._pos(x + w / 2, y + h / 2)
        self._core.test_mouse_button(0, True)
        self.step(2)
        self._core.test_mouse_button(0, False)
        self.step(2)

    def click_at(self, x: float, y: float) -> None:
        self._pos(x, y)
        self._core.test_mouse_button(0, True)
        self.step(2)
        self._core.test_mouse_button(0, False)
        self.step(2)

    def type(self, text: str) -> None:
        self._core.test_text(text)
        self.step(2)

    def key(self, name: str) -> None:
        self._core.test_key(name, True)
        self.step(2)
        self._core.test_key(name, False)
        self.step(2)

    def drag(self, widget, frac_from: float, frac_to: float) -> None:
        x, y, w, h = widget.rect
        self._pos(x + w * frac_from, y + h / 2)
        self._core.test_mouse_button(0, True)
        self.step(2)
        self._pos(x + w * frac_to, y + h / 2)
        self._core.test_mouse_button(0, False)
        self.step(2)

    def frames(self) -> int:
        return self._core.frame_count()

    def screenshot(self, path: Optional[str] = None):
        self.step(2, capture=True)
        w, h = self._core.capture_size()
        from PIL import Image
        img = Image.frombytes("RGBA", (w, h), self._core.last_capture())
        if path:
            img.save(path)
        return img

    def close(self) -> None:
        self.win._stop()
