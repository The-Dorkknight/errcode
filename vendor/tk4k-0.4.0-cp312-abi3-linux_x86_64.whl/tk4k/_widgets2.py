"""TK 4K 0.4.0 widgets: the hard ones. Canvas, Menu, Tabs, Radio, Spinbox, Listbox, Tree, Dialog (+ in-app file dialog).

Method names follow tkinter on purpose (insert, delete, curselection, create_line, add_command ...) so translated
code keeps working, but every widget also has plain Python properties for new code.
"""
from __future__ import annotations

import os
from typing import Any, Callable, Optional

from . import _core
from ._widgets import (Button, Column, Container, Entry, Label, Row, Separator, Var, Widget, _compat_note, _Event,
                       _queue, _rgb, _val)

# ---------------------------------------------------------------------------------------- colours
_NAMED = {"white": "#ffffff", "black": "#000000", "red": "#ff0000", "green": "#008000", "blue": "#0000ff",
          "yellow": "#ffff00", "gray": "#bebebe", "grey": "#bebebe", "orange": "#ffa500", "purple": "#a020f0",
          "cyan": "#00ffff", "magenta": "#ff00ff", "pink": "#ffc0cb", "brown": "#a52a2a", "lightblue": "#add8e6",
          "lightgray": "#d3d3d3", "darkgray": "#a9a9a9", "navy": "#000080", "gold": "#ffd700"}


def _col(c: Any, default: Optional[str] = None):
    if c is None or c == "":
        c = default
    if c is None:
        return None
    if isinstance(c, str):
        c = _NAMED.get(c.lower(), c)
        if not c.startswith("#"):
            return None
    return _rgb(c)


# ---------------------------------------------------------------------------------------- Canvas
class Canvas(Widget):
    """Retained 2-D drawing area with tkinter's item API: create_line/rectangle/oval/polygon/text, move, delete, itemconfig."""

    def __init__(self, width: float = 300.0, height: float = 200.0, *, bg: str = "white", **kw):
        super().__init__(**kw)
        self.cw, self.ch, self.bg = float(width), float(height), bg
        self._items: dict[int, dict] = {}
        self._next = 1
        self._handlers: dict[str, Callable] = {}
        self._was_down = False

    # --- creating items (return an id, like tkinter)
    def _add(self, kind: str, coords: list, opts: dict) -> int:
        i = self._next
        self._next += 1
        tags = opts.pop("tags", ())
        self._items[i] = {"k": kind, "c": [float(v) for v in coords], "o": opts,
                          "t": {tags} if isinstance(tags, str) else set(tags)}
        _core.wake()
        return i

    def create_line(self, *coords, **o):
        return self._add("line", _flat(coords), o)

    def create_rectangle(self, *coords, **o):
        return self._add("rect", _flat(coords), o)

    def create_oval(self, *coords, **o):
        return self._add("oval", _flat(coords), o)

    def create_polygon(self, *coords, **o):
        return self._add("poly", _flat(coords), o)

    def create_text(self, x, y, **o):
        o.setdefault("text", "")
        return self._add("text", [x, y], o)

    # --- editing items
    def _which(self, what) -> list[int]:
        if what == "all":
            return list(self._items)
        if isinstance(what, int):
            return [what] if what in self._items else []
        return [i for i, it in self._items.items() if what in it["t"]]

    def delete(self, *what) -> None:
        for w in what:
            for i in self._which(w):
                self._items.pop(i, None)
        _core.wake()

    def move(self, what, dx, dy) -> None:
        for i in self._which(what):
            c = self._items[i]["c"]
            for k in range(0, len(c) - 1, 2):
                c[k] += dx
                c[k + 1] += dy
        _core.wake()

    def coords(self, what, *new):
        ids = self._which(what)
        if not ids:
            return []
        if new:
            self._items[ids[0]]["c"] = [float(v) for v in _flat(new)]
            _core.wake()
        return list(self._items[ids[0]]["c"])

    def itemconfig(self, what, **o) -> None:
        for i in self._which(what):
            self._items[i]["o"].update(o)
        _core.wake()

    itemconfigure = itemconfig

    def find_all(self):
        return tuple(self._items)

    def bind(self, seq, fn=None, add=None):
        """<Button-1>, <B1-Motion>, <ButtonRelease-1>, <Motion>; the callback gets an event with .x and .y."""
        if fn is not None:
            self._handlers[str(seq)] = fn

    # --- drawing
    def _draw(self) -> None:
        bg = _col(self.bg, "#ffffff") or (1.0, 1.0, 1.0)
        x, y, hov, down, pressed, released = _core.canvas_begin("##canvas", self.cw, self.ch, *bg)
        try:
            for it in list(self._items.values()):
                self._paint(it)
        finally:
            _core.canvas_end()
        ev = _CanvasEvent(self, x, y)
        h = self._handlers
        if pressed and "<Button-1>" in h:
            _queue(h["<Button-1>"], ev)
        if down and not pressed and "<B1-Motion>" in h:
            _queue(h["<B1-Motion>"], ev)
        if hov and "<Motion>" in h and not down:
            _queue(h["<Motion>"], ev)
        if self._was_down and not down and "<ButtonRelease-1>" in h:
            _queue(h["<ButtonRelease-1>"], ev)
        self._was_down = down

    def _paint(self, it: dict) -> None:
        k, c, o = it["k"], it["c"], it["o"]
        fill = _col(o.get("fill"))
        out = _col(o.get("outline"), "#000000")
        wd = float(o.get("width", 1))
        if k == "line":
            col = fill or (0.0, 0.0, 0.0)
            for a in range(0, len(c) - 3, 2):
                _core.cv_line(c[a], c[a + 1], c[a + 2], c[a + 3], *col, wd)
        elif k in ("rect", "oval", "poly"):
            f = (*fill, 1.0) if fill else (0.0, 0.0, 0.0, -1.0)
            ln = (*out, 1.0) if (out and wd > 0 and o.get("outline", "x") != "") else (0.0, 0.0, 0.0, -1.0)
            if k == "rect":
                _core.cv_rect(*c[:4], *f, *ln, wd)
            elif k == "oval":
                _core.cv_oval(*c[:4], *f, *ln, wd)
            else:
                _core.cv_poly(c, *f, *ln, wd)
        elif k == "text":
            _core.cv_text(c[0], c[1], str(o.get("text", "")), *(fill or (0.0, 0.0, 0.0)))


class _CanvasEvent(_Event):
    def __init__(self, w, x, y):
        super().__init__(w)
        self.x, self.y = int(x), int(y)


def _flat(coords) -> list:
    out: list = []
    for c in coords:
        if isinstance(c, (list, tuple)):
            out += list(c)
        else:
            out.append(c)
    return out


# ---------------------------------------------------------------------------------------- Menu
class Menu:
    """A menu bar or a drop-down. Build it like tkinter: add_command / add_separator / add_cascade / add_checkbutton.

    Attach the top-level Menu with `window.config(menu=bar)` or `window.menubar = bar`.
    """

    def __init__(self, parent: Any = None, *, tearoff: Any = 0, **_ignored):
        self.entries: list[tuple] = []

    def add_command(self, label: str = "", command: Optional[Callable] = None, accelerator: str = "", **_):
        self.entries.append(("cmd", label, command, accelerator, None))

    def add_checkbutton(self, label: str = "", command: Optional[Callable] = None, variable: Optional[Var] = None,
                        accelerator: str = "", **_):
        self.entries.append(("chk", label, command, accelerator, variable))

    def add_separator(self, **_):
        self.entries.append(("sep",))

    def add_cascade(self, label: str = "", menu: Optional["Menu"] = None, **_):
        self.entries.append(("sub", label, menu))

    def entryconfig(self, *a, **k):
        _compat_note("Menu.entryconfig is not supported yet")

    entryconfigure = entryconfig

    def _draw_items(self) -> None:
        for e in self.entries:
            if e[0] == "sep":
                _core.menu_separator()
            elif e[0] == "sub":
                if e[2] is not None and _core.begin_menu(e[1], True):
                    try:
                        e[2]._draw_items()
                    finally:
                        _core.end_menu()
            else:
                chk = -1 if e[0] == "cmd" else (1 if (e[4] is not None and e[4].get()) else 0)
                if _core.menu_item(e[1], e[3], chk, True):
                    if e[0] == "chk" and e[4] is not None:
                        e[4].set(not e[4].get())
                    _queue(e[2])

    def _draw_bar(self) -> None:
        if _core.begin_main_menu_bar():
            try:
                self._draw_items()
            finally:
                _core.end_main_menu_bar()


# ---------------------------------------------------------------------------------------- Tabs
class Tab(Column):
    """One page of a Tabs widget."""

    def __init__(self, title: str = "Tab", parent=None, **kw):
        super().__init__(parent, **kw)
        self.title = title


class Tabs(Container):
    """Tabbed pages (ttk.Notebook). Children are Tab objects, or any Frame given a title with add(frame, text=...)."""

    def __init__(self, parent=None, *, on_change: Optional[Callable[[int], None]] = None, **kw):
        super().__init__(parent, **kw)
        self.index = 0
        self.on_change = on_change
        self._want: Optional[int] = None

    def add(self, child: Widget, text: str = "", **_) -> None:
        child._tab_title = text
        if child not in self._children:
            self._children.append(child)

    def select(self, i: Any = None):
        if i is None:
            return self.index
        self._want = int(i) if not isinstance(i, Widget) else self._children.index(i)
        _core.wake()

    def tab(self, i: int, option: str = "text"):
        return self._title(self._children[i])

    @staticmethod
    def _title(c: Widget) -> str:
        return str(getattr(c, "_tab_title", None) or getattr(c, "title", "Tab"))

    def _draw(self) -> None:
        if not _core.begin_tab_bar(f"##tabs{self._id}"):
            return
        try:
            for n, c in enumerate(list(self._children)):
                want = self._want == n
                if _core.begin_tab_item(self._title(c) + f"###t{n}", want):
                    try:
                        if self.index != n and not want:
                            self.index = n
                            _queue(self.on_change, n)
                        if want:
                            self._want = None
                            self.index = n
                        c._render()
                    finally:
                        _core.end_tab_item()
        finally:
            _core.end_tab_bar()


# ---------------------------------------------------------------------------------------- Radio, Spinbox
class Radio(Widget):
    """One round button of a group: all share a Var, each has its own value."""

    def __init__(self, text: str = "", value: Any = 1, *, var: Optional[Var] = None,
                 on_change: Optional[Callable[[Any], None]] = None, **kw):
        super().__init__(**kw)
        self.text, self.value = text, value
        self.var = var if var is not None else Var(None)
        self.on_change = on_change

    def invoke(self) -> None:
        self.var.set(self.value)
        _queue(self.on_change, self.value)

    def _draw(self) -> None:
        if _core.radio(str(_val(self.text)), self.var.get() == self.value):
            self.var.set(self.value)
            _queue(self.on_change, self.value)


class Spinbox(Widget):
    """A number box with up/down steps (tk.Spinbox / ttk.Spinbox). .get() returns text like tkinter; .value is a number."""

    def __init__(self, lo: float = 0, hi: float = 100, step: float = 1, *, var: Optional[Var] = None, value: Any = None,
                 on_change: Optional[Callable[[Any], None]] = None, **kw):
        super().__init__(**kw)
        self.lo, self.hi, self.step = lo, hi, step
        self.var = var if var is not None else Var(lo if value is None else value)
        self.on_change = on_change

    @property
    def value(self):
        v = float(self.var.get() or 0)
        return int(v) if float(self.step).is_integer() and float(self.lo).is_integer() else v

    @value.setter
    def value(self, v):
        self.var.set(v)

    def get(self) -> str:
        return str(self.value)

    def set(self, v) -> None:
        self.var.set(v)

    def delete(self, *a) -> None:
        pass

    def insert(self, _i, text) -> None:
        try:
            self.var.set(float(text))
        except ValueError:
            pass

    def _draw(self) -> None:
        dec = 0 if float(self.step).is_integer() and float(self.lo).is_integer() else 2
        ch, nv = _core.spin("##spin", float(self.var.get() or 0), float(self.lo), float(self.hi), float(self.step),
                            self._auto_width(120.0), dec)
        if ch:
            self.var.set(int(nv) if dec == 0 else nv)
            _queue(self.on_change, self.value)


# ---------------------------------------------------------------------------------------- Listbox
class Listbox(Widget):
    """Scrolling list of strings. tkinter names: insert, delete, get, curselection, size, selection_set."""

    def __init__(self, items: Optional[list] = None, *, height: int = 6, selectmode: str = "browse",
                 on_select: Optional[Callable[[list], None]] = None, **kw):
        super().__init__(**kw)
        self.items = [str(i) for i in (items or [])]
        self.rows, self.selectmode, self.on_select = int(height), selectmode, on_select
        self.sel: list[int] = []

    def _ix(self, i) -> int:
        return len(self.items) if str(i) == "end" else int(i)

    def insert(self, index, *items) -> None:
        at = self._ix(index)
        for k, it in enumerate(items):
            self.items.insert(at + k, str(it))
        _core.wake()

    def delete(self, first, last=None) -> None:
        a = self._ix(first)
        b = (len(self.items) - 1 if str(last) == "end" else int(last)) if last is not None else a
        del self.items[a:b + 1]
        self.sel = [i for i in self.sel if i < len(self.items)]
        _core.wake()

    def get(self, first, last=None):
        if last is None:
            return self.items[self._ix(first)]
        b = len(self.items) - 1 if str(last) == "end" else int(last)
        return tuple(self.items[self._ix(first):b + 1])

    def size(self) -> int:
        return len(self.items)

    def curselection(self) -> tuple:
        return tuple(sorted(self.sel))

    def selection_set(self, i, last=None) -> None:
        self.sel = [self._ix(i)]
        _core.wake()

    def selection_clear(self, *a) -> None:
        self.sel = []

    def see(self, *a) -> None:
        pass

    yview = see

    def bind(self, seq, fn=None, add=None):
        if str(seq) in ("<<ListboxSelect>>", "<ButtonRelease-1>", "<Button-1>") and fn is not None:
            self.on_select = lambda _s, f=fn: f(_Event(self))
        elif fn is not None:
            _compat_note(f"Listbox.bind({seq}) is not supported yet")

    def _draw(self) -> None:
        h = max(1, self.rows) * 24.0 + 8.0
        w = self.width if self.width is not None else -1.0
        if _core.begin_child(f"##lb{self._id}", w, h, True):
            try:
                for i, txt in enumerate(self.items):
                    _core.push_id(str(i))
                    if _core.selectable(txt, i in self.sel, False):
                        if self.selectmode in ("multiple", "extended"):
                            self.sel = [x for x in self.sel if x != i] if i in self.sel else self.sel + [i]
                        else:
                            self.sel = [i]
                        _queue(self.on_select, list(self.sel))
                    _core.pop_id()
            finally:
                _core.end_child()
        else:
            _core.end_child()


# ---------------------------------------------------------------------------------------- Tree
class Tree(Widget):
    """Hierarchical table (ttk.Treeview). insert/delete/get_children/item/selection/heading follow tkinter."""

    def __init__(self, columns: tuple = (), *, show: Any = "tree headings", height: float = 220.0,
                 on_select: Optional[Callable[[tuple], None]] = None, **kw):
        super().__init__(**kw)
        self.cols = tuple(columns)
        self.show = show if isinstance(show, str) else " ".join(show)
        self.height, self.on_select = height, on_select
        self.heads: dict[str, str] = {}
        self._nodes: dict[str, dict] = {"": {"children": [], "text": "", "values": (), "parent": None}}
        self._n = 0
        self.sel: list[str] = []

    def heading(self, col, text: str = "", **_):
        if text:
            self.heads[str(col)] = text

    def column(self, *a, **k):
        pass

    def insert(self, parent: str = "", index: Any = "end", iid: Optional[str] = None, *, text: str = "",
               values: tuple = (), **_) -> str:
        self._n += 1
        iid = iid or f"I{self._n:03d}"
        self._nodes[iid] = {"children": [], "text": str(text), "values": tuple(str(v) for v in values), "parent": parent}
        sibs = self._nodes[parent]["children"]
        if str(index) == "end":
            sibs.append(iid)
        else:
            sibs.insert(int(index), iid)
        _core.wake()
        return iid

    def delete(self, *iids) -> None:
        for iid in iids:
            n = self._nodes.pop(iid, None)
            if n is None:
                continue
            for c in list(n["children"]):
                self.delete(c)
            p = self._nodes.get(n["parent"])
            if p and iid in p["children"]:
                p["children"].remove(iid)
            if iid in self.sel:
                self.sel.remove(iid)
        _core.wake()

    def get_children(self, parent: str = "") -> tuple:
        return tuple(self._nodes[parent]["children"])

    def item(self, iid: str, option: Optional[str] = None, **kw):
        n = self._nodes[iid]
        for k, v in kw.items():
            if k in ("text", "values"):
                n[k] = v if k == "text" else tuple(str(x) for x in v)
        d = {"text": n["text"], "values": n["values"]}
        return d.get(option) if option else d

    def set(self, iid: str, column: Any = None, value: Any = None):
        n = self._nodes[iid]
        names = list(self.cols)
        if column is None:
            return dict(zip(names, n["values"]))
        k = names.index(column) if column in names else int(column)
        if value is None:
            return n["values"][k]
        v = list(n["values"]) + [""] * (len(names) - len(n["values"]))
        v[k] = str(value)
        n["values"] = tuple(v)

    def selection(self) -> tuple:
        return tuple(self.sel)

    def selection_set(self, *iids) -> None:
        self.sel = [i for i in (iids[0] if iids and isinstance(iids[0], (list, tuple)) else iids)]

    def focus(self, *a):
        return self.sel[0] if self.sel else ""

    def see(self, *a) -> None:
        pass

    yview = xview = see

    def bind(self, seq, fn=None, add=None):
        if str(seq) in ("<<TreeviewSelect>>", "<Button-1>", "<ButtonRelease-1>") and fn is not None:
            self.on_select = lambda _s, f=fn: f(_Event(self))
        elif fn is not None:
            _compat_note(f"Tree.bind({seq}) is not supported yet")

    def _draw(self) -> None:
        tree_col = "tree" in self.show
        names = (["#0"] if tree_col else []) + list(self.cols)
        if not names:
            names = ["#0"]
            tree_col = True
        w = self.width if self.width is not None else -1.0
        if not _core.begin_child(f"##tv{self._id}", w, self.height, True):
            _core.end_child()
            return
        try:
            if _core.begin_table(f"##tvt{self._id}", len(names)):
                try:
                    for n in names:
                        _core.table_setup_column(self.heads.get(n, "" if n == "#0" else n), 1.0)
                    if "headings" in self.show:
                        _core.table_headers_row()
                    self._rows("", tree_col, len(names))
                finally:
                    _core.end_table()
        finally:
            _core.end_child()

    def _rows(self, parent: str, tree_col: bool, ncols: int) -> None:
        for iid in list(self._nodes[parent]["children"]):
            n = self._nodes[iid]
            _core.push_id(iid)
            _core.table_next_row()
            _core.table_next_column()
            kids = bool(n["children"])
            label = n["text"] if tree_col else (n["values"][0] if n["values"] else "")
            if kids or tree_col:
                is_open, clicked = _core.tree_node(label + "##n", iid in self.sel, not kids)
            else:
                clicked = _core.selectable(label + "##n", iid in self.sel, True)
                is_open = False
            if clicked and self.sel != [iid]:
                self.sel = [iid]
                _queue(self.on_select, tuple(self.sel))
            vals = n["values"][(0 if tree_col else 1):]
            for k in range(ncols - 1):
                _core.table_next_column()
                _core.text(vals[k] if k < len(vals) else "")
            if kids and is_open:
                self._rows(iid, tree_col, ncols)
                _core.tree_pop()
            _core.pop_id()


# ---------------------------------------------------------------------------------------- Dialogs
class Dialog(Column):
    """A modal pop-up window. `with Dialog("Title", win): ...` builds it; open()/close() show and hide it."""

    def __init__(self, title: str = "Dialog", parent=None, *, size: tuple = (360, 0), on_close=None, **kw):
        root = parent if parent is not None else None
        super().__init__(None, **kw)
        self.title_text, self.size, self.on_close = title, size, on_close
        self._open = False
        self._asked = False
        self._win = _find_window(root)
        if self._win is not None:
            self._win._dialogs.append(self)

    def open(self) -> None:
        self._open, self._asked = True, False
        _core.wake()

    def close(self) -> None:
        if self._open:
            self._open = False
            _queue(self.on_close)
            _core.wake()

    destroy = close

    def _render_dialog(self) -> None:
        name = f"{self.title_text}###dlg{self._id}"
        if self._open and not self._asked:
            _core.open_popup(name)
            self._asked = True
        if not self._asked:
            return
        vis, still = _core.begin_modal(name, float(self.size[0]), float(self.size[1]))
        if vis:
            try:
                if not self._open:
                    _core.close_popup()
                else:
                    self._draw_children()
            finally:
                _core.end_modal()
            if not still:
                self.close()
        elif self._open and self._asked:
            self._open = False  # closed by the pop-up system itself (Escape, click outside)


class Toplevel(Dialog):
    """tkinter's Toplevel: opens at once as a pop-up (TK 4K has one OS window)."""

    def __init__(self, master=None, **kw):
        super().__init__("Window", master, size=(360, 0))
        self.open()

    def title(self, text=None):  # tkinter: top.title("x")
        if text is not None:
            self.title_text = str(text)

    def geometry(self, spec: str = "") -> None:
        import re
        m = re.match(r"(\d+)x(\d+)", str(spec))
        if m:
            self.size = (int(m.group(1)), int(m.group(2)))


def _find_window(w: Any):
    from . import _window
    if isinstance(w, _window.Window):
        return w
    while w is not None and not isinstance(w, _window.Window):
        w = getattr(w, "parent", None)
    return w if w is not None else (_window._current[-1] if _window._current else None)


def message(win, title: str, text: str, on_close: Optional[Callable] = None) -> Dialog:
    d = Dialog(title, win, size=(380, 0))
    with d:
        Label(text, wrap=True)
        Button("OK", d.close, primary=True)
    d.on_close = on_close
    d.open()
    return d


def ask_yes_no(win, title: str, text: str, on_answer: Callable[[bool], None], yes: str = "Yes", no: str = "No") -> Dialog:
    d = Dialog(title, win, size=(380, 0))
    answer = {"v": False}

    def pick(v):
        answer["v"] = v
        d.close()
    with d:
        Label(text, wrap=True)
        with Row():
            Button(yes, lambda: pick(True), primary=True)
            Button(no, lambda: pick(False))
    d.on_close = lambda: on_answer(answer["v"])
    d.open()
    return d


def ask_string(win, title: str, prompt: str, on_answer: Callable[[Optional[str]], None], initial: str = "") -> Dialog:
    d = Dialog(title, win, size=(380, 0))
    v = Var(initial)
    res = {"v": None}

    def ok(_t=None):
        res["v"] = v.get()
        d.close()
    with d:
        Label(prompt, wrap=True)
        Entry(var=v, on_submit=ok)
        with Row():
            Button("OK", ok, primary=True)
            Button("Cancel", d.close)
    d.on_close = lambda: on_answer(res["v"])
    d.open()
    return d


def ask_open_file(win, on_answer: Callable[[Optional[str]], None], start: Optional[str] = None,
                  title: str = "Open file") -> Dialog:
    """An in-app file chooser (TK 4K has no native dialogs yet): folders first, type a path or click."""
    d = Dialog(title, win, size=(520, 420))
    cur = Var(os.path.abspath(os.path.expanduser(start or os.getcwd())))
    res = {"v": None}
    lb = None

    def entries():
        p = cur.get()
        try:
            names = sorted(os.listdir(p), key=lambda n: (not os.path.isdir(os.path.join(p, n)), n.lower()))
        except OSError as e:
            return ["(cannot read: %s)" % e.strerror]
        return [".."] + [n + ("/" if os.path.isdir(os.path.join(p, n)) else "") for n in names]

    def refresh():
        lb.items = entries()
        lb.sel = []

    def choose(_sel=None):
        if not lb.sel:
            return
        n = lb.items[lb.sel[0]]
        full = os.path.normpath(os.path.join(cur.get(), n.rstrip("/")))
        if n == ".." or n.endswith("/"):
            cur.set(full)
            refresh()
        else:
            res["v"] = full
            d.close()

    def go(_t=None):
        p = os.path.expanduser(cur.get().strip())
        if os.path.isfile(p):
            res["v"] = p
            d.close()
        else:
            cur.set(p)
            refresh()
    with d:
        Entry(var=cur, on_submit=go)
        lb = Listbox(entries(), height=12)
        with Row():
            Button("Open", choose, primary=True)
            Button("Up", lambda: (cur.set(os.path.dirname(cur.get())), refresh()))
            Button("Cancel", d.close)
    lb.on_select = lambda s: None
    d.on_close = lambda: on_answer(res["v"])
    d.open()
    return d


# ---------------------------------------------------------------------------------------- no-op compat
class Style:
    """ttk.Style stand-in: TK 4K themes are set with Window.set_theme(); style calls are noted and ignored."""

    def __init__(self, *a, **k):
        pass

    def theme_use(self, name=None):
        _compat_note("ttk.Style().theme_use is ignored: use Window.set_theme('dark'|'light')")
        return "default"

    def configure(self, *a, **k):
        _compat_note("ttk.Style().configure is ignored (the TK 4K theme decides)")

    map = lookup = theme_names = layout = element_create = configure


class Scrollbar(Widget):
    """Scrollbars are built into TK 4K's lists, tables, trees and text boxes; this is an invisible stand-in."""

    def __init__(self, *a, **k):
        super().__init__(parent=k.get("parent"))
        self._visible = False

    def set(self, *a):
        pass

    def _draw(self) -> None:
        pass
