"""Widgets and layout containers.

The widget tree is retained (plain Python objects you can change at any time); drawing is
immediate underneath. Callbacks never run while a frame is being drawn: they are queued and
run right after, so it is always safe to add, remove or change widgets inside a callback.
"""
from __future__ import annotations

import itertools
from typing import Any, Callable, Optional

from . import _core

_ids = itertools.count(1)
_anim_ms = 0  # a widget sets this while drawing if it needs another frame soon (e.g. busy bar)
_stack: list["Container"] = []  # containers currently open with `with`


class Var:
    """A value that widgets can share (like Tk's StringVar/IntVar/BooleanVar in one).

    Changing it from any thread wakes the window; use Window.post() if you also touch widgets.
    """

    def __init__(self, value: Any = None):
        self._v = value
        self._traces: list[Callable[[Any], None]] = []

    def get(self) -> Any:
        return self._v

    def set(self, value: Any) -> None:
        if value == self._v:
            return
        self._v = value
        for fn in list(self._traces):
            _queue(fn, value)
        _core.wake()

    value = property(get, set)

    def trace(self, fn: Callable[[Any], None]) -> Callable[[Any], None]:
        """Call fn(new_value) whenever the value changes. Returns fn (usable as a decorator)."""
        self._traces.append(fn)
        return fn

    def trace_add(self, mode: Any, cb: Callable) -> str:
        """tkinter's var.trace_add("write", cb): cb is called as cb(name, index, mode)."""
        if "write" in (mode if isinstance(mode, (list, tuple)) else [mode]):
            self._traces.append(lambda _v, f=cb: f("", "", "write"))
        return "trace%d" % len(self._traces)

    trace_variable = trace_add_compat = lambda self, mode, cb: self.trace_add("write", cb)  # noqa: E731

    def trace_remove(self, *a: Any) -> None:
        pass

    def untrace(self, fn: Callable[[Any], None]) -> None:
        if fn in self._traces:
            self._traces.remove(fn)

    def __repr__(self) -> str:
        return f"Var({self._v!r})"


_callbacks: list[tuple[Callable, tuple]] = []


def _queue(fn: Optional[Callable], *args: Any) -> None:
    if fn is not None:
        _callbacks.append((fn, args))


def _take_callbacks() -> list[tuple[Callable, tuple]]:
    global _callbacks
    out, _callbacks = _callbacks, []
    return out


class Widget:
    """Base class. Create inside a `with Column():` block, or pass parent=."""

    def __init__(self, parent: Optional["Container"] = None, *, width: Optional[float] = None,
                 visible: bool = True, enabled: bool = True):
        self._id = next(_ids)
        self.parent: Optional[Container] = parent if parent is not None else (_stack[-1] if _stack else None)
        if self.parent is not None:
            self.parent._children.append(self)
        self.width = width
        self._visible = visible
        self._enabled = enabled
        self._rect = (0.0, 0.0, 0.0, 0.0)
        self.hovered = False

    # --- common properties; every setter wakes the window so it redraws
    visible = property(lambda s: s._visible, lambda s, v: s._set("_visible", v))
    enabled = property(lambda s: s._enabled, lambda s, v: s._set("_enabled", v))

    def _set(self, name: str, value: Any) -> None:
        if getattr(self, name) != value:
            setattr(self, name, value)
            _core.wake()

    def destroy(self) -> None:
        if self.parent is not None and self in self.parent._children:
            self.parent._children.remove(self)
        self.parent = None
        _core.wake()

    @property
    def rect(self) -> tuple[float, float, float, float]:
        """(x, y, w, h) from the last frame, in window points."""
        return self._rect

    # --- drawing
    def _in_row(self) -> bool:
        return isinstance(self.parent, Row)

    def _auto_width(self, row_default: float = 200.0) -> float:
        if self.width is not None:
            return self.width
        return row_default if self._in_row() else -1.0  # -1 = fill the available width

    def _render(self) -> None:
        if not self._visible:
            return
        _core.push_id(str(self._id))
        if not self._enabled:
            _core.begin_disabled(True)
        try:
            self._draw()
            self._rect = _core.item_rect()
            self.hovered = _core.item_hovered()
        finally:
            if not self._enabled:
                _core.end_disabled()
            _core.pop_id()

    def _draw(self) -> None:  # pragma: no cover
        raise NotImplementedError

    # ------------------------------------------------------------ tkinter compatibility (runtime)
    # Translated code that was not laid out statically keeps calling .pack()/.grid()/.config()/.bind() on its widgets.
    _CFG = {"text": "text", "textvariable": "_textvar", "command": "_command", "state": "_state", "value": "value",
            "variable": "_var", "fg": "color", "foreground": "color", "show": "_show", "values": "items"}

    def pack(self, **kw):
        self._pack = kw
        _compat_note("pack/grid/place options are used at run time only for side, fill, row and column")

    def grid(self, **kw):
        self._grid = kw
        _compat_note("pack/grid/place options are used at run time only for side, fill, row and column")

    def place(self, **kw):
        _compat_note("place() is not supported; the widget is laid out in creation order")

    def pack_forget(self):
        self.visible = False

    grid_forget = place_forget = pack_forget

    def config(self, cnf=None, **kw):
        kw = dict(cnf or {}, **kw)
        for k, v in kw.items():
            tgt = self._CFG.get(k)
            if tgt == "_textvar":
                self.var = v if isinstance(v, Var) else self.var
                if hasattr(self, "text") and not isinstance(getattr(type(self), "text", None), property):
                    self.text = v
            elif tgt == "_command":
                if hasattr(self, "on_click"):
                    self.on_click = v
                else:
                    self.on_change = (lambda _v, f=v: f()) if v else None
            elif tgt == "_state":
                self.enabled = v != "disabled"
            elif tgt == "_var":
                self.var = v
            elif tgt == "_show":
                self.password = bool(v)
            elif tgt:
                setattr(self, tgt, v)
            # everything else is cosmetic: the theme decides
        _core.wake()

    configure = config

    def cget(self, key):
        tgt = self._CFG.get(key, key)
        return getattr(self, tgt, None)

    def __getitem__(self, key):
        return self.cget(key)

    def __setitem__(self, key, value):
        self.config(**{key: value})

    def bind(self, seq, fn=None, add=None):
        """Entry: <Return> -> on_submit, <Key>/<KeyRelease>/<<Modified>> -> on_change; others are noted and ignored."""
        s = str(seq)
        if fn is None:
            return None
        if s in ("<Return>", "<KP_Enter>") and hasattr(self, "on_submit"):
            self.on_submit = lambda _t, f=fn: f(_Event(self))
        elif s in ("<Key>", "<KeyRelease>", "<KeyPress>", "<<Modified>>") and hasattr(self, "on_change"):
            self.on_change = lambda _t, f=fn: f(_Event(self))
        elif s in ("<Button-1>", "<ButtonRelease-1>", "<1>") and hasattr(self, "on_click"):
            self.on_click = lambda f=fn: f(_Event(self))
        else:
            _compat_note(f"bind({s}) on a {type(self).__name__} is not supported yet")
        return None

    def focus_set(self):
        pass

    focus = focus_force = lift = lower = update = update_idletasks = columnconfigure = rowconfigure = \
        grid_columnconfigure = grid_rowconfigure = pack_propagate = grid_propagate = tkraise = focus_set


class _Event:
    """What a tkinter <Key> or <Button-1> callback receives: just the widget (and empty key fields)."""
    def __init__(self, widget):
        self.widget, self.keysym, self.char, self.x, self.y = widget, "", "", 0, 0


_compat_seen: set = set()


def _compat_note(msg: str) -> None:
    if msg in _compat_seen:
        return
    _compat_seen.add(msg)
    try:
        from . import _alerts
        _alerts.note("todo", msg[:60], once_key="compat:" + msg)
    except Exception:
        pass


def _val(x: Any) -> Any:
    return x.get() if isinstance(x, Var) else x


def _rgb(c: Any) -> tuple[float, float, float]:
    """'#rrggbb' or (r, g, b) in 0..1 or 0..255 -> floats 0..1."""
    if isinstance(c, str):
        c = c.lstrip("#")
        return tuple(int(c[i:i + 2], 16) / 255.0 for i in (0, 2, 4))  # type: ignore[return-value]
    r, g, b = c[:3]
    return (r, g, b) if max(r, g, b) <= 1.0 else (r / 255.0, g / 255.0, b / 255.0)


class Label(Widget):
    def __init__(self, text: Any = "", *, dim: bool = False, wrap: bool = False, color: Any = None, **kw):
        super().__init__(**kw)
        self.text, self.dim, self.wrap, self.color = text, dim, wrap, color

    def _draw(self) -> None:
        s = str(_val(self.text))
        if self.color is not None:
            _core.text_colored(s, *_rgb(self.color), self.wrap)
        elif self.wrap:
            _core.text_wrapped(s, self.dim)
        else:  # in a Row or Grid, sit level with the framed widgets next to it
            _core.text(s, self.dim, isinstance(self.parent, (Row, Grid)))


class Button(Widget):
    def __init__(self, text: str = "Button", on_click: Optional[Callable[[], None]] = None, *,
                 primary: bool = False, height: float = 0.0, **kw):
        super().__init__(**kw)
        self.text, self.on_click, self.primary, self.height = text, on_click, primary, height
        self.clicks = 0

    def invoke(self) -> None:
        _queue(self.on_click)

    def _draw(self) -> None:
        w = self.width if self.width is not None else 0.0
        if _core.button(str(_val(self.text)), w, self.height, self.primary):
            self.clicks += 1
            _queue(self.on_click)


class Entry(Widget):
    """Single-line text box. Bind it to a Var, or read/write .text."""

    def __init__(self, text: str = "", *, var: Optional[Var] = None, hint: str = "",
                 password: bool = False, readonly: bool = False,
                 on_change: Optional[Callable[[str], None]] = None,
                 on_submit: Optional[Callable[[str], None]] = None, **kw):
        super().__init__(**kw)
        self.var = var if var is not None else Var(text)
        self.hint, self.password, self.readonly = hint, password, readonly
        self.on_change, self.on_submit = on_change, on_submit

    text = property(lambda s: s.var.get(), lambda s, v: s.var.set(v))

    def get(self) -> str:
        return str(self.var.get())

    def delete(self, first: Any = 0, last: Any = None) -> None:
        self.var.set("")

    def insert(self, index: Any, text: Any) -> None:
        cur = str(self.var.get())
        i = len(cur) if str(index) == "end" else max(0, int(index))
        self.var.set(cur[:i] + str(text) + cur[i:])

    def _draw(self) -> None:
        changed, new = _core.input_text("##entry", str(self.var.get()), self.hint, self.password,
                                        self.readonly, self._auto_width())
        if changed:
            self.var._v = new  # already on screen; skip the extra wake
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)
        if self.on_submit is not None and _core.item_enter():
            _queue(self.on_submit, self.var.get())


class Checkbox(Widget):
    def __init__(self, text: str = "", *, var: Optional[Var] = None, checked: bool = False,
                 on_change: Optional[Callable[[bool], None]] = None, **kw):
        super().__init__(**kw)
        self.text, self.on_change = text, on_change
        self.var = var if var is not None else Var(checked)

    checked = property(lambda s: bool(s.var.get()), lambda s, v: s.var.set(bool(v)))

    def get(self) -> bool:
        return self.checked

    def set(self, v: Any) -> None:
        self.checked = v

    def select(self) -> None:
        self.checked = True

    def deselect(self) -> None:
        self.checked = False

    def toggle(self) -> None:
        self.checked = not self.checked

    def invoke(self) -> None:
        self.toggle()
        _queue(self.on_change, self.checked)

    def _draw(self) -> None:
        changed, new = _core.checkbox(str(_val(self.text)), bool(self.var.get()))
        if changed:
            self.var._v = new
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)


class Slider(Widget):
    def __init__(self, lo: float = 0.0, hi: float = 1.0, *, var: Optional[Var] = None,
                 value: float = 0.0, fmt: Optional[str] = None,
                 on_change: Optional[Callable[[float], None]] = None, **kw):
        super().__init__(**kw)
        if fmt is None:  # whole-number range -> whole-number display, like tkinter's Scale
            fmt = "%.0f" if float(lo).is_integer() and float(hi).is_integer() and hi - lo >= 2 else "%.2f"
        self.lo, self.hi, self.fmt, self.on_change = lo, hi, fmt, on_change
        self.var = var if var is not None else Var(value)

    value = property(lambda s: s.var.get(), lambda s, v: s.var.set(v))

    def get(self) -> float:
        return self.var.get()

    def set(self, v: Any) -> None:
        self.var.set(v)

    def _draw(self) -> None:
        changed, new = _core.slider("##slider", float(self.var.get()), self.lo, self.hi, self.fmt,
                                    self._auto_width())
        if changed:
            self.var._v = new
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)


class Progress(Widget):
    """0..1 progress bar. Pass value=None for 'working, unknown length' (a moving bar)."""

    def __init__(self, value: Any = 0.0, *, text: str = "", height: float = 22.0, maximum: float = 1.0, **kw):
        super().__init__(**kw)
        self.maximum = float(maximum) if maximum else 1.0
        self.value = value if (value is None or isinstance(value, Var) or self.maximum == 1.0) else float(value) / self.maximum
        self.text, self.height = text, height

    def config(self, cnf=None, **kw):  # tkinter: config(value=40, maximum=200); value is in maximum units
        kw = dict(cnf or {}, **kw)
        if "maximum" in kw:
            self.maximum = float(kw.pop("maximum")) or 1.0
        if "value" in kw:
            v = kw.pop("value")
            self.value = None if v is None else float(v) / self.maximum
        super().config(**kw)
        _core.wake()

    configure = config

    def cget(self, key):
        if key == "value":
            return (self.value or 0.0) * self.maximum
        return super().cget(key)

    def step(self, amount: float = 1.0) -> None:
        self.value = min(1.0, (self.value or 0.0) + amount / self.maximum)
        _core.wake()

    def _draw(self) -> None:
        v = _val(self.value)
        if v is None:  # unknown length: a sweeping bar driven by the clock
            import time
            v = (time.monotonic() * 0.6) % 1.0
            global _anim_ms
            _anim_ms = 50  # ask the window for another frame in ~50 ms; no frames at all otherwise
        _core.progress(max(0.0, min(1.0, float(v))), self.text, self._auto_width(), self.height)


class Separator(Widget):
    def _draw(self) -> None:
        _core.separator()


class Placeholder(Widget):
    """Stands in for a tkinter widget TK 4K does not have yet, so a translated app still runs.

    It shows as a greyed-out box naming the missing widget, answers `.get()` with a harmless default,
    and swallows any other call (`insert`, `config`, `yview` ...) after recording it in the log, in the
    exit footer and in the QR error report. `visible=False` keeps it out of the layout (a Menu, say).
    """

    def __init__(self, kind: str = "widget", *, name: str = "", default: Any = "", line: int = 0, **kw):
        super().__init__(**kw)
        object.__setattr__(self, "_info", (kind, name, line))
        self.text = self.value = self._default = default
        from . import _alerts
        _alerts.note("placeholder", f"{kind}{' ' + repr(name) if name else ''} is not in TK 4K yet", line)

    def get(self, *args: Any) -> Any:
        return self._default

    def set(self, value: Any) -> None:
        self.text = self.value = self._default = value

    def __getattr__(self, attr: str):
        # only public method-like names; private/dunder lookups must still fail normally
        if attr.startswith("_"):
            raise AttributeError(attr)
        kind, name, line = self._info

        def swallow(*a: Any, **k: Any):
            from . import _alerts
            _alerts.note("unsupported", f"{name or kind}.{attr}() ignored (placeholder for {kind})", line)
            return _Null()
        return swallow

    def __setitem__(self, key: Any, value: Any) -> None:
        self.__getattr__("config")(**{str(key): value})

    def __getitem__(self, key: Any):
        self.__getattr__("cget")(key)
        return self._default

    def _draw(self) -> None:
        kind, name, _ = self._info
        _core.begin_disabled(True)
        _core.button(f"{kind}{' ' + name if name else ''}: not in TK 4K yet")
        _core.end_disabled()


class _Null:
    """Harmless stand-in returned by skipped calls: any attribute, call or index gives another _Null."""

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return self

    def __call__(self, *a, **k):
        return self

    def __getitem__(self, k):
        return self

    def __setitem__(self, k, v):
        pass

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return False

    def __len__(self):
        return 0

    def __repr__(self):
        return "<skipped tkinter call>"


def unsupported(what: str, line: int = 0) -> _Null:
    """Called by translated code in place of a tkinter call TK 4K cannot do yet.

    Records it (log, exit footer, QR report) and returns a null object so the program carries on.
    """
    from . import _alerts
    _alerts.note("unsupported", what, line)
    return _Null()


class Spacer(Widget):
    def __init__(self, height: float = 8.0, **kw):
        super().__init__(**kw)
        self.height = height

    def _draw(self) -> None:
        _core.spacing()


# ------------------------------------------------------------------ containers
def _fill(w, sticky: bool = False) -> None:
    opt = getattr(w, "_pack", None) or getattr(w, "_grid", None) or {}
    f = str(opt.get("fill", "")) or ""
    st = str(opt.get("sticky", "")) if sticky else ""
    if f in ("x", "both") or ("e" in st and "w" in st):
        _core.set_next_width(-1.0)


class Container(Widget):
    def __init__(self, parent: Optional["Container"] = None, **kw):
        super().__init__(parent, **kw)
        self._children: list[Widget] = []

    def __enter__(self):
        _stack.append(self)
        return self

    def __exit__(self, *exc):
        _stack.pop()
        return False

    def clear(self) -> None:
        self._children.clear()
        _core.wake()

    # tkinter's columnconfigure(weight=) for runtime grids
    def columnconfigure(self, index=0, weight=None, **kw):
        if weight is not None:
            self.__dict__.setdefault("_colw", {})[index] = weight

    grid_columnconfigure = columnconfigure

    def _draw_children(self) -> None:
        kids = [c for c in self._children if c._visible]
        if any(getattr(c, "_grid", None) for c in kids):
            self._draw_grid(kids)
        elif any(getattr(c, "_pack", None) for c in kids):
            self._draw_pack(kids)
        else:
            for child in list(self._children):
                child._render()

    def _draw_pack(self, kids) -> None:
        """tkinter pack at run time: top/bottom stack, consecutive left/right widgets share a row."""
        bottom = [c for c in kids if (getattr(c, "_pack", None) or {}).get("side") == "bottom"]
        main = [c for c in kids if c not in bottom]
        i = 0
        while i < len(main):
            c = main[i]
            side = (getattr(c, "_pack", None) or {}).get("side", "top")
            if side in ("left", "right"):
                run = [c]
                while i + 1 < len(main) and (getattr(main[i + 1], "_pack", None) or {}).get("side", "top") in ("left", "right"):
                    i += 1
                    run.append(main[i])
                left = [w for w in run if w._pack.get("side") == "left"]
                right = [w for w in run if w._pack.get("side") == "right"]
                first = True
                for w in left + list(reversed(right)):
                    if not first:
                        _core.same_line(0.0, -1.0)
                    first = False
                    _fill(w)
                    w._render()
            else:
                _fill(c)
                c._render()
            i += 1
        for c in reversed(bottom):
            _fill(c)
            c._render()

    def _draw_grid(self, kids) -> None:
        cells: dict = {}
        nxt = 0
        for c in kids:
            g = getattr(c, "_grid", None)
            if g is None:  # mixed with pack/none: treat as its own row
                cells[(nxt, 0)] = (c, 1)
                nxt += 1
                continue
            r = int(g.get("row", nxt))
            col = int(g.get("column", 0))
            cells[(r, col)] = (c, int(g.get("columnspan", 1)))
            nxt = r + 1
        ncols = max(col + span for (r, col), (c, span) in cells.items())
        rows = sorted({r for r, _ in cells})
        cw = self.__dict__.get("_colw", {})
        if not _core.begin_table(f"##g{self._id}", ncols):
            return
        try:
            for i in range(ncols):
                _core.table_setup_column(f"c{i}", float(cw.get(i, 0)))
            for r in rows:
                _core.table_next_row()
                for col in range(ncols):
                    _core.table_next_column()
                    hit = cells.get((r, col))
                    if hit:
                        _fill(hit[0], sticky=True)
                        hit[0]._render()
        finally:
            _core.end_table()


class Column(Container):
    """Children stacked top to bottom. gap=None uses the theme's spacing."""

    def __init__(self, parent=None, *, gap: Optional[float] = None, indent: float = 0.0, **kw):
        super().__init__(parent, **kw)
        self.gap, self.indent = gap, indent

    def _draw(self) -> None:
        if self.gap is not None:
            _core.push_spacing(self.gap, self.gap)
        if self.indent:
            _core.indent(self.indent)
        _core.begin_group()
        try:
            self._draw_children()
        finally:
            _core.end_group()
            if self.indent:
                _core.unindent(self.indent)
            if self.gap is not None:
                _core.pop_spacing()


class Row(Container):
    """Children side by side. Give widgets a width= (Entry defaults to 200)."""

    def __init__(self, parent=None, *, gap: Optional[float] = None, **kw):
        super().__init__(parent, **kw)
        self.gap = gap

    def _draw(self) -> None:
        if self.gap is not None:
            _core.push_spacing(self.gap, self.gap)
        _core.begin_group()
        try:
            first = True
            for child in list(self._children):
                if not child._visible:
                    continue
                if not first:
                    _core.same_line(0.0, -1.0 if self.gap is None else self.gap)
                first = False
                child._render()
        finally:
            _core.end_group()
            if self.gap is not None:
                _core.pop_spacing()


class Grid(Container):
    """Children fill cells left to right, top to bottom. weights = relative column widths.

    A column with weight 0 is only as wide as its widest widget.
    """

    def __init__(self, parent=None, *, columns: int = 2, weights: Optional[list[float]] = None, **kw):
        super().__init__(parent, **kw)
        self.columns = columns
        self.weights = weights or [1.0] * columns

    def _draw(self) -> None:
        if not _core.begin_table(f"##grid{self._id}", self.columns):
            return
        try:
            for i in range(self.columns):
                _core.table_setup_column(f"c{i}", self.weights[i] if i < len(self.weights) else 1.0)
            for child in list(self._children):
                if not child._visible:
                    continue
                _core.table_next_column()
                child._render()
        finally:
            _core.end_table()


# ------------------------------------------------------------------ 0.3.0 widgets
class TextArea(Widget):
    """Multi-line text box (tkinter's Text, the plain-text part). Bind a Var or use .text."""

    def __init__(self, text: str = "", *, var: Optional[Var] = None, height: float = 120.0,
                 readonly: bool = False, wrap: bool = True,
                 on_change: Optional[Callable[[str], None]] = None, **kw):
        super().__init__(**kw)
        self.var = var if var is not None else Var(text)
        self.height, self.readonly, self.wrap, self.on_change = height, readonly, wrap, on_change

    text = property(lambda s: s.var.get(), lambda s, v: s.var.set(v))

    # tkinter Text names ("1.0", "end", "insert"); tags and marks are noted and ignored
    def _off(self, index: Any) -> int:
        t, i = str(self.var.get()), str(index)
        if i in ("end", "insert", "end-1c"):
            return len(t) if i != "end-1c" else max(0, len(t) - 1)
        try:
            line, col = i.split(".")
            lines = t.split("\n")
            ln = max(1, int(line)) - 1
            if ln >= len(lines):
                return len(t)
            return sum(len(x) + 1 for x in lines[:ln]) + min(int(col) if col != "end" else len(lines[ln]), len(lines[ln]))
        except ValueError:
            return len(t)

    def insert(self, index: Any, chars: Any, *tags: Any) -> None:
        t, at = str(self.var.get()), self._off(index)
        self.var.set(t[:at] + str(chars) + t[at:])

    def get(self, start: Any = "1.0", end: Any = "end") -> str:
        t = str(self.var.get())
        return t[self._off(start):self._off(end)]

    def delete(self, start: Any = "1.0", end: Any = None) -> None:
        t = str(self.var.get())
        a = self._off(start)
        b = self._off(end) if end is not None else a + 1
        self.var.set(t[:a] + t[b:])

    def tag_configure(self, *a: Any, **k: Any) -> None:
        _compat_note("Text tags (colours, fonts) are not supported yet")

    tag_add = tag_remove = tag_config = mark_set = see = edit_reset = tag_configure

    def _draw(self) -> None:
        changed, new = _core.input_multiline("##area", str(self.var.get()), self._auto_width(), self.height,
                                             self.readonly, self.wrap)
        if changed:
            self.var._v = new
            for fn in list(self.var._traces):
                _queue(fn, new)
            _queue(self.on_change, new)


class Dropdown(Widget):
    """Drop-down list (ttk.Combobox, read-only style). .index is -1 when nothing is chosen."""

    def __init__(self, items: Optional[list[str]] = None, *, index: int = 0,
                 on_change: Optional[Callable[[int, str], None]] = None, **kw):
        super().__init__(**kw)
        self.items = list(items or [])
        self.index = index
        self.on_change = on_change

    value = property(lambda s: s.items[s.index] if 0 <= s.index < len(s.items) else "")

    # ttk.Combobox names
    def get(self) -> str:
        return self.value

    def set(self, v: Any) -> None:
        self.index = self.items.index(v) if v in self.items else -1
        _core.wake()

    def current(self, i: Optional[int] = None) -> int:
        if i is not None:
            self.index = int(i)
            _core.wake()
        return self.index

    values = property(lambda s: tuple(s.items), lambda s, v: (setattr(s, "items", [str(x) for x in v]), _core.wake()))

    def bind(self, seq, fn=None, add=None):
        if str(seq) == "<<ComboboxSelected>>" and fn is not None:
            self.on_change = lambda _i, _t, f=fn: f(_Event(self))
        elif fn is not None:
            _compat_note(f"Combobox.bind({seq}) is not supported yet")

    def _draw(self) -> None:
        changed, i = _core.combo("##dd", self.items, self.index, self._auto_width(200.0))
        if changed:
            self.index = i
            _queue(self.on_change, i, self.items[i])


class Table(Widget):
    """Scrolling list of rows with columns (ttk.Treeview in its flat 'headings' form).

    rows: list of tuples of strings. colors: optional list (same length) of '#rrggbb' per row.
    """

    def __init__(self, columns: Optional[list[str]] = None, rows: Optional[list[tuple]] = None, *,
                 colors: Optional[list[Any]] = None, height: float = 160.0, weights: Optional[list[float]] = None,
                 on_select: Optional[Callable[[int], None]] = None, **kw):
        super().__init__(**kw)
        self.columns = list(columns or [""])
        self.weights = weights
        self.height, self.on_select = height, on_select
        self.selected = -1
        self.rows: list[tuple] = []
        self.colors: list[Any] = []
        self.set_rows(rows or [], colors)

    def set_rows(self, rows: list[tuple], colors: Optional[list[Any]] = None) -> None:
        self.rows = [tuple(str(c) for c in r) for r in rows]
        self.colors = list(colors) if colors else [None] * len(self.rows)
        if self.selected >= len(self.rows):
            self.selected = -1
        _core.wake()

    def select(self, i: int) -> None:
        if i != self.selected:
            self.selected = i
            _queue(self.on_select, i)
            _core.wake()

    def _draw(self) -> None:
        w = self.width if self.width is not None else -1.0
        if _core.begin_child("##tbl", w, self.height, True):
            try:
                n = len(self.columns)
                if _core.begin_table("##cols", n):
                    try:
                        for i in range(n):
                            _core.table_setup_column(self.columns[i], self.weights[i] if self.weights else 1.0)
                        for i, row in enumerate(self.rows):
                            _core.push_id(str(i))
                            _core.table_next_row()
                            col = self.colors[i] if i < len(self.colors) else None
                            if col is not None:
                                _core.push_text_color(*_rgb(col))
                            for j in range(n):
                                _core.table_next_column()
                                txt = row[j] if j < len(row) else ""
                                if j == 0:
                                    if _core.selectable(txt + "##r", i == self.selected, True):
                                        self.select(i)
                                else:
                                    _core.text(txt)
                            if col is not None:
                                _core.pop_text_color()
                            _core.pop_id()
                    finally:
                        _core.end_table()
            finally:
                _core.end_child()
        else:
            _core.end_child()


class QRView(Widget):
    """Draws a square on/off matrix (such as a QR code) with a white quiet zone around it."""

    def __init__(self, matrix: Optional[list[list[int]]] = None, *, px: float = 5.0, quiet: int = 4, **kw):
        super().__init__(**kw)
        self.px, self.quiet = px, quiet
        self._n = 0
        self._bits = b""
        self.set_matrix(matrix or [])

    def set_matrix(self, matrix: list[list[int]]) -> None:
        m = len(matrix)
        q = self.quiet
        n = m + 2 * q if m else 0
        buf = bytearray(n * n)
        for y, row in enumerate(matrix):
            for x, v in enumerate(row):
                if v:
                    buf[(y + q) * n + x + q] = 1
        self._n, self._bits = n, bytes(buf)
        _core.wake()

    def _draw(self) -> None:
        if self._n:
            _core.draw_matrix(self._bits, self._n, self.px, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0)
        else:
            _core.text("(no QR yet)", True)


def set_clipboard(text: str) -> None:
    _core.set_clipboard(str(text))


def get_clipboard() -> str:
    return _core.get_clipboard()


class Frame(Column):
    """tkinter's Frame/ttk.Frame/LabelFrame: a Column that accepts (and ignores) the usual styling options."""

    def __init__(self, master=None, *args, parent=None, text: str = "", **ignored):
        super().__init__(parent if parent is not None else master if isinstance(master, Container) else None)
        self.text = text

    def _draw(self) -> None:
        if self.text:
            _core.text(str(_val(self.text)), True)
        super()._draw()


LabelFrame = Frame
